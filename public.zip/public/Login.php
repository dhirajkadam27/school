<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}


if(isset($_SESSION['no'])){
    header("Location: /");
   }


if (isset($_GET['ref'])){
    $ref = $_GET['ref'];
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <script src="/Assets/Js/JQuery.js"></script>
    <script src="https://www.gstatic.com/firebasejs/4.8.1/firebase.js"></script>
    <script>
        
        var config = {
           
            apiKey: "AIzaSyCYxecc6uN_P6wx5rbkxJLDx5WxgpLhVyQ",
            authDomain: "derbun.com",
            projectId: "derbun-8d1bc",
            storageBucket: "derbun-8d1bc.appspot.com",
            messagingSenderId: "664612708715",
        };

        firebase.initializeApp(config);

    </script>
 <style>
body{
    margin:0;
    padding: 0;
   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

}

input::-webkit-outer-spin-button, input::-webkit-inner-spin-button{
    -webkit-appearance: none;
    margin: 0;
  }
  input[type=number]{
    -moz-appearance: textfield;
  }
  
img[alt="www.000webhost.com"]{
               display: none;
           } 
.loadbg1{
            width: 100%;
            height: 100vh;
            position: fixed;
            top:0;
            z-index:4
        }
        .loader1{
            box-shadow:1px 1px 10px 1px #a9a9a9;
            display: flex;
            position: absolute;
            top: 50%;
            left: 50%;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width: 45px;
            height: 45px;
            margin: 7px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }

@media only screen and (min-width:320px) and (max-width: 480px){
.part1{
    display: none
}
.cell{
    text-align: center;
}
.title1{
    font-size: 28px;
    font-weight: 500;
    margin-bottom: 25px;
    background: gold;
    width: 100%;
    height: 50px;
    line-height:50px
}
.sub1{
    margin-top: 25px;
    width: 186px;
    margin: 10px auto;
}
.inpu{
    display: flex;
    width: 225px;
    margin: 15px auto;
    margin-top: 37px;
}
.pin{
    font-size: 25px;
    border-bottom: 5px solid gold;
    margin-right: 10px;
}
.inpu input{
    border: none;
    border-bottom: 5px solid gold;
    font-size: 25px;
    width: 160px;
    text-align: center;
    outline: none;
}
.inpu input::placeholder{
    font-size: 15px;
}
.cell1 button{
    padding: 10px 15px;
    font-size: 25px;
    border: none;
    background: gold;
    border-radius: 7px;
    margin-bottom: 20px;
}


.cell2{
    display: none
}
.title{
    font-size: 28px;
    font-weight: 500;
    margin-bottom: 25px;
    background: gold;
    width: 100%;
    height: 50px;
    line-height: 50px;
}
.sub2{
    margin-top: 25px;
}
.cell2 input{
    width: 160px;
    font-size: 35px;
    border: none;
    border-bottom: 5px solid gold;
    text-align: center;
    outline: none;
    margin-top: 25px;
}
.sub3{
    margin-top: 34px;
    margin-bottom: 7px;
}
.sub4 a{
    text-decoration: none;
    font-size: 18px;
    font-weight: 500;
    color: red;
}
.cell2 button{
    padding: 10px 15px;
    font-size: 25px;
    border: none;
    background: gold;
    border-radius: 7px;
    margin-top: 15px;
}
.cell2 input::placeholder{
    font-size: 18px;
}
#dis{
    display: none;
    width: 90%;
    height: 40px;
    position: absolute;
    bottom: 20px;
    left: 5%;
    background: #6f6f6f;
    color: white;
    font-size: 20px;
    border-radius: 6px;
    padding-top: 10px;
    text-align: center;
}




}


 /* max size */
 @media only screen and (min-width:800px){


.main{
    width: 100%;
}
.part1{
    width: 50%;
}
.all{
    width:80%;
    display: flex;
    margin:10px auto;
    margin-top: 50px;
    box-shadow: 1px 1px 10px 1px #d2d2d2;
}

.image{
    width:100%;
    text-align: center;
}
.image img{
    width:100%
}
.part2{
    width: 50%;
}
.cell{
    width:100%;
}
.cell1{
    text-align: center;
    margin-top: 120px;
}
.cell1 button{
    padding: 10px 20px;
    font-size: 25px;
    border: none;
    background: gold;
    border-radius: 7px;
    margin-bottom: 20px;
}
.cell2 button{
    padding: 10px 30px;
    font-size: 25px;
    border: none;
    background: gold;
    margin-top: 30px;
    border-radius: 7px;
}
.title1{
    font-size: 30px;
    font-weight: 500;
    margin-top: 50px;
}
.title{
    font-size: 30px;
    font-weight: 500;
    margin-top: 50px;
}
.sub1{
    width: 185px;
    margin: 10px auto;
    margin-top: 34px;
}
.sub2{
    margin-top: 25px;
}
.sub3{
    margin-top: 34px;
}
.sub4{
    margin-top: 5px;
}

.sub4 a{
    text-decoration: none;
    font-weight: 600;
    font-size: 17px;
    color: red;
    padding-top: 20px;
}
.cell2{
    display: none;
    text-align: center;
    margin-top: 120px;
}
.inpu{
    display: flex;
    font-size: 35px;
    width: 310px;
    margin: 5px auto;
  
}
.pin{
    border-bottom: 5px solid gold;
    margin-right: 10px;
}
.inpu input{
    width: 230px;
    font-size: 35px;
    border: none;
    border-bottom: 5px solid gold;
    text-align: center;
    outline: none
}
.cell2 input{
    width: 160px;
    font-size: 35px;
    border: none;
    border-bottom: 5px solid gold;
    text-align: center;
    outline: none;
    margin-top: 25px;
}
.cell2 input::placeholder{
    font-size: 18px;
}

.inpu input{
    width: 230px;
    font-size: 35px;
    border: none;
    border-bottom: 5px solid gold;
    text-align: center;
    outline: none
}
.inpu input::placeholder{
    font-size: 20px;
}
#dis{
    position: absolute;
    top: 20px;
    right: 15px;
    background: #6f6f6f;
    color: white;
    padding: 10px 15px;
    font-size: 20px;
    border-radius: 6px;
    display: none
}

 }
    </style>
</head>
<body onload="load1()">

<div id="load1" class="loadbg1">

<div class="loader1">
    <img src="/Assets/Icons/loader.gif">
</div>

</div>

<div class="main">
        <div class="all">
             <div class="part1">
                  <div class="image">
                      <img src="/Assets/Icons/opt2.jpg">
                  </div>
                  
             </div>
             
            <div class="part2">
                 <div class="cell">
                              <div id="num" class="cell1">
                                  <div class="title1">Verify your phone</div>
                                  <div class="sub1">We will send you an <b>OTP</b> on your number</div>
                                  <div class="inpu">
                                    <div class="pin">+91</div><input type="number" id="no" maxlength="10" placeholder="Enter 10 Digit Number">
                                  </div>
                                  <br>
                                  <br>
                                  <button onclick="auth()">Continue</button>
                                  <br>
                                  <a style="text-decoration:none" href='/Logins/test?ref=<?php if(isset($ref)){ echo $ref; } ?>'>Sign In</a>
                              </div>
                             <div id="otp" class="cell2">
                                 <div class="title">Verify OTP</div>
                                 <div class="sub2">Enter <b>OTP</b> sent to you on <div id="phone"></div></div>
                                 <div id="recaptcha"></div>
                                 <input id="cod" placeholder="Enter the OTP" type="number">
                                   <div id="codo" class="sub3">60</div>
                                 <button onclick="verify()">Verify</button>
                             </div>
                </div>
            </div>
             
      </div>
</div>
<div id="dis"></div>
<script src="/Assets/Js/JQuery.js"></script>
<script>
$(document).ready(function(){
    $("#no").focus();
});


var recaptcha = new firebase.auth.RecaptchaVerifier('recaptcha',
{
    size: "invisible",
    callback: function(response) {
      submitPhoneNumberAuth();
    }
  });


function auth(){

   var count = document.getElementById('codo').innerHTML;
                                   var set = setInterval(function(){
                                    document.getElementById('codo').innerHTML = --count;
                                    if(count==0){
                                    document.getElementById('codo').innerHTML = "<div class='sub3'>I didn't receive the <b>OTP</b> !</div><div class='sub4'><a href=''>Resend Code</a></div>";
                                    clearInterval(set);
                                    }
                                   },1000);
                                   
                                     document.getElementById('num').style.display = "none";
                                     document.getElementById('otp').style.display = "block";


    var number = '+91' + document.getElementById('no').value;
  
    firebase.auth().signInWithPhoneNumber(number, recaptcha).then( function(echo) {
        window.echo = echo;
        document.getElementById('phone').innerHTML = number;
    $("#cod").focus();

    })
    .catch(function (error) {
        document.getElementById('no').value = " ";
        document.getElementById('dis').innerHTML = "Something Went Wrong";
        document.getElementById('dis').style.display = "block";
setTimeout(function(){;
    document.getElementById('dis').style.display = "none";
}, 3000);

    });
  
}


function verify(){
    document.getElementById("load1").style.display = "block";
    
    
var  code = document.getElementById('cod').value;
var numbers = document.getElementById('no').value;

if(code === null) return;


echo.confirm(code).then(function (result) {
    document.getElementById('go').value = numbers;
    document.getElementById('self').submit();
    document.getElementById("load1").style.display = "none";
    
}).catch(function (error) {
    document.getElementById('cod').value = "";
    document.getElementById('dis').innerHTML = "Please, Enter the correct OTP";
    document.getElementById('dis').style.display = "block";
    document.getElementById("load1").style.display = "none";
setTimeout(function(){
    document.getElementById('dis').style.display = "none";
}, 3000);

});


}

function load1(){
    document.getElementById("load1").style.display = "none";
}
</script>



<form id="self" action="Logins/Encode" method="POST">
    <input type="hidden" id="go" name="yes">
    <input type="hidden" name="ref" value="<?php if(isset($ref)){ echo $ref; } ?>">
</form>

</body>
</html>
