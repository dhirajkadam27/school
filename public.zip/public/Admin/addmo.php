<?php
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/config.php';

$query = "SELECT * FROM url";
$data = mysqli_query($conn, $query);
while($result = mysqli_fetch_assoc($data)){
$ids = $result['ID'];
}
$id = ++$ids;

if(isset($_POST['submit'])){
    $bkurl = $_POST['bkurl'];
    $bkbr = $_POST['bkbr'];
    $bkti = $_POST['bkti'];
    $bkpr = $_POST['bkpr'];
    $bkmr = $_POST['bkmr'];
    $bksi = $_POST['bksi'];
    $bki1 = $_POST['bki1'];
    $bki2 = $_POST['bki2'];
    $bki3 = $_POST['bki3'];
    $bki4 = $_POST['bki4'];
    $bki5 = $_POST['bki5'];
    $bki6 = $_POST['bki6'];
    $bkab = $_POST['bkab'];
    $fkurl = $_POST['fkurl'];
    $fkbr = $_POST['fkbr'];
    $fkti = $_POST['fkti'];
    $fkpr = $_POST['fkpr'];
    $fkmr = $_POST['fkmr'];
    $fksity = $_POST['fksit'];
    $fksina = $_POST['fksi'];
    $fksina = str_replace("_"," ", $fksina);
    $fkcoty = $_POST['fkcot'];
    $fkcona = $_POST['fkco'];
    $fkcona = str_replace("_"," ", $fkcona);
    $fksi1ty = $_POST['fksi1t'];
    $fksi1na = $_POST['fksi1'];
    $fksi1na = str_replace("_"," ", $fksi1na);
    $fksi2ty = $_POST['fksi2t'];
    $fksi2na = $_POST['fksi2'];
    $fksi3ty = $_POST['fksi3t'];
    $fksi3na = $_POST['fksi3'];
    $fki1 = $_POST['fki1'];
    $fki2 = $_POST['fki2'];
    $fki3 = $_POST['fki3'];
    $fki4 = $_POST['fki4'];
    $fki5 = $_POST['fki5'];
    $fki6 = $_POST['fki6'];
    $fkab = $_POST['fkab'];
    $azurl = $_POST['azurl'];
    $azbr = $_POST['azbr'];
    $azti = $_POST['azti'];
    $azpr = $_POST['azpr'];
    $azmr = $_POST['azmr'];
    $azsit = $_POST['azsit'];
    $azsi = $_POST['azsi'];
    $azsi = str_replace("_"," ", $azsi);
    $azcot = $_POST['azcot'];
    $azco = $_POST['azco'];
    $azco = str_replace("_"," ", $azco);
    $azstt = $_POST['azstt'];
    $azst = $_POST['azst'];
    $azst = str_replace("_"," ", $azst);

    $azi1 = $_POST['azi1'];
    $azi2 = $_POST['azi2'];
    $azi3 = $_POST['azi3'];
    $azi4 = $_POST['azi4'];
    $azi5 = $_POST['azi5'];
    $azi6 = $_POST['azi6'];
    $azab = $_POST['azab'];
    
    $sec = $_POST['sec'];
    $cat = $_POST['cat'];
    $sub = $_POST['sub'];
    $tags = $_POST['hidden-tags'];

    if(!empty($bkpr)){
        $bksql = "INSERT INTO `data`(`sites`, `productid`, `name`, `descp`, `rating`, `original`, `sizety`, `sizena`,  `image1`, `image2`, `image3`, `image4`, `image5`, `image6`,`about`) VALUES ('BK','$id','$bkbr','$bkti','0','$bkmr', 'Size', '$bksi','$bki1','$bki2','$bki3','$bki4','$bki5','$bki6','$bkab')";	
        mysqli_query($conn, $bksql);   
    }
    if(!empty($fkpr)){
        $fksql = "INSERT INTO `data`(`sites`, `productid`, `name`, `descp`, `rating`, `original`, `sizety`, `sizena`, `coty`, `cona`, `si1ty`, `si1na`, `si2ty`, `si2na`, `si3ty`, `si3na`, `image1`, `image2`, `image3`, `image4`, `image5`, `image6`,`about`) VALUES ('FK','$id','$fkbr','$fkti','0','$fkmr','$fksity','$fksina','$fkcoty','$fkcona','$fksi1ty','$fksi1na','$fksi2ty','$fksi2na','$fksi3ty','$fksi3na','$fki1','$fki2','$fki3','$fki4','$fki5','$fki6','$fkab')";	
        mysqli_query($conn, $fksql);    
    }
    if(!empty($azpr)){
        $azsql = "INSERT INTO `data`(`sites`, `productid`, `name`, `descp`, `rating`, `original`, `sizety`, `sizena`, `coty`, `cona`, `si1ty`, `si1na`, `si2ty`, `si2na`, `si3ty`, `si3na`, `image1`, `image2`, `image3`, `image4`, `image5`, `image6`,`about`) VALUES ('AZ','$id','$azbr','$azti','0','$azmr','$azsit','$azsi','$azcot','$azco','$azstt','$azst','', '', '', '','$azi1','$azi2','$azi3','$azi4','$azi5','$azi6','$azab')";	
        mysqli_query($conn, $azsql);       
    }

    if(isset($_POST['valos'])){
        $varit = $_POST['valos'];
        foreach ($varit as $varity) {
            mysqli_query($conn, $varity);
           }
    }

    $sql = "INSERT INTO `url`(`FK`, `AZ`, `BK`, `FK_P`, `AZ_P`,`BK_P`, `pri`, `sec`, `tri`, `tags`) values('$fkurl', '$azurl','$bkurl', '$fkpr', '$azpr', '$bkpr', ' $sec', ' $cat',  '$sub', '$tags')";	
    if(mysqli_query($conn, $sql)){
      echo "done";
  }
    else{
        echo "none";
    }
}
?>

<html>
   <head>

  <script src="/Assets/Js/JQuery.js"></script>
      <meta name='viewport' content='width=device-width, initial-scale=1'>
      <title>Admin</title>
   
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
         }
         img[alt="www.000webhost.com"]{
         display: none;
         } 
         .loadbg1{
         width: 100%;
         height: 100vh;
         background-color: white;
         position: fixed;
         z-index:1
         }
         .loader1{
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: flex;
         position: absolute;
         top:50%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         }
         .loader1 img{
         width:45px;
         height: 45px;
         margin:5px;
         border-radius: 50%;
         }
         .loader1 p{
         font-weight: 600;
         padding-left:20px ;
         }
         @media only screen and (min-width:320px) and (max-width: 480px){
         .nav{
         background:gold;
         width:100%;
         height:50px;
         position: fixed;
         top: 0;
         z-index:5;
         display:flex;
         }
         .slicon{
         width:20px;
         height:20px;
         margin: 15px 15px 0px 15px
         }
         .left{
         width:80%;
         height:100%;
         position:fixed;
         top:0;
         left:-90%;
         z-index: 7;
         background:white;
         transition-property:left;
         transition-duration: 0.3s
         }
         .slide:hover .left{
         left:0;
         }
         .menu > ul{
         list-style:none;
         padding:0;
         margin:0;
         position:relative;
         }
         .menu li{
         display:flex
         }
         .menu li > a{
         flex-basis:80%;
         text-decoration:none;
         color:black;
         display:block;
         padding:10px 29px;
         font-size:20px;
         }
         .menu li > span{
         font-size:15px;
         color:green;
         flex-basis:20%;
         position:absolute;
         right:0;
         margin-top:7px
         }
         .menu ul > li:hover{
         background: rgb(221, 221, 221);
         }
         .til{
         font-size: 20px;
         font-weight: 500;
         line-height:50px
         }
         .sliderbg{
         width:100%;
         height:100%;
         background: #0a0a0a70;
         position:fixed;
         top:0;
         left:0;
         z-index:5;
         visibility:hidden;
         transition: visibility 0.1s;
         }

         .main{
    position:absolute;
    top: 80px
}




         }


















         /* max size */
         @media only screen and (min-width:800px){
         .nav{
         background:gold;
         width:100%;
         height:70px;
         position: fixed;
         z-index:4;
         display:flex;
         }
         .til{
         font-family: Verdana, Geneva, Tahoma, sans-serif;
         font-weight:bold;
         font-size:39px;
         color:black;
         margin-left:90px;
         line-height:70px
         }
         .slide{
         position:fixed;
         padding:17px 28px 22px 24px;
         }
         .slicon{
         width:30px;
         height:30px
         }
         .left{
         width:200px;
         height:100%;
         margin-top:23px;
         position:fixed;
         left:-200px;
         background:white;
         transition-property:left;
         transition-duration: 0.3s
         }
         .slide:hover .left{
            left:0;
            box-shadow: 5px 16px 20px 2px #0000006b;
		 }
         .menu > ul{
         list-style:none;
         padding:0;
         margin:0;
         position:relative
         }
         .menu li{
         display:flex
         }
         .menu li > a{
         flex-basis:80%;
         text-decoration:none;
         color:black;
         display:block;
         padding:10px 29px;
         font-size:17px;
         }
         .menu li > span{
         font-size:15px;
         color:green;
         flex-basis:20%;
         position:absolute;
         right:0;
         margin-top:7px
         }
         .menu ul > li:hover{
         background: rgb(221, 221, 221);
         }
         /*Vertical Menu Bar End*/
         .sliderbg{
         width:100%;
         height:100%;
         background: #0a0a0a70;
         position:fixed;
         top:0;
         left:0;
         z-index:4;
         display:none
         }
.main{
    position:absolute;
    top: 120px;
    width: 100%;
}
.check{
    width: 100%;
    text-align: center;
    display: block;
    margin-bottom:20px;
}
.check input{
    width: 35%;
    padding: 10px;
}
.check button{
    width: 10%;
    padding: 10px;
}
#btn{
    padding: 10px;
    width: 100px;
    display: block;
    margin: 5px auto;
}

.pop{
    width: 96%;
    height: 92vh;
    position: fixed;
    background: #ffffff;
    top: 2%;
    left: 1%;
    z-index: 4;
    padding: 1%;
    box-shadow: 1px 1px 10px 1px #d0d0d0;
    border-radius: 10px;
    display: none;
    overflow: scroll;
}
.pop2{
    width: 96%;
    height: 92vh;
    position: fixed;
    background: #d0f8ff;
    top: 2%;
    left: 1%;
    z-index: 5;
    padding: 1%;
    box-shadow: 1px 1px 10px 1px #d0d0d0;
    border-radius: 10px;
    display: none;
    overflow: scroll;
}
.div{
    width: 100%;
    display: flex;
}
.one{
    width:10%;
}
.two{
    width: 90%
}
.cross{
    font-size: 40px;
    transform: rotate(45deg);
    position: fixed;
    right: 28px;
    top: 15px;
    background: none;
    border: none;
}
select{
    width:200px;
    padding:10px;
    margin: 10px auto;
    display: flex
}

/* tags css  */
.typeahead{
    border: none;
    outline: none;
    font-size: 15px;

}
.tm-tag-remove{
    font-size: 20px;
    text-decoration: none;
    color: black;
    margin-left: 5px;
    font-family: monospace;
}
.tm-tag {
    padding: 8px 5px;
    background: gold;
    border-radius: 5px;
    margin-right: 5px;
    margin-bottom: 8px;
}
.form-group {
    width: 300px;
    padding: 10px 5px;
    border: 1px solid black;
    border-radius: 5px;
    display: flex;
    flex-wrap: wrap;
    margin:20px auto;
}

.form-group ul{
    position: absolute;
    list-style: none;
    z-index:5;
    background: white
}
.typeahead li{
    padding: 10px 10px;
    border: 1px solid #c1c1c1;
    font-size: 20px;
}
.typeahead strong{
    color: red
}
.typeahead li:hover{
    background: #c1c1c1
}
.typeahead a{
    text-decoration: none;
    color: black;
}


         }
      </style>
   </head>
   <body onload="load1()">
      <div id="load1" class="loadbg1">
         <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
         </div>
      </div>
      <script>
         function jshover(){
         
             document.getElementById("ridss").style.visibility = 'visible';
         }
         function jshoverout(){
             document.getElementById("ridss").style.visibility = 'hidden';
         }
         
         function seaa(){
             document.getElementById("sein").style.display = 'block';
         }
             
      </script>
      <div id="navv" class="nav">
         <!--Vertical Slider Img-->
         <div   onmouseover="jshover()" onmouseout="jshoverout()" class="slide">
            <img class="slicon" src="/Assets/Icons/menu.png">
            <!--Vertical Slider Starts-->
            <div class="left">
               <!--Vertical Slider Menu Starts-->
               <div class="menu">
                  <ul>
                     <li><a href="/Admin/AddPro">Add Product</a></li>
                     <li><a href="/Admin/Product">Product</a></li>
                     <li><a href="/Admin/Users">Users</a></li>
                     <li><a href="/Admin/Orders">Orders</a></li>
                     <li><a href="/Admin/Address">Address</a></li>
                     <li><a href="/Admin/Search">Keyword</a></li>
                     <li><a href="/Admin/Notifications">Notifications</a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="ridss" class="sliderbg">
         </div>
         <!-- Vertical silder ends-->
         <div class="til">
            Add Product
         </div>
      </div>
      </div>
      <!--navbar Ends-->

<div class="main">
<div class="check"><p id="ids"><?php echo $id; ?></p></div>

<select style="margin-bottom:20px" name="sec" id="section" onChange="Section()">
    <option>Select Section</option>
    <option value="Men">Men</option>
    <option value="Women">Women</option>
    <option value="Kids">Mobile</option>
    </select>
<select style="margin-bottom:20px" name="cat" id="category" onChange="Category()">
        <option>Select Catgory</option>
    </select>
<select style="margin-bottom:20px" name="sub" id="sub" onChange="subca()">
        <option>Select Sub-Catgory</option>
    </select>


<div class="check">
<input id="bkin" type="text" placeholder="Bewakoof URL">
<button onclick="bk()">Fetch</button>
</div>

<div class="check">
<input id="fkin" type="text" placeholder="Flipkart URL">
<button onclick="fk()">Fetch</button>
</div>

<div class="check">
<input id="azin" type="text" placeholder="Amazon URL">
<button onclick="az()">Fetch</button>
</div>

<div class="pop" id="pop">

<button onclick="closes()" class="cross">
+
</button>
<div id="showbk"></div>
<div id="showfk"></div>
<div id="showaz"></div>

</div>

<div class="pop2" id="pop2">

<button onclick="closes2()" class="cross">
+
</button>

<div id="variaz"></div>
<div id="varifk"></div>
<div id="varibk"></div>

</div>


<form id="formo" method="POST">
<input type="hidden" id="subm" name="submit" value="1">
<input type="hidden" id="bu" name="bkurl" value="">
<input type="hidden" id="bb" name="bkbr" value="">
<input type="hidden" id="bt" name="bkti" value="">
<input type="hidden" id="bp" name="bkpr" value="">
<input type="hidden" id="bm" name="bkmr" value="">
<input type="hidden" id="bs" name="bksi" value="">
<input type="hidden" id="b1" name="bki1" value="">
<input type="hidden" id="b2" name="bki2" value="">
<input type="hidden" id="b3" name="bki3" value="">
<input type="hidden" id="b4" name="bki4" value="">
<input type="hidden" id="b5" name="bki5" value="">
<input type="hidden" id="b6" name="bki6" value="">
<input type="hidden" id="ba" name="bkab" value="">
<input type="hidden" id="fu" name="fkurl" value="">
<input type="hidden" id="fb" name="fkbr" value="">
<input type="hidden" id="ft" name="fkti" value="">
<input type="hidden" id="fp" name="fkpr" value="">
<input type="hidden" id="fm" name="fkmr" value="">
<input type="hidden" id="fs" name="fksi" value="">
<input type="hidden" id="fst" name="fksit" value="">
<input type="hidden" id="fct" name="fkcot" value="">
<input type="hidden" id="fc" name="fkco" value="">
<input type="hidden" id="fs1t" name="fksi1t" value="">
<input type="hidden" id="fs1" name="fksi1" value="">
<input type="hidden" id="fs2t" name="fksi2t" value="">
<input type="hidden" id="fs2" name="fksi2" value="">
<input type="hidden" id="fs3t" name="fksi3t" value="">
<input type="hidden" id="fs3" name="fksi3" value="">
<input type="hidden" id="f1" name="fki1" value="">
<input type="hidden" id="f2" name="fki2" value="">
<input type="hidden" id="f3" name="fki3" value="">
<input type="hidden" id="f4" name="fki4" value="">
<input type="hidden" id="f5" name="fki5" value="">
<input type="hidden" id="f6" name="fki6" value="">
<input type="hidden" id="fa" name="fkab" value="">
<input type="hidden" id="au" name="azurl" value="">
<input type="hidden" id="ab" name="azbr" value="">
<input type="hidden" id="at" name="azti" value="">
<input type="hidden" id="ap" name="azpr" value="">
<input type="hidden" id="am" name="azmr" value="">

<input type="hidden" id="ast" name="azsit" value="">
<input type="hidden" id="as" name="azsi" value="">
<input type="hidden" id="act" name="azcot" value="">
<input type="hidden" id="ac" name="azco" value="">
<input type="hidden" id="asyt" name="azstt" value="">
<input type="hidden" id="asy" name="azst" value="">

<input type="hidden" id="a1" name="azi1" value="">
<input type="hidden" id="a2" name="azi2" value="">
<input type="hidden" id="a3" name="azi3" value="">
<input type="hidden" id="a4" name="azi4" value="">
<input type="hidden" id="a5" name="azi5" value="">
<input type="hidden" id="a6" name="azi6" value="">
<input type="hidden" id="aa" name="azab" value="">


<input type="hidden" id="secc" name="sec" value="">
<input type="hidden" id="catt" name="cat" value="">
<input type="hidden" id="subb" name="sub" value="">

<div class="form-group">
            <input type="text" name="tags" autocomplete="off" placeholder="Type here.." class="typeahead tm-input form-control tm-input-info">
        </div>

<div id="varita">

</div>
<button id="btn">Upload</button>
</form>




<script>
             function btnss(){
            document.getElementById("formo").submit();
         }

         
function bk(){
    var linkb = document.getElementById('bkin').value;
            $.get("/Admin/BK.php",{
		url: linkb
	}, function(datab){
document.getElementById('showbk').innerHTML = datab;
document.getElementById("pop").style.display = "block";
document.getElementById("showbk").style.display = "block";
document.getElementById("showaz").style.display = "none";
document.getElementById("showfk").style.display = "none";

document.getElementById("bu").value = document.getElementById('bkin').value;
document.getElementById("bb").value = document.getElementById('bkbr').innerHTML;
document.getElementById("bt").value = document.getElementById('bkti').innerHTML;
document.getElementById("bp").value = document.getElementById('bkpr').innerHTML;
document.getElementById("bm").value = document.getElementById('bkmr').innerHTML;
document.getElementById("bs").value = document.getElementById('bksi').innerHTML;
document.getElementById("b1").value = document.getElementById('bki1').innerHTML;
document.getElementById("b2").value = document.getElementById('bki2').innerHTML;
document.getElementById("b3").value = document.getElementById('bki3').innerHTML;
document.getElementById("b4").value = document.getElementById('bki4').innerHTML;
document.getElementById("b5").value = document.getElementById('bki5').innerHTML;
document.getElementById("b6").value = document.getElementById('bki6').innerHTML;
document.getElementById("ba").value = document.getElementById('bkab').innerHTML;
document.getElementById("subm").value = "bk";
	});
         }
         function fk(){
             var linkf = document.getElementById('fkin').value;
            $.get("/Admin/FK.php",{
		url: linkf
	}, function(dataf){
document.getElementById('showfk').innerHTML = dataf;
document.getElementById("pop").style.display = "block";
document.getElementById("showbk").style.display = "none";
document.getElementById("showaz").style.display = "none";
document.getElementById("showfk").style.display = "block";

document.getElementById("fu").value = document.getElementById('fkin').value;
document.getElementById("fb").value = document.getElementById('fkbr').innerHTML;
document.getElementById("ft").value = document.getElementById('fkti').innerHTML;
document.getElementById("fp").value = document.getElementById('fkpr').innerHTML;
document.getElementById("fm").value = document.getElementById('fkmr').innerHTML;
document.getElementById("fs").value = document.getElementById('fksizo').innerHTML;
document.getElementById("fc").value = document.getElementById('fkcolo').innerHTML;
document.getElementById("fs1").value = document.getElementById('fkstozo').innerHTML;
document.getElementById("fs2").value = document.getElementById('fkramzo').innerHTML;
document.getElementById("fs3").value = document.getElementById('fkdiszo').innerHTML;
document.getElementById("f1").value = document.getElementById('fki1').innerHTML;
document.getElementById("f2").value = document.getElementById('fki2').innerHTML;
document.getElementById("f3").value = document.getElementById('fki3').innerHTML;
document.getElementById("f4").value = document.getElementById('fki4').innerHTML;
document.getElementById("f5").value = document.getElementById('fki5').innerHTML;
document.getElementById("f6").value = document.getElementById('fki6').innerHTML;
document.getElementById("fa").value = document.getElementById('fkab').innerHTML;
document.getElementById("subm").value = "fk";

	});
         }
         function az(){
            var linka = document.getElementById('azin').value;
            $.get("/Admin/AZ.php",{
		url: linka
	}, function(dataa){
document.getElementById('showaz').innerHTML = dataa;
document.getElementById("pop").style.display = "block";
document.getElementById("showbk").style.display = "none";
document.getElementById("showaz").style.display = "block";
document.getElementById("showfk").style.display = "none";

document.getElementById("au").value = document.getElementById('azin').value;
document.getElementById("ab").value = document.getElementById('azbr').innerHTML;
document.getElementById("at").value = document.getElementById('azti').innerHTML;
document.getElementById("ap").value = document.getElementById('azpr').innerHTML;
document.getElementById("am").value = document.getElementById('azmr').innerHTML;

document.getElementById("as").value = document.getElementById('azsizo').innerHTML;
document.getElementById("ac").value = document.getElementById('azcolo').innerHTML;
document.getElementById("asy").value = document.getElementById('azty').innerHTML;

document.getElementById("a1").value = document.getElementById('azi1').innerHTML;
document.getElementById("a2").value = document.getElementById('azi2').innerHTML;
document.getElementById("a3").value = document.getElementById('azi3').innerHTML;
document.getElementById("a4").value = document.getElementById('azi4').innerHTML;
document.getElementById("a5").value = document.getElementById('azi5').innerHTML;
document.getElementById("a6").value = document.getElementById('azi6').innerHTML;
document.getElementById("aa").value = document.getElementById('azab').innerHTML;
document.getElementById("subm").value = "az";

	});
         }

         var azsizcl = 0;
        var azcolcl = 0;
        var azsycl = 0;

         function vari(urli,nali,tyi){
            $.get("/Admin/az_vari.php",{
		url : urli,
        type : tyi, 
        varina : nali,
        ids : <?php echo $id; ?>,
	}, function(urla){
        document.getElementById('variaz').innerHTML = urla;


        if(tyi == "Size"){
    ++azsizcl;
    if(azsizcl > 1){
        document.getElementById("ast").value = "Size";
        document.getElementById("azsizo").append(","+nali);
    }
    else{
        document.getElementById("ast").value = "Size";
        document.getElementById("azsizo").append(nali);
    }
}

if(tyi == "Color"){
    ++azcolcl;
    if(azcolcl > 1){
        document.getElementById("act").value = "Color";
        document.getElementById("azcolo").append(","+nali);
    }
    else{
        document.getElementById("act").value = "Color";
        document.getElementById("azcolo").append(nali);
    }
}

if(tyi == "Style"){
    ++azsycl;
    if(azsycl > 1){
        document.getElementById("asyt").value = "Style";
        document.getElementById("azty").append(","+nali);
    }
    else{
        document.getElementById("asyt").value = "Style";
        document.getElementById("azty").append(nali);
    }
}

        document.getElementById("variaz").style.display = "block";
        document.getElementById("varifk").style.display = "none";
        document.getElementById("varibk").style.display = "none";
        document.getElementById("pop2").style.display = "block";

        var sqla = document.getElementById("sqla").innerHTML;

var xi = document.createElement("INPUT");
xi.setAttribute("type", "hidden");
xi.setAttribute("name", "valos[]");
xi.setAttribute("value", sqla);
document.getElementById("varita").appendChild(xi);

document.getElementById("as").value = document.getElementById('azsizo').innerHTML;
document.getElementById("ac").value = document.getElementById('azcolo').innerHTML;
document.getElementById("asy").value = document.getElementById('azty').innerHTML;

    });
         }

var fksizcl = 0;
var fkcolcl = 0;
var fkracl = 0;
var fkstocl = 0;
var fkdiscl = 0;

         function varifk(urlyi,nayli,tyyi){

            $.get("/Admin/fk_var.php",{
		url : urlyi,
        type : tyyi, 
        varina : nayli,
        ids : <?php echo $id; ?>,
	}, function(urlia){
        document.getElementById('varifk').innerHTML = urlia;
if(tyyi == "Size"){
    ++fksizcl;
    if(fksizcl > 1){
        document.getElementById("fst").value = "Size";
        document.getElementById("fksizo").append(","+nayli);
    }
    else{
        document.getElementById("fst").value = "Size";
        document.getElementById("fksizo").append(nayli);
    }
}

if(tyyi == "Color"){
    ++fkcolcl;
    if(fkcolcl > 1){
        document.getElementById("fct").value = "Color";
        document.getElementById("fkcolo").append(","+nayli);
    }
    else{
        document.getElementById("fct").value = "Color";
        document.getElementById("fkcolo").append(nayli);
    }
}

if(tyyi == "RAM"){
    ++fkracl;
    if(fkracl > 1){
        document.getElementById("fs1t").value = "RAM";
        document.getElementById("fkramzo").append(","+nayli);
    }
    else{
        document.getElementById("fs1t").value = "RAM";
        document.getElementById("fkramzo").append(nayli);
    }
}

if(tyyi == "Storage"){
    ++fkstocl;
    if(fkstocl > 1){
        document.getElementById("fs2t").value = "Storage";
        document.getElementById("fkstozo").append(","+nayli);
    }
    else{
        document.getElementById("fs2t").value = "Storage";
        document.getElementById("fkstozo").append(nayli);
    }
}

if(tyyi == "Display"){
    ++fkdiscl;
    if(fkdiscl > 1){
        document.getElementById("fs2t").value = "Display Size";
        document.getElementById("fkdiszo").append(","+nayli);
    }
    else{
        document.getElementById("fs3t").value = "Display Size";
        document.getElementById("fkdiszo").append(nayli);
    }
}

        document.getElementById("variaz").style.display = "none";
        document.getElementById("varifk").style.display = "block";
        document.getElementById("varibk").style.display = "none";
        document.getElementById("pop2").style.display = "block";
        var sql = document.getElementById("sql").innerHTML;

        var xi = document.createElement("INPUT");
        xi.setAttribute("type", "hidden");
        xi.setAttribute("name", "valos[]");
        xi.setAttribute("value", sql);
        document.getElementById("varita").appendChild(xi);

        document.getElementById("fs").value = document.getElementById('fksizo').innerHTML;
document.getElementById("fc").value = document.getElementById('fkcolo').innerHTML;
document.getElementById("fs1").value = document.getElementById('fkstozo').innerHTML;
document.getElementById("fs2").value = document.getElementById('fkramzo').innerHTML;
document.getElementById("fs3").value = document.getElementById('fkdiszo').innerHTML;

    });
         }

         function closes(){
             document.getElementById("pop").style.display = "none";
         }

         function closes2(){
             document.getElementById("pop2").style.display = "none";
         }

         </script>

<script>
         function load1(){
             document.getElementById("load1").style.display = "none";
         }
         </script>

<script  type="text/javascript">
        function Section()
        {
        var a = document.getElementById('section').value;
        document.getElementById('secc').value =  document.getElementById('section').value;
        if (a === "Men") {
            var array = ["Select Catgory", "Men^s_TopWear", "Men^s_BottomWear", "Men^s_Accessories","Men^s_FootWear", "Men^s_Ethnic_Wear", "Men^s_InnerWear", "Men^s_SleepWear"];
        }
        else if (a === "Women") {
            var array = ["Select Catgory", "Saree", "Women^s_Kurtis", "Women^s_Kurta_Sets", "Women^s_Suit", "Women^s_Dress_Material", "Women^s_Other_Ethnic_Wear", "Women^s_TopWear", "Women^s_BottomWear", "Women^s_InnerWear", "Women^s_SleepWear", "Women^s_Other_Ethnic_Wear"];
        }
        else{
            var array = [];
        }
        var string ="";
        for (i=0; i<array.length; i++) {
            string = string+"<option value="+array[i]+">"+array[i]+"</option>";
        }
        document.getElementById('category').innerHTML = string;
      
        }

        function Category()
        {
        var g = document.getElementById('category').value;
        document.getElementById('catt').value = document.getElementById('category').value;
        if (g === "Men^s_TopWear") {
            var print = ["Select_Sub-Catgory", "Men^s_T-Shirts", "Men^s_Shirts", "Men^s_WinterWear", "Men^s_Jackets", "Men^s_Sweater","Men^s_SweaterShirts"];
        }
        else if (g === "Men^s_BottomWear") {
            var print = ["Select Sub-Catgory", "Men^s_Track_Suits", "Men^s_Track_Pants", "Men^s_Jeans", "Men^s_Trouses"];
        }
        else if (g === "Men^s_Accessories") {
            var print = ["Select Sub-Catgory", "Men^s_Watches", "Men^s_Belts", "Men^s_Wallets","Men^s_Jewellery", "Men^s_Sunglasses", "Men^s_Bags"];
        }
        else if (g === "Men^s_FootWear") {
            var print = ["Select Sub-Catgory", "Men^_Sports_Shoes", "Men^s_Casual_Shoes", "Men^s_Formal_Shoes", "Men^s_Chappals", "Men^s_Sandals"];
        }
        else if (g === "Men^s_Ethnic_Wear") {
            var print = ["Select Sub-Catgory", "Men^s_Kurta", "Men^s_Kurta_Sets", "Men^s_Ethnic_Jackets", "Men^s_Ethnic_BottomWear" ];
        }
        else if (g === "Men^s_SleepWear") {
            var print = ["Select Sub-Catgory", "Men^s_Vests", "Men^s_Boxers"];
        }
        else if (g === "Men^s_InnerWear") {
            var print = ["Select Sub-Catgory", "Men^s_Underwear"];
        }

        else if (g === "Saree") {
            var print = ["Select Sub-Catgory", "Silk_Saree", "Cotton_Silk_Saree", "Cotton_Saree", "Georgette_Saree", "Chiffon_Saree", "Satin Saree", "Solid Saree", "Enbroidered Saree", "Zari Woven Saree"];
        }
        else if (g === "Women^s_Kurtis") {
            var print = ["Select Sub-Catgory", "Women^s_Cotton_Kurtis", "Women^s_Rayon_Kurtis", "Women^s_Anarkali_Kurtis", "Women^s_Embroidered_Kurtis", "Women^s_Solid_Kurtis"];
        }
        else if (g === "Women^s_Kurta_Sets") {
            var print = ["Select Sub-Catgory", "Women^s_Rayon_Kurtis_sets", "Women^s_Palazzo_Kurtis_sets", "Women^s_Embroidered_Kurtis_sets", "Women^s_Cotton_Kurtis_sets", "Women^s_Pant_Sets"];
        }
        else if (g === "Women^s_Suit") {
            var print = ["Select Sub-Catgory", "Women^s_Cotton_Suits", "Women^s_Embroidered_Suits", "Women^s_Jaipuri_Suits", "Women^s_Chanderi_Suits", "Women^s_Crepe_Suits"];
        }
        else if (g === "Women^s_Dress_Material") {
            var print = ["Select Sub-Catgory", "Women^s_Cotton_Dress_Matarial", "Women^s_Embroidered_Dress_Matarial", "Women^s_Jaipuri_Dress_Matarial", "Women^s_Chanderi_Dress_Matarial", "Women^s_Crepe_Dress_Matarial"];
        }
      
        else if (g === "Women^s_TopWear") {
            var print = ["Select Sub-Catgory", "Women^s_Dresses" , "Women^s_Tops", "Women^s_Tunics", "Women_Winterwear", "Women^s_Jumpsuits", "Women^s_Topwear_Sets"];
        }
        else if (g === "Women^s_BottomWear") {
            var print = ["Select Sub-Catgory","Women^s_Jeans", "Women^s_Jeggings", "Women^s_Palazzos", "Women^s_Shorts", "Women^s_Skirts"];
        }
        else if (g === "Women^s_InnerWear") {
            var print = ["Select Sub-Catgory", "Bras", "Briefs"];
        }
        else if (g === "Women^s_SleepWear") {
            var print = ["Select Sub-Catgory", "Nightsuits", "Badydolls"];
        }
        else if (g === "Women^s_Other_Ethnic_Wear") {
            var print = ["Select Sub-Catgory", "Blouses", "Dupattas", "Lehengas", "Ethnic_Bottomwear"];
        }   
         else {
             var print = [];
         }
        var joint ="";
        for (s=0; s<print.length; s++) {
            joint = joint+"<option value="+print[s]+">"+print[s]+"</option>";
        }
        document.getElementById('sub').innerHTML = joint;
      
        }
        
        function subca()
        {
        document.getElementById('subb').value = document.getElementById('sub').value;
        }
        </script>

<script src="/Assets/Js/JQuery.js"></script>
   <script src="tagmanager.min.js"></script>
    <script src="bootstrap3-typeahead.min.js"></script>  
<script>
  $(document).ready(function() {
    var tags = $(".tm-input").tagsManager();
    jQuery(".typeahead").typeahead({
      source: function (query, process) {
        return $.get('data.php', { query: query }, function (data) {
          data = $.parseJSON(data);
          return process(data);
        });
      },
      afterSelect :function (item){
        tags.tagsManager("pushTag", item);
      }
    });
  });
</script>
   </body>
</html>