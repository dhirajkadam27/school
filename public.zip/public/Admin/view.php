<?php
   ini_set('session.cookie_lifetime', 5184000);
   ini_set('session.gc_maxlifetime', 5184000);
   if(isset($_COOKIE[session_name()])){
       session_start();
   }
   else{
       session_start();
   }
   
   if(!isset($_SESSION["sell"]))
   {
       header("Location: /Admin");
   }

   $patho = $_SERVER['DOCUMENT_ROOT'];
   include $patho.'/Connection/config.php';
$display = "none";
$id = $_GET['id'];

if(isset($_POST['name'])){
    $name = $_POST['name'];
    $sql = "UPDATE `data` SET `name`='$name' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}
if(isset($_POST['descp'])){
    $descp = $_POST['descp'];
    $sql = "UPDATE `data` SET `descp`='$descp' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}
if(isset($_POST['mrp'])){
    $mrp = $_POST['mrp'];
    $mrp = str_ireplace("₹", "",  $mrp);
    $sql = "UPDATE `data` SET `original`='$mrp' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}
if(isset($_POST['price'])){
    $price = $_POST['price'];
    $price = str_ireplace("₹", "",  $price);
    $sql = "UPDATE `data` SET `price`='$price' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}

if(isset($_POST['hidden-tags'])){
    $tags = $_POST['hidden-tags'];
    $sql = "UPDATE `data` SET `tags`='$tags' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}

if(isset($_POST['del'])){
    $del = $_POST['del'];
    $sql = "UPDATE `data` SET `del`='$del' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}
if(isset($_POST['about'])){
    $about = $_POST['about'];
    $sql = "UPDATE `data` SET `about`='$about' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}



if(isset($_POST['delete'])){
    $im =$_POST['im'];
    $delete = $_POST['delete'];
    $delete = str_ireplace("http://localhost", "../",  $delete);
    if(unlink($delete)){
           
        $sql = "UPDATE `data` SET `$im`='' WHERE ID = '$id'";
        if(mysqli_query($conn, $sql)){
            $img = "done.png";
            $one = "Message Send";
            $display = "block";
         }
          else{
            $img = "failed.jpg";
         $one = "Message Not Send";
         $display = "block";
          }

     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }
}



if(isset($_FILES["file1"]["name"])){
        
    $image1=$_FILES["file1"]["name"];
	$tmp_name1=$_FILES["file1"]["tmp_name"];
    $ext1 = pathinfo( $image1, PATHINFO_EXTENSION);
    $image1 = date("jmYhis")."1".".".$ext1;
	$path1="../Assets/Images/".$image1;
	$file1=explode(".",$image1);
    $allowed=array("jpg","jpeg","png");
    move_uploaded_file($tmp_name1,$path1);
    
    $sql = "UPDATE `data` SET `image1`='$image1' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }

    }
    if(isset($_FILES["file2"]["name"])){
           
        $image2=$_FILES["file2"]["name"];
        $tmp_name2=$_FILES["file2"]["tmp_name"];
        $ext2 = pathinfo( $image2, PATHINFO_EXTENSION);
        $image2 = date("jmYhis")."2".".".$ext2;
        $path2="../Assets/Images/".$image2;
        $file2=explode(".",$image2);
        $allowed=array("jpg","jpeg","png");
        move_uploaded_file($tmp_name2,$path2); 
        $sql = "UPDATE `data` SET `image2`='$image2' WHERE ID = '$id'";
        if(mysqli_query($conn, $sql)){
            $img = "done.png";
            $one = "Message Send";
            $display = "block";
         }
          else{
            $img = "failed.jpg";
         $one = "Message Not Send";
         $display = "block";
          }
    
        }
    
        if(isset($_FILES["file3"]["name"])){
            
        $image3=$_FILES["file3"]["name"];
        $tmp_name3=$_FILES["file3"]["tmp_name"];
        $ext3 = pathinfo( $image3, PATHINFO_EXTENSION);
        $image3 = date("jmYhis")."3".".".$ext3;
        $path3="../Assets/Images/".$image3;
        $file3=explode(".",$image3);
        $allowed=array("jpg","jpeg","png");
        move_uploaded_file($tmp_name3,$path3);
         
    $sql = "UPDATE `data` SET `image3`='$image3' WHERE ID = '$id'";
    if(mysqli_query($conn, $sql)){
        $img = "done.png";
        $one = "Message Send";
        $display = "block";
     }
      else{
        $img = "failed.jpg";
     $one = "Message Not Send";
     $display = "block";
      }

        }
    
        if(isset($_FILES["file4"]["name"])){
            
        $image4=$_FILES["file4"]["name"];
        $tmp_name4=$_FILES["file4"]["tmp_name"];
        $ext4 = pathinfo( $image4, PATHINFO_EXTENSION);
        $image4 = date("jmYhis")."4".".".$ext4;
        $path4="../Assets/Images/".$image4;
        $file4=explode(".",$image4);
        $allowed=array("jpg","jpeg","png");
        move_uploaded_file($tmp_name4,$path4);
         
        $sql = "UPDATE `data` SET `image4`='$image4' WHERE ID = '$id'";
        if(mysqli_query($conn, $sql)){
            $img = "done.png";
            $one = "Message Send";
            $display = "block";
         }
          else{
            $img = "failed.jpg";
         $one = "Message Not Send";
         $display = "block";
          }
    
        }
    
        if(isset($_FILES["file5"]["name"])){
            
        $image5=$_FILES["file5"]["name"];
        $tmp_name5=$_FILES["file5"]["tmp_name"];
        $ext5 = pathinfo( $image5, PATHINFO_EXTENSION);
        $image5 = date("jmYhis")."5".".".$ext5;
        $path5="../Assets/Images/".$image5;
        $file5=explode(".",$image5);
        $allowed=array("jpg","jpeg","png");
        move_uploaded_file($tmp_name5,$path5);
         
        $sql = "UPDATE `data` SET `image5`='$image5' WHERE ID = '$id'";
        if(mysqli_query($conn, $sql)){
            $img = "done.png";
            $one = "Message Send";
            $display = "block";
         }
          else{
            $img = "failed.jpg";
         $one = "Message Not Send";
         $display = "block";
          }
    
        }
    
        if(isset($_FILES["file6"]["name"])){
            
        $image6=$_FILES["file6"]["name"];
        $tmp_name6=$_FILES["file6"]["tmp_name"];
        $ext6 = pathinfo( $image6, PATHINFO_EXTENSION);
        $image6 = date("jmYhis")."6".".".$ext6;
        $path6="../Assets/Images/".$image6;
        $file6=explode(".",$image6);
        $allowed=array("jpg","jpeg","png");
        move_uploaded_file($tmp_name6,$path6);
         
        $sql = "UPDATE `data` SET `image6`='$image6' WHERE ID = '$id'";
        if(mysqli_query($conn, $sql)){
            $img = "done.png";
            $one = "Message Send";
            $display = "block";
         }
          else{
            $img = "failed.jpg";
         $one = "Message Not Send";
         $display = "block";
          }
    
    
        }

$query = "SELECT * FROM data WHERE ID = ".$id."";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
$resul = mysqli_fetch_assoc($data); 
$resul = str_ireplace("^", "'", $resul);

?>

<html>
   <head>
      <title>Admin</title>
      <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
       padding-bottom: 60px;
         }
         img[alt="www.000webhost.com"]{
         display: none;
         } 
         .loadbg1{
         width: 100%;
         height: 100vh;
         background-color: white;
         position: fixed;
         z-index:1
         }
         .loader1{
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: flex;
         position: absolute;
         top:50%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         }
         .loader1 img{
         width:45px;
         height: 45px;
         margin:5px;
         border-radius: 50%;
         }
         .loader1 p{
         font-weight: 600;
         padding-left:20px ;
         }

         .nav{
         background:gold;
         width:100%;
         height:70px;
         position: fixed;
         z-index:4;
         display:flex;
         }
         .til{
         font-family: Verdana, Geneva, Tahoma, sans-serif;
         font-weight:bold;
         font-size:39px;
         color:black;
         margin-left:90px;
         line-height:70px
         }
         .slide{
         position:fixed;
         padding:17px 28px 22px 24px;
         }
         .slicon{
         width:30px;
         height:30px
         }
         .left{
         width:200px;
         height:100%;
         margin-top:23px;
         position:fixed;
         left:-200px;
         background:white;
         transition-property:left;
         transition-duration: 0.3s
         }
         .slide:hover .left{
         left:0;
         }
         .menu > ul{
         list-style:none;
         padding:0;
         margin:0;
         position:relative
         }
         .menu li{
         display:flex
         }
         .menu li > a{
         flex-basis:80%;
         text-decoration:none;
         color:black;
         display:block;
         padding:10px 29px;
         font-size:17px;
         }
         .menu li > span{
         font-size:15px;
         color:green;
         flex-basis:20%;
         position:absolute;
         right:0;
         margin-top:7px
         }
         .menu ul > li:hover{
         background: rgb(221, 221, 221);
         }
         /*Vertical Menu Bar End*/
         .sliderbg{
         width:100%;
         height:100%;
         background: #0a0a0a70;
         position:fixed;
         top:0;
         left:0;
         z-index:4;
         display:none
         }
.main{
    width: 100%;
    padding-top: 80px;
    display: flex
}
.all{
   width: 40%;
   display: flex;
}
.two{
   width: 58%;
margin-left: 2%
}
.my{
   width: 80%;
   display: block;
   text-align: center;
}
#not button{
   padding: 10px 20px;
    border: none;
    background: gold;
    font-size: 18px;
    font-weight: 500;
    margin-top: 10px;
}
.myimage{
   width: 100%;
            height: 400px;
        }
        .thumb{
           width: 20%;
            display: block;
            text-align: center;
        }
        .thumb img{
            width:70px;
            height: 70px;
            margin: 5px;
        }
        .no{
            width:70px;
            height: 70px;
            margin: 5px;
            background: gray
        }
        .no img{
            width: 50px;
              margin: 10px;
              height: 50px;
        }
        .brand{
           margin-top: 5px;
        }
.brand input{
   padding: 5px 8px;
    border-radius: 5px;
    border: none;
    outline-color: gold;
}
        .brand button{
         padding: 8px 13px;
    border: none;
    background: gold;
    border-radius: 5px;
    margin-left: 5px
        }
        .des{
           margin-top: 10px;
        }
        .des input{
   padding: 5px 8px;
    border-radius: 5px;
    border: none;
    outline-color: gold;
}
        .des button{
         padding: 8px 13px;
    border: none;
    background: gold;
    border-radius: 5px;
    margin-left: 5px
        }
        .price{
           margin-top: 10px;
        }
        .price input{
         width: 90px;
   padding: 5px 8px;
    border-radius: 5px;
    border: none;
    outline-color: gold;
}
        .price button{
         
         padding: 8px 13px;
    border: none;
    background: gold;
    border-radius: 5px;
    margin-left: 5px
        }
        .mrp{
           margin-top: 10px;
        }
        .mrp input{
         width: 90px;
   padding: 5px 8px;
    border-radius: 5px;
    border: none;
    outline-color: gold;
}
        .mrp button{
         padding: 8px 13px;
    border: none;
    background: gold;
    border-radius: 5px;
    margin-left: 5px
        }
        .specs pre{
            font-family: inherit;
           background: #fafafa;
        }
        .specs b{
           color: rgb(139, 139, 139)
        }
.specs textarea{
    display: none
}
        .specs button{
         padding: 8px 13px;
    border: none;
    background: gold;
    border-radius: 5px;
    margin-left: 5px
        }

        textarea{
   width: 400px;
    height: 150px;
    resize: none;
    border: none;
  }
  .about button{
   padding: 8px 13px;
    border: none;
    background: gold;
    border-radius: 5px;

  }


  /* tags input */

.typeahead{
    border: none;
    outline: none;
    font-size: 15px;

}
.tm-tag-remove{
    font-size: 20px;
    text-decoration: none;
    color: black;
    margin-left: 5px;
    font-family: monospace;
}
.tm-tag {
    padding: 8px 5px;
    background: gold;
    border-radius: 5px;
    margin-right: 5px;
    margin-bottom: 8px;
}
.form-group {
    width: 500px;
    padding: 10px 5px;
    border: 1px solid black;
    border-radius: 5px;
    display: flex;
    flex-wrap: wrap;
}

.form-group ul{
    position: absolute;
    list-style: none;
    z-index:5;
    background: white
}
.typeahead li{
    padding: 10px 10px;
    border: 1px solid #c1c1c1;
    font-size: 20px;
}
.typeahead strong{
    color: red
}
.typeahead li:hover{
    background: #c1c1c1
}
.typeahead a{
    text-decoration: none;
    color: black;
}

.tags button{
   padding: 8px 13px;
    border: none;
    background: gold;
    border-radius: 5px;
    margin-top: 10px;

  }

p{
    margin-bottom: 3px;
    margin-left: 4px;
}

#btnn, #btn1, #btn2, #btn3, #btn4, #btn5, #btn6{
    display: none
}

.upload-btn-wrapper {
  position: relative;
  overflow: hidden;
  display: inline-block;
  margin-top:10px;
  margin-bottom:10px;
  display:none
}

.btn {
  border: 2px dashed gray;
  border-radius: 8px;
  display: block
}
.texto{
   position: absolute;
    left: 26px;
    top: -18px;
    background: white;
    padding: 2px 10px;
    font-size: 20px;
}
.upload-btn-wrapper input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}
.upload-btn-wrapper img{
    max-width: 350px;
    height: 295px;
}
.upload-btn-wrapper button{
    padding: 8px 15px;
    border: none;
    background: gold;
    border-radius: 5px;
    margin-top: 20px;
    font-size:18px
}
.upload-btn-wrapper input{
    width: 100%;
    height: 100%;
}
form{
    display: inline
}




.upload{
            width: 300px;
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: block;
         text-align: center;
         position: fixed;
         top:40%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         }
         .upload img{
            width: 80px;
    height: 80px;
    margin: 10px;
    border-radius: 50%;
         }
         .say{
         font-weight: 600;
         padding-left:20px ;
         font-weight
         }
.upload button{
   padding: 10px 15px;
    font-size: 20px;
    background: gold;
    border: none;
    margin-bottom: 10px;
    margin-top: 20px;
}

#cke_texta{
    display: none
}
      </style>
   </head>
   <body onload="load1()">
      <div id="load1" class="loadbg1">
         <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
         </div>
      </div>
      <script>
         function jshover(){
         
             document.getElementById("ridss").style.visibility = 'visible';
         }
         function jshoverout(){
             document.getElementById("ridss").style.visibility = 'hidden';
         }
         
         function seaa(){
             document.getElementById("sein").style.display = 'block';
         }
             
      </script>
      <div id="navv" class="nav">
         <!--Vertical Slider Img-->
         <div   onmouseover="jshover()" onmouseout="jshoverout()" class="slide">
            <img class="slicon" src="/Assets/Icons/menu.png">
            <!--Vertical Slider Starts-->
            <div class="left">
               <!--Vertical Slider Menu Starts-->
               <div class="menu">
                  <ul>
                   <li><a href="/Admin/AddPro">Add Product</a></li>
                     <li><a href="/Admin/Product">Product</a></li>
                     <li><a href="/Admin/Users">Users</a></li>
                     <li><a href="/Admin/Orders">Orders</a></li>
                     <li><a href="/Admin/Address">Address</a></li>
                     <li><a href="/Admin/Search">Keyword</a></li>
                     <li><a href="/Admin/Notifications">Notifications</a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="ridss" class="sliderbg">
         </div>
         <!-- Vertical silder ends-->
         <div class="til">
           Product
         </div>
      </div>
      </div>
      <!--navbar Ends-->

      <div class="main">


         <div class="all">
            <div class="thumb">
                <?php
                if (!empty($resul["image1"])) {
                    echo '<img onclick="thumb1()" id="thumb1" src="/Assets/Images/'.$resul["image1"].'">';
                }
                else{
                    echo '<div onclick="fil1()" class="no"><img src="1.png"></div>';
                }
                if (!empty($resul["image2"])) {
                    echo '<img onclick="thumb2()" id="thumb2" src="/Assets/Images/'.$resul["image2"].'">';
                }
                else{
                    echo '<div onclick="fil2()" class="no"><img src="2.png"></div>';
                }
                if (!empty($resul["image3"])) {
                    echo '<img onclick="thumb3()" id="thumb3" src="/Assets/Images/'.$resul["image3"].'">';
                }
                else{
                    echo '<div onclick="fil3()" class="no"><img src="3.png"></div>';
                }
                if (!empty($resul["image4"])) {
                    echo '<img onclick="thumb4()" id="thumb4" src="/Assets/Images/'.$resul["image4"].'">';
                }
                else{
                    echo '<div onclick="fil4()" class="no"><img src="4.png"></div>';
                }
                if (!empty($resul["image5"])) {
                    echo '<img onclick="thumb5()" id="thumb5" src="/Assets/Images/'.$resul["image5"].'">';
                }
                else{
                    echo '<div onclick="fil5()" class="no"><img src="5.png"></div>';
                }
                if (!empty($resul["image6"])) {
                    echo '<img onclick="thumb6()" id="thumb6" src="/Assets/Images/'.$resul["image6"].'">';
                }
                else{
                    echo '<div onclick="fil6()" class="no"><img src="6.png"></div>';
                }
         ?>
               </div>
           <div id="my" class="my">
         <div id="not">
         <?php
         if (!empty($resul["image1"])) {
            echo ' <img id="myimage" src="/Assets/Images/'.$resul["image1"].'" class="myimage">
            <form method="post">
            <input type="hidden" id="im" name="im" value="1">
            <input type="hidden" id="dele" name="delete">
            <button>Delete</button>
            </form>';
         }
         else{
             echo ' <img id="myimage" src="1.png" class="myimage">';

         }
         ?>
            </div>

<div id="seen">


<div id="file1" class="upload-btn-wrapper">
             <label class="btn"><img id="imgg1" src="1.png" alt="your image" /></label>
             <form method="post" enctype="multipart/form-data"> 
             <input required type="file" onchange="fileo(this);" name="file1" />
             <button>Update</button>
             </form>
           </div>
<div id="file2" class="upload-btn-wrapper">
  <label class="btn"><img id="imgg2" src="2.png" alt="your image" /></label>
  <form method="post" enctype="multipart/form-data"> 
  <input required type="file" onchange="filet(this);" name="file2" />
  <button>Update</button>
  </form>
</div>

<div id="file3" class="upload-btn-wrapper">
  <label class="btn"><img id="imgg3" src="3.png" alt="your image" /></label>
  <form method="post" enctype="multipart/form-data"> 
  <input required type="file" onchange="fileh(this);" name="file3" />
  <button>Update</button>
  </form>
</div>

<div id="file4" class="upload-btn-wrapper">
  <label class="btn"><img id="imgg4" src="4.png" alt="your image" /></label>
  <form method="post" enctype="multipart/form-data"> 
  <input required type="file" onchange="filef(this);" name="file4" />
  <button>Update</button>
  </form>
</div>

<div id="file5" class="upload-btn-wrapper">
  <label class="btn"><img id="imgg5" src="5.png" alt="your image" /></label>
  <form method="post" enctype="multipart/form-data"> 
  <input required type="file" onchange="filev(this);" name="file5" />
  <button>Update</button>
  </form>
</div>

<div id="file6" class="upload-btn-wrapper">
  <label class="btn"><img id="imgg6" src="6.png" alt="your image" /></label>
  <form method="post" enctype="multipart/form-data"> 
  <input required type="file" onchange="filex(this);" name="file6" />
  <button>Update</button>
  </form>
</div>

</div>

   </div>
   
         </div>
        
         <div class="two">

<div class="brand">
    <p>Brand Name</p>
    <form method="post">
    
    <input type="text" id="inp" disabled name="name" value="<?php echo $resul["name"] ?>">
   <button id="btnn">Update</button>
        </form>
   <button onclick="bts()" id="bt">Edit</button>
</div>

<div class="des">
<p>Product Name</p>
<form method="post">
    
    <input type="text" id="inp1" disabled name="descp" value="<?php echo $resul["descp"] ?>">
   <button id="btn1">Update</button>
        </form>
  <button onclick="bts1()" id="bt1">Edit</button>
</div>

<div class="price">
<p>Price</p>
<form method="post">
    
    <input type="text" id="inp2" disabled name="price" value="₹<?php echo $resul["price"] ?>">
   <button id="btn2">Update</button>
        </form>
  <button onclick="bts2()" id="bt2">Edit</button>
</div>

<div class="mrp">
<p>mrp Name</p>
<form method="post">
    
    <input type="text" id="inp3" disabled name="mrp" value="₹<?php echo $resul["original"] ?>">
   <button id="btn3">Update</button>
        </form>
  <button onclick="bts3()" id="bt3">Edit</button>
</div>

<div class="specs">
    <p>Specifications</p>
      <pre id="pre">
      <?php echo $resul["del"]; ?>
      </pre>
      <form method="post">
      <textarea id="texta" name="del"><?php echo $resul["del"]; ?></textarea>
                <script>
                        CKEDITOR.replace('del');
                </script>
      <button id="btn4">Update</button>
      </form>
      <button onclick="bts4()" id="bt4">Edit</button>
    </div>

<div class="about">
<p>Product Detail</p>
<form method="post">
<textarea id="inp5" disabled name="about"><?php echo $resul["about"]; ?></textarea>
<br>  <button id="btn5">Update</button>
    </form>
<br> <button onclick="bts5()" id="bt5">Edit</button>
</div>


<div class="tags">
<p>Keywords</p>
<form method="post">
   <div class="form-group">
    
    <input id="inp6" disabled type="text" name="tags" placeholder="Type here.." value="<?php echo $resul["tags"]; ?>" class="typeahead tm-input form-control tm-input-info"/>
   </div>
   <button id="btn6">Update</button>
  
        </form>
  <button onclick="bts6()" id="bt6">Edit</button>

</div>


         </div>

      </div>

      


      <div style="display:<?php echo $display; ?> " id="upload" class="upload">
   <img id="imgg" src="/Assets/Icons/<?php echo $img; ?>">
   <div id="say" class="say"><?php echo $one ; ?></div>
   <button onclick="okay()">Okay</button>
</div>



<script src="/Assets/Js/JQuery.js"></script>
   <script src="tagmanager.min.js"></script>
    <script src="bootstrap3-typeahead.min.js"></script>  
<script>
  $(document).ready(function() {
    var tags = $(".tm-input").tagsManager();
    jQuery(".typeahead").typeahead({
      source: function (query, process) {
        return $.get('data.php', { query: query }, function (data) {
          data = $.parseJSON(data);
          return process(data);
        });
      },
      afterSelect :function (item){
        tags.tagsManager("pushTag", item);
      }
    });
  });
</script>

<script>

function fileo(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg1')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }


        function filet(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg2')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function fileh(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg3')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function filef(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg4')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function filev(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg5')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function filex(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg6')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

</script>

      <script>
         function load1(){
             document.getElementById("load1").style.display = "none";
         }
         
         function okay(){
             document.getElementById("upload").style.display = "none";
         }
      </script>

<script>
         
   function thumb1(){
       document.getElementById('myimage').src = document.getElementById('thumb1').src;
       document.getElementById('dele').value = document.getElementById('thumb1').src;
       document.getElementById('im').value = "image1";
       document.getElementById('seen').style.display = "none";
       document.getElementById('not').style.display = "block";
   }

   function thumb2(){
       document.getElementById('myimage').src = document.getElementById('thumb2').src;
       document.getElementById('dele').value = document.getElementById('thumb2').src;
       document.getElementById('im').value = "image2";
       document.getElementById('seen').style.display = "none";
       document.getElementById('not').style.display = "block";
   }

   function thumb3(){
       document.getElementById('myimage').src = document.getElementById('thumb3').src;
       document.getElementById('dele').value = document.getElementById('thumb3').src;
       document.getElementById('im').value = "image3";
       document.getElementById('seen').style.display = "none";
       document.getElementById('not').style.display = "block";
   }

   function thumb4(){
       document.getElementById('myimage').src = document.getElementById('thumb4').src;
       document.getElementById('dele').value = document.getElementById('thumb4').src;
       document.getElementById('im').value = "image4";
       document.getElementById('seen').style.display = "none";
       document.getElementById('not').style.display = "block";
   }

   function thumb5(){
       document.getElementById('myimage').src = document.getElementById('thumb5').src;
       document.getElementById('dele').value = document.getElementById('thumb5').src;
       document.getElementById('im').value = "image5";
       document.getElementById('seen').style.display = "none";
       document.getElementById('not').style.display = "block";
   }
   function thumb5(){
       document.getElementById('myimage').src = document.getElementById('thumb6').src;
       document.getElementById('dele').value = document.getElementById('thumb6').src;
       document.getElementById('im').value = "image6";
       document.getElementById('seen').style.display = "none";
       document.getElementById('not').style.display = "block";
   }

   function fil1(){
    document.getElementById('not').style.display = "none";
    document.getElementById('seen').style.display = "block";
    document.getElementById('file1').style.display = "block";
    document.getElementById('file2').style.display = "none";
    document.getElementById('file3').style.display = "none";
    document.getElementById('file4').style.display = "none";
    document.getElementById('file5').style.display = "none";
    document.getElementById('file6').style.display = "none";

   }

   function fil2(){
    document.getElementById('seen').style.display = "block";
    document.getElementById('not').style.display = "none";
    document.getElementById('file1').style.display = "none";
    document.getElementById('file2').style.display = "block";
    document.getElementById('file3').style.display = "none";
    document.getElementById('file4').style.display = "none";
    document.getElementById('file5').style.display = "none";
    document.getElementById('file6').style.display = "none";
   }

   function fil3(){
    document.getElementById('seen').style.display = "block";
    document.getElementById('not').style.display = "none";
    document.getElementById('file1').style.display = "none";
    document.getElementById('file2').style.display = "none";
    document.getElementById('file3').style.display = "block";
    document.getElementById('file4').style.display = "none";
    document.getElementById('file5').style.display = "none";
    document.getElementById('file6').style.display = "none";
   }


   function fil4(){
    document.getElementById('seen').style.display = "block";
    document.getElementById('not').style.display = "none";
    document.getElementById('file1').style.display = "none";
    document.getElementById('file2').style.display = "none";
    document.getElementById('file3').style.display = "none";
    document.getElementById('file4').style.display = "block";
    document.getElementById('file5').style.display = "none";
    document.getElementById('file6').style.display = "none";
   }


   function fil5(){
    document.getElementById('seen').style.display = "block";
    document.getElementById('not').style.display = "none";
    document.getElementById('file1').style.display = "none";
    document.getElementById('file2').style.display = "none";
    document.getElementById('file3').style.display = "none";
    document.getElementById('file4').style.display = "none";
    document.getElementById('file5').style.display = "block";
    document.getElementById('file6').style.display = "none";
   }

   function fil6(){
    document.getElementById('seen').style.display = "block";
    document.getElementById('not').style.display = "none";
    document.getElementById('file1').style.display = "none";
    document.getElementById('file2').style.display = "none";
    document.getElementById('file3').style.display = "none";
    document.getElementById('file4').style.display = "none";
    document.getElementById('file5').style.display = "none";
    document.getElementById('file6').style.display = "block";
   }


function bts(){
    document.getElementById('btnn').style.display = "inline";
    document.getElementById('bt').style.display = "none";
    document.getElementById('inp').disabled = false;
}

function bts1(){
    document.getElementById('btn1').style.display = "inline";
    document.getElementById('bt1').style.display = "none";
    document.getElementById('inp1').disabled = false;
}

function bts2(){
    document.getElementById('btn2').style.display = "inline";
    document.getElementById('bt2').style.display = "none";
    document.getElementById('texta').disabled = false;
}

function bts3(){
    document.getElementById('btn3').style.display = "inline";
    document.getElementById('bt3').style.display = "none";
    document.getElementById('inp3').disabled = false;
}

function bts4(){
    document.getElementById('btn4').style.display = "inline";
    document.getElementById('bt4').style.display = "none";
    document.getElementById('cke_texta').style.display = "block";
    document.getElementById('pre').style.display = "none";
}

function bts5(){
    document.getElementById('btn5').style.display = "inline";
    document.getElementById('bt5').style.display = "none";
    document.getElementById('inp5').disabled = false;
}

function bts6(){
    document.getElementById('btn6').style.display = "inline";
    document.getElementById('bt6').style.display = "none";
    document.getElementById('inp6').disabled = false;
}


</script>

   </body>
</html>