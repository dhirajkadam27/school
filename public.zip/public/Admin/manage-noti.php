<?php
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';


$user = $_POST['user'];
$title = $_POST['title'];
$msg = $_POST['msg'];
$seen = $_POST['seen'];
$date = $_POST['date'];

$sql = "INSERT INTO `notify`(`user`, `title`, `msg`, `datetime`, `seen`) VALUES ('$user','$title','$msg','$date','$seen')";
if(mysqli_query($conn, $sql)){
    echo "Yes";
}
else{
    echo "Not";
}

?>