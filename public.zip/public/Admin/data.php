<?php
    
    $patho = $_SERVER['DOCUMENT_ROOT'];
    include $patho.'/Connection/config.php';

    $sql = "SELECT * FROM search 
    WHERE src LIKE '%".$_GET['query']."%'"; 
   $dat = mysqli_query($conn, $sql);
   $total = mysqli_num_rows($dat);
    
    $data = [];
    if($total!=0){
			while($result = mysqli_fetch_assoc($dat)){
		  $cu = $result['src'];
         $data[] = $cu;
        }
    }

    echo json_encode($data);

?>