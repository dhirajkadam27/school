<?php
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';

date_default_timezone_set("Asia/Kolkata");

$orderId = $_POST['orderId'];
$track = $_POST['track'];
$date =  date("d/m/Y h:iA");
if($track == "Placed"){
    $sql = "UPDATE `orders` SET `track`='$track' ,`date2`='$date'  WHERE orderId = '$orderId'";
}
if($track == "Shipped"){
    $sql = "UPDATE `orders` SET `track`='$track' ,`date3`='$date'  WHERE orderId = '$orderId'";
}

if ($track == "Delivered"){
    $sql = "UPDATE `orders` SET `track`='$track' ,`date4`='$date'  WHERE orderId = '$orderId'";
}

if(mysqli_query($conn, $sql)){
    echo "Yes";
}
else{
    echo "Not";
}


$user = $_POST['userId'];
$title = $track;
$msg = "Your Order ".$orderId." Is Successfully ".$track.".It Well Be Delivered Soon.";
$seen = "Send";

$sqll = "INSERT INTO `notify`(`user`, `title`, `msg`, `datetime`, `seen`) VALUES ('$user','$title','$msg','$date','$seen')";
mysqli_query($conn, $sqll);
?>