<?php
$url = $_GET['url'];

$ch = curl_init();
$useragent="Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1";
curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$res = curl_exec($ch);
$res = trim(preg_replace('/[\t\n\r\s]+/', ' ', $res));
curl_close($ch);

$dom = new DomDocument();
@ $dom->loadHTML($res);
$xpath = new DOMXpath($dom);
$brand= "";
$size= "";
$mrp = "";
$colo = "";
$styl = "";
$img[2] = "";
$img[3] = "";
$img[4] = "";
$img[5] = "";
$img[6] = "";
$about1 = "";
$about2 = "";

$title = $dom->getElementById('productTitle')->textContent;
$title = str_replace("'","^",$title);

$prices = $dom->getElementById('priceblock_ourprice');
if(!empty($prices->textContent)){
   $price = $prices->textContent;
$price = preg_replace('/[^0-9.-]/','',$price);
}
$prices1 = $dom->getElementById('priceblock_saleprice');
if(!empty($prices1->textContent)){
   $price = $prices1->textContent;
$price = preg_replace('/[^0-9.]/','',$price);
}

$prices2 = $dom->getElementById('priceblock_dealprice');
if(!empty($prices2->textContent)){
   $price = $prices2->textContent;
$price = preg_replace('/[^0-9.]/','',$price);
}
$mrps = $xpath->query("//*[contains(@class, 'priceBlockStrikePriceString')]");
if(!empty($mrps->item(0)->textContent)){
   $mrp = $mrps->item(0)->textContent;
   $mrp =  preg_replace('/[^0-9.]/','',$mrp);
}

$sizes1val = $xpath->query("//*[contains(@id, 'variation_size_name')]/span/span/select/option[contains(@class, 'dropdownAvailable')]/@value");
$sizes1nam = $xpath->query("//*[contains(@id, 'variation_size_name')]/span/span/select/option[contains(@class, 'dropdownAvailable')]/@data-a-html-content");

foreach ($sizes1val as $val => $valo) {
$size0url = $sizes1val->item($val)->textContent;
$size0s = $sizes1nam->item($val)->textContent;
$size0sss = str_replace(' ',"_",$size0s);
$size0ur = explode(",", $size0url);
if(empty($size0url)){
   $size .= '<button onclick=vari("'.$url.'","'.$size0sss.'","Size")>'.$size0s.'</button>'; 
 }
  else{ 
   $size .= '<button style="background:lime" onclick=vari("https://www.amazon.in/dp/'.$size0ur[1].'?th=1&psc=1","'.$size0sss.'","Size")>'.$size0s.'</button>';
  }

}

$sizes2val = $xpath->query("//*[contains(@id, 'variation_size_name')]/ul/li/@title");
$sizes2nam = $xpath->query("//*[contains(@id, 'variation_size_name')]/ul/li/@data-dp-url");

foreach ($sizes2val as $vals => $valos) {
   $size0s = $sizes2val->item($vals)->textContent;
   $size0url = $sizes2nam->item($vals)->textContent;
   $size0 = str_replace('Click to select ',"",$size0s);
   $size0ss = str_replace(' ',"_",$size0);
if(empty($size0url)){
   $size .= '<button onclick=vari("'.$url.'","'.$size0ss.'","Size")>'.$size0.'</button>'; 
 }
  else{ 
   $size .= '<button style="background:lime" onclick=vari("https://www.amazon.in'.$size0url.'","'.$size0ss.'","Size")>'.$size0.'</button>';
  }

   }



   $colorna0 = $xpath->query("//*[contains(@id, 'variation_color_name')]/span/span/select/option[contains(@class, 'dropdownAvailable')]/@value");
   $colorurl0 = $xpath->query("//*[contains(@id, 'variation_color_name')]/span/span/select/option[contains(@class, 'dropdownAvailable')]/@data-a-html-content");
   
   foreach ($colorna0 as $nu0 => $valuea0) {
   $colurl0 = $colorna0->item($nu0)->textContent;
   $colna0 = $colorurl0->item($nu0)->textContent;
   $colos0 = str_replace('Click to select ',"",$colna0);
   $colos0s = str_replace(' ',"_",$colos0);
   $coloulo = explode(",", $colurl0);
   if(empty($colurl0)){
      $colo .= '<button onclick=vari("'.$url.'","'.$colos0s.'",Color")>'.$colos0.'</button>'; 
    }
     else{ 
      $colo .= '<button style="background:lime" onclick=vari("https://www.amazon.in/dp/'.$coloulo[1].'?th=1&psc=1","'.$colos0s.'",Color")>'.$colos0.'</button>';
     }
   
   }


$colorna = $xpath->query("//*[contains(@id, 'variation_color_name')]/ul/li/@title");
$colorurl = $xpath->query("//*[contains(@id, 'variation_color_name')]/ul/li/@data-dp-url");

foreach ($colorna as $nu => $valuea) {
$colna = $colorna->item($nu)->textContent;
$colurl = $colorurl->item($nu)->textContent;
$colos = str_replace('Click to select ',"",$colna);
$coloss = str_replace(' ',"_",$colos);
if(empty($colurl)){
   $colo .= '<button onclick=vari("'.$url.'","'.$coloss.'","Color")>'.$colos.'</button>'; 
 }
  else{ 
   $colo .= '<button style="background:lime" onclick=vari("https://www.amazon.in'.$colurl.'","'.$coloss.'","Color")>'.$colos.'</button>';
  }

}

$stylena = $xpath->query("//*[contains(@id, 'variation_style_name')]/ul/li/@title");
$styleurl = $xpath->query("//*[contains(@id, 'variation_style_name')]/ul/li/@data-dp-url");

foreach ($stylena as $num => $valueas) {
$stylna = $stylena->item($num)->textContent;
$stylurl = $styleurl->item($num)->textContent;
$style = str_replace('Click to select ',"",$stylna);
$styles = str_replace(' ',"_",$style);
if(empty($stylurl)){
   $styl .= '<button onclick=vari("'.$url.'","'.$styles.'","Style")>'.$style.'</button>';
 }
  else{ 
   $styl .= '<button style="background:lime" onclick=vari("https://www.amazon.in'.$stylurl.'","'.$styles.'","Style")>'.$style.'</button>';
  }

}




preg_match_all('/{"hiRes":"(.*?)"/is',$res, $imgs);
$lo = "1";
foreach($imgs[1] as $imgo){
   $img[$lo] = $imgo;
   $lo++;
}
$abouts = $dom->getElementById('feature-bullets');
if(!empty($abouts)){
   $about1 = str_replace("'","^",$abouts->C14N());

}


$aboutss = $dom->getElementById('productDetails_techSpec_section_1');
if(!empty($aboutss)){ 
   $about2 = str_replace("'","^",$aboutss->C14N());
}
$about = $about1.$about2;

echo '<div class="div">
<div class="one">Brand :</div>
<div id="azbr" class="two">'.$brand.'</div>
</div>
<div class="div">
<div class="one">Title :</div>
<div id="azti" class="two">'.$title.'</div>
</div>
<div class="div">
<div class="one">Price :</div>
<div id="azpr" class="two">'.$price.'</div>
</div>
<div class="div">
<div class="one">MRP :</div>
<div id="azmr" class="two">'.$mrp.'</div>
</div>
<div class="div">
<div class="one">Sizes :</div>
<div id="azsi" class="two">'.$size.'<div id="azsizo"></div></div>
</div>

<div class="div">
<div class="one">Colours :</div>
<div id="azcol" class="two">'.$colo.'<div id="azcolo"></div></div>
</div>

<div class="div">
<div class="one">Style :</div>
<div id="azcol" class="two">'.$styl.'<div id="azty"></div></div>
</div>

<div class="div">
<div class="one">Img1 :</div>
<div id="azi1" class="two">'.$img[1].'</div>
</div>
<div class="div">
<div class="one">Img2 :</div>
<div id="azi2" class="two">'.$img[2].'</div>
</div>
<div class="div">
<div class="one">Img3 :</div>
<div id="azi3" class="two">'.$img[3].'</div>
</div>
<div class="div">
<div class="one">Img4 :</div>
<div id="azi4" class="two">'.$img[4].'</div>
</div>
<div class="div">
<div class="one">Img5 :</div>
<div id="azi5" class="two">'.$img[5].'</div>
</div>
<div class="div">
<div class="one">Img6 :</div>
<div id="azi6" class="two">'.$img[6].'</div>
</div>
<div class="div">
<div class="one">About :</div>
<div id="azab" class="two">'.$about.'</div>
</div>';
?>