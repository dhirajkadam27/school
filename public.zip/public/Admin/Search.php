<?php
   ini_set('session.cookie_lifetime', 5184000);
   ini_set('session.gc_maxlifetime', 5184000);
   if(isset($_COOKIE[session_name()])){
       session_start();
   }
   else{
       session_start();
   }
   
   if(!isset($_SESSION["sell"]))
   {
       header("Location: /Admin");
   }
   
   $patho = $_SERVER['DOCUMENT_ROOT'];
   include $patho.'/Connection/config.php';

   $img = "";
$one = "";
$display = "none";

   if (isset($_POST['q'])) {
      $src = $_POST['q'];

      $sql = "INSERT INTO `search`(`src`) values('$src')";	

      if(mysqli_query($conn, $sql)){
     $img = "done.png";
     $one = "Message Send";
     $display = "block";
  }
   else{
     $img = "failed.jpg";
  $one = "Message Not Send";
  $display = "block";
   }

   }
 


   ?>
<html>
   <head>
      <meta name='viewport' content='width=device-width, initial-scale=1'>
      <title>Admin</title>

      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
         background: #f1f1f1;
         }
         img[alt="www.000webhost.com"]{
         display: none;
         } 
         .loadbg1{
         width: 100%;
         height: 100vh;
         background-color: white;
         position: fixed;
         z-index:1
         }
         .loader1{
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: flex;
         position: absolute;
         top:50%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         }
         .loader1 img{
         width:45px;
         height: 45px;
         margin:5px;
         border-radius: 50%;
         }
         .loader1 p{
         font-weight: 600;
         padding-left:20px ;
         }
         @media only screen and (min-width:320px) and (max-width: 480px){
         body{
         background: white;
         }
         .nav{
         background:gold;
         width:100%;
         height:50px;
         position: fixed;
         top: 0;
         z-index:5;
         display:flex;
         }
         .slicon{
         width:20px;
         height:20px;
         margin: 15px 15px 0px 15px
         }
         .left{
         width:80%;
         height:100%;
         position:fixed;
         top:0;
         left:-90%;
         z-index: 7;
         background:white;
         transition-property:left;
         transition-duration: 0.3s
         }
         .slide:hover .left{
         left:0;
         }
         .menu > ul{
         list-style:none;
         padding:0;
         margin:0;
         position:relative;
         }
         .menu li{
         display:flex
         }
         .menu li > a{
         flex-basis:80%;
         text-decoration:none;
         color:black;
         display:block;
         padding:10px 29px;
         font-size:20px;
         }
         .menu li > span{
         font-size:15px;
         color:green;
         flex-basis:20%;
         position:absolute;
         right:0;
         margin-top:7px
         }
         .menu ul > li:hover{
         background: rgb(221, 221, 221);
         }
         .til{
         font-size: 20px;
         font-weight: 500;
         line-height:50px
         }
         .sliderbg{
         width:100%;
         height:100%;
         background: #0a0a0a70;
         position:fixed;
         top:0;
         left:0;
         z-index:5;
         visibility:hidden;
         transition: visibility 0.1s;
         }
         }
         /* max size */
         @media only screen and (min-width:800px){
         .nav{
         background:gold;
         width:100%;
         height:70px;
         position: fixed;
         z-index:4;
         display:flex;
         }
         .til{
         font-family: Verdana, Geneva, Tahoma, sans-serif;
         font-weight:bold;
         font-size:39px;
         color:black;
         margin-left:90px;
         line-height:70px
         }
         .slide{
         position:fixed;
         padding:17px 28px 22px 24px;
         }
         .slicon{
         width:30px;
         height:30px
         }
         .left{
         width:200px;
         height:100%;
         margin-top:23px;
         position:fixed;
         left:-200px;
         background:white;
         transition-property:left;
         transition-duration: 0.3s
         }
         .slide:hover .left{
            left:0;
            box-shadow: 5px 16px 20px 2px #0000006b;
		 }
         .menu > ul{
         list-style:none;
         padding:0;
         margin:0;
         position:relative
         }
         .menu li{
         display:flex
         }
         .menu li > a{
         flex-basis:80%;
         text-decoration:none;
         color:black;
         display:block;
         padding:10px 29px;
         font-size:17px;
         }
         .menu li > span{
         font-size:15px;
         color:green;
         flex-basis:20%;
         position:absolute;
         right:0;
         margin-top:7px
         }
         .menu ul > li:hover{
         background: rgb(221, 221, 221);
         }
         /*Vertical Menu Bar End*/
         .sliderbg{
         width:100%;
         height:100%;
         background: #0a0a0a70;
         position:fixed;
         top:0;
         left:0;
         z-index:4;
         display:none
         }

         .main{
   position: absolute;
   top:100px;
   width:100%
}
.add{
    display: flex;
    justify-content: center;
    margin-left: 67px;
}
.add form{
    margin-bottom: 1px;
}
.add input{
    width: 250px;
    padding: 9px 5px;
    border-radius: 9px;
    border: 1px solid #b7b7b7;
}
.add button{
    font-size: 20px;
    padding: 6px 15px;
    background: gold;
    border: none;
    margin-left: 5px;
}
.sug{
    width: 250px;
    background: white;
    margin: 0 auto;
    max-height: 633px;
    overflow: hidden;
    display: none;
}
.sug ul{
    list-style: none;
    padding: 0;
    margin-top: 0;
}
.sug li{
    text-decoration: none;
    color: black;
    padding: 10px 6px;
    display: block;
}
.sug li:hover{
    background: #e0e0e0
}
.table{
   display: block;
    width: 300px;
    margin: 5px auto;
    margin-top: 30px;
    background: white;
}
.row{
   padding: 15px 10px;
}
.row:hover{
    background: #e0e0e0
}
         .upload{
            width: 300px;
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: block;
         text-align: center;
         position: fixed;
         top:40%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         display: none
         }
         .upload img{
            width: 80px;
    height: 80px;
    margin: 10px;
    border-radius: 50%;
         }
         .say{
         font-weight: 600;
         padding-left:20px ;
         font-weight
         }
.upload button{
   padding: 10px 15px;
    font-size: 20px;
    background: gold;
    border: none;
    margin-bottom: 10px;
    margin-top: 20px;
}



         }
      </style>
   </head>
   <body onload="load1()">
      <div id="load1" class="loadbg1">
         <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
         </div>
      </div>
      <script>
         function jshover(){
         
             document.getElementById("ridss").style.visibility = 'visible';
         }
         function jshoverout(){
             document.getElementById("ridss").style.visibility = 'hidden';
         }
         
         function seaa(){
             document.getElementById("sein").style.display = 'block';
         }
             
      </script>
      <div id="navv" class="nav">
         <!--Vertical Slider Img-->
         <div   onmouseover="jshover()" onmouseout="jshoverout()" class="slide">
            <img class="slicon" src="/Assets/Icons/menu.png">
            <!--Vertical Slider Starts-->
            <div class="left">
               <!--Vertical Slider Menu Starts-->
               <div class="menu">
                  <ul>
                 <li><a href="/Admin/Add">Add Product</a></li>
                     <li><a href="/Admin/Product">Product</a></li>
                     <li><a href="/Admin/Users">Users</a></li>
                     <li><a href="/Admin/Orders">Orders</a></li>
                     <li><a href="/Admin/Address">Address</a></li>
                     <li><a href="/Admin/Search">Keyword</a></li>
                     <li><a href="/Admin/Notifications">Notifications</a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="ridss" class="sliderbg">
         </div>
         <!-- Vertical silder ends-->
         <div class="til">
            Search Query
         </div>
      </div>
      </div>
      <!--navbar Ends-->



      <div class="main">
<div class="add">
<form method="post">
      <input type="text" autocomplete="off" id="search" placeholder="Add Search Query" name="q">
        <button>Add</button>
</form>
</div>
<div class="sug" id="que"></div>

<div class="table">
<?php
$query = "SELECT * FROM search" ;
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
if($total!=0){
    while($result = mysqli_fetch_assoc($data)){
       echo '<div class="row">'.$result['src'].'</div>';
    }
   }
   ?>
</div>


</div>


<div style="display:<?php echo $display; ?> " id="upload" class="upload">
   <img id="imgg" src="/Assets/Icons/<?php echo $img; ?>">
   <div id="say" class="say"><?php echo $one ; ?></div>
   <button onclick="okay()">Okay</button>
</div>


      <script>
         function load1(){
             document.getElementById("load1").style.display = "none";
         }
         
         function okay(){
             document.getElementById("upload").style.display = "none";
         }
      </script>
   </body>
</html>
<script src="/Assets/Js/JQuery.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
      $("#search").on("keyup", function(){
        var city = $(this).val();
        if (city !=="") {
          $.ajax({
            url:"query",
            type:"POST",
            cache:false,
            data:{city:city},
            success:function(data){
              $("#que").html(data);
              $("#que").fadeIn();
            }  
          });
        }else{
          $("#que").html("");  
          $("#que").fadeOut();
        }
      });

      // click one particular city name it's fill in textbox
      $('#que').on("click","li", function(){
        $('#search').val($(this).text());
        $('#que').fadeOut("fast");
      });
  });
</script>