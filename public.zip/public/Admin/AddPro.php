<?php 
   ini_set('session.cookie_lifetime', 5184000);
   ini_set('session.gc_maxlifetime', 5184000);
   if(isset($_COOKIE[session_name()])){
       session_start();
   }
   else{
       session_start();
   }

   $patho = $_SERVER['DOCUMENT_ROOT'];
   include $patho.'/Connection/config.php';
date_default_timezone_set("Asia/Kolkata");

$img = "";
$one = "";
$display = "none";

if(!isset($_SESSION["sell"]))
{
    header("Location: /Admin");
}

if(isset($_POST["code"]))
{

    $code = "MEs".$_POST['code'];
    $name = $_POST['name'];
    $descp = $_POST['descp'];
    $rating = $_POST['rating'];
    $price = $_POST['price'];
    $prevprice = $_POST['prevprice'];
    $del = "<pre>".$_POST['del']."</pre>";
    $about = $_POST['about'];
    $tags = $_POST['tags'];
    $size1 = $_POST['1'];
    $size2 = $_POST['2'];
    $size3 = $_POST['3'];
    $size4 = $_POST['4'];
    $size5 = $_POST['5'];
    $size6 = $_POST['6'];
    $size7 = $_POST['7'];
    $size8 = $_POST['8'];
    $size9 = $_POST['9'];
    $pri = $_POST['pri'];
    $cat = $_POST['cat'];
    $sub = $_POST['sub'];
    $date = date("d/m/Y");

    $name = str_ireplace("'", "^",  $name);
    $descp = str_ireplace("'", "^",   $descp);
    $tags = str_ireplace("'", "^", $tags );
    $about = str_ireplace("'", "^", $about );
    $cat = str_ireplace('_', ' ',  $cat);
    $sub = str_ireplace('_', ' ', $sub);

    if(!$_FILES["file1"]["name"] == ""){
        $image1=$_FILES["file1"]["name"];
        $tmp_name1=$_FILES["file1"]["tmp_name"];
        $ext1 = pathinfo( $image1, PATHINFO_EXTENSION);
        $image1 = date("jmYhis")."1".".".$ext1;
        $path1="../Assets/Images/".$image1;
        $file1=explode(".",$image1);
        $allowed=array("jpg","jpeg","png");

        move_uploaded_file($tmp_name1,$path1);
    }
    else{
        $image1 = "";
    }
    if(!$_FILES["file2"]["name"] == ""){
           
    $image2=$_FILES["file2"]["name"];
	$tmp_name2=$_FILES["file2"]["tmp_name"];
    $ext2 = pathinfo( $image2, PATHINFO_EXTENSION);
    $image2 = date("jmYhis")."2".".".$ext2;
	$path2="../Assets/Images/".$image2;
	$file2=explode(".",$image2);
    $allowed=array("jpg","jpeg","png");
    move_uploaded_file($tmp_name2,$path2);
    }
    else{
        $image2 = "";
    }

    if(!$_FILES["file3"]["name"] == ""){
        
    $image3=$_FILES["file3"]["name"];
	$tmp_name3=$_FILES["file3"]["tmp_name"];
    $ext3 = pathinfo( $image3, PATHINFO_EXTENSION);
    $image3 = date("jmYhis")."3".".".$ext3;
	$path3="../Assets/Images/".$image3;
	$file3=explode(".",$image3);
    $allowed=array("jpg","jpeg","png");
    move_uploaded_file($tmp_name3,$path3);
    }
    else{
        $image3 = "";
    }

    if(!$_FILES["file4"]["name"] == ""){
        
    $image4=$_FILES["file4"]["name"];
	$tmp_name4=$_FILES["file4"]["tmp_name"];
    $ext4 = pathinfo( $image4, PATHINFO_EXTENSION);
    $image4 = date("jmYhis")."4".".".$ext4;
	$path4="../Assets/Images/".$image4;
	$file4=explode(".",$image4);
    $allowed=array("jpg","jpeg","png");
    move_uploaded_file($tmp_name4,$path4);
    }
    else{
        $image4 = "";
    }

    if(!$_FILES["file5"]["name"] == ""){
        
    $image5=$_FILES["file5"]["name"];
	$tmp_name5=$_FILES["file5"]["tmp_name"];
    $ext5 = pathinfo( $image5, PATHINFO_EXTENSION);
    $image5 = date("jmYhis")."5".".".$ext5;
	$path5="../Assets/Images/".$image5;
	$file5=explode(".",$image5);
    $allowed=array("jpg","jpeg","png");
    move_uploaded_file($tmp_name5,$path5);
    }
    else{
        $image5 = "";
    }

    if(!$_FILES["file6"]["name"] == ""){
        
    $image6=$_FILES["file6"]["name"];
	$tmp_name6=$_FILES["file6"]["tmp_name"];
    $ext6 = pathinfo( $image6, PATHINFO_EXTENSION);
    $image6 = date("jmYhis")."6".".".$ext6;
	$path6="../Assets/Images/".$image6;
	$file6=explode(".",$image6);
    $allowed=array("jpg","jpeg","png");
    move_uploaded_file($tmp_name6,$path6);

    }
    else{
        $image6 = "";
    }

        
       
       
  
    
      

        $sql = "INSERT INTO `data`( `productid`, `name`, `descp`, `rating`, `price`, `original`,`size1`, `size2`, `size3`, `size4`, `size5`, `size6`, `size7`, `size8`, `size9`, `image1`, `image2`, `image3`, `image4`, `image5`, `image6`, `pri`, `cat`, `sub`, `del`, `about`, `tags`, `date`) values('$code', '$name','$descp',  '$rating', '$price', '$prevprice', '$size1', '$size2', '$size3', '$size4', '$size5', '$size6', '$size7', '$size8', '$size9', '$image1', '$image2', '$image3', '$image4', '$image5', '$image6', '$pri', '$cat', '$sub', '$del', '$about', '$tags', '$date')";	
  if(mysqli_query($conn, $sql)){
    $img = "done.png";
    $one = "Message Send";
    $display = "block";
}
  else{
    $img = "failed.jpg";
$one = "Message Not Send";
$display = "block";
  }
}
?>
<html>
   <head>
   <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
      <meta name='viewport' content='width=device-width, initial-scale=1'>
      <title>Admin</title>
   
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
         }
         img[alt="www.000webhost.com"]{
         display: none;
         } 
         .loadbg1{
         width: 100%;
         height: 100vh;
         background-color: white;
         position: fixed;
         z-index:1
         }
         .loader1{
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: flex;
         position: absolute;
         top:50%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         }
         .loader1 img{
         width:45px;
         height: 45px;
         margin:5px;
         border-radius: 50%;
         }
         .loader1 p{
         font-weight: 600;
         padding-left:20px ;
         }
         @media only screen and (min-width:320px) and (max-width: 480px){
         .nav{
         background:gold;
         width:100%;
         height:50px;
         position: fixed;
         top: 0;
         z-index:5;
         display:flex;
         }
         .slicon{
         width:20px;
         height:20px;
         margin: 15px 15px 0px 15px
         }
         .left{
         width:80%;
         height:100%;
         position:fixed;
         top:0;
         left:-90%;
         z-index: 7;
         background:white;
         transition-property:left;
         transition-duration: 0.3s
         }
         .slide:hover .left{
         left:0;
         }
         .menu > ul{
         list-style:none;
         padding:0;
         margin:0;
         position:relative;
         }
         .menu li{
         display:flex
         }
         .menu li > a{
         flex-basis:80%;
         text-decoration:none;
         color:black;
         display:block;
         padding:10px 29px;
         font-size:20px;
         }
         .menu li > span{
         font-size:15px;
         color:green;
         flex-basis:20%;
         position:absolute;
         right:0;
         margin-top:7px
         }
         .menu ul > li:hover{
         background: rgb(221, 221, 221);
         }
         .til{
         font-size: 20px;
         font-weight: 500;
         line-height:50px
         }
         .sliderbg{
         width:100%;
         height:100%;
         background: #0a0a0a70;
         position:fixed;
         top:0;
         left:0;
         z-index:5;
         visibility:hidden;
         transition: visibility 0.1s;
         }

         .main{
    position:absolute;
    top: 80px
}




         }


















         /* max size */
         @media only screen and (min-width:800px){
         .nav{
         background:gold;
         width:100%;
         height:70px;
         position: fixed;
         z-index:4;
         display:flex;
         }
         .til{
         font-family: Verdana, Geneva, Tahoma, sans-serif;
         font-weight:bold;
         font-size:39px;
         color:black;
         margin-left:90px;
         line-height:70px
         }
         .slide{
         position:fixed;
         padding:17px 28px 22px 24px;
         }
         .slicon{
         width:30px;
         height:30px
         }
         .left{
         width:200px;
         height:100%;
         margin-top:23px;
         position:fixed;
         left:-200px;
         background:white;
         transition-property:left;
         transition-duration: 0.3s
         }
         .slide:hover .left{
            left:0;
            box-shadow: 5px 16px 20px 2px #0000006b;
		 }
         .menu > ul{
         list-style:none;
         padding:0;
         margin:0;
         position:relative
         }
         .menu li{
         display:flex
         }
         .menu li > a{
         flex-basis:80%;
         text-decoration:none;
         color:black;
         display:block;
         padding:10px 29px;
         font-size:17px;
         }
         .menu li > span{
         font-size:15px;
         color:green;
         flex-basis:20%;
         position:absolute;
         right:0;
         margin-top:7px
         }
         .menu ul > li:hover{
         background: rgb(221, 221, 221);
         }
         /*Vertical Menu Bar End*/
         .sliderbg{
         width:100%;
         height:100%;
         background: #0a0a0a70;
         position:fixed;
         top:0;
         left:0;
         z-index:4;
         display:none
         }
.main{
    position:absolute;
    top: 120px;
    width: 100%;
}

.all{
    width: 300px;
    margin: 5px auto;
    position: relative;
    margin-bottom:25px
}
.text{
    position: absolute;
    margin-left: 20px;
    margin-top: -12px;
    background: white;
    padding: 2px 10px;
}
.all input{
    width: 100%;
    padding: 15px 10px;
    font-size: 20px;
    border-radius: 10px;
    border: 1px solid #b3b3b3;
    outline-color: gold;
}
.all select{
    width: 100%;
    padding: 15px 10px;
    font-size: 15px;
    border-radius: 10px;
    border: 1px solid #b3b3b3;
    outline-color: gold
}


.filing{
   width: 650px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
    margin: 5px auto;
    border: 1px solid #b3b3b3;
    border-radius: 10px;
    padding-top: 10px;
    padding-bottom: 10px;
    position: relative;
    margin-bottom:30px
}
  .upload-btn-wrapper {
  position: relative;
  overflow: hidden;
  display: inline-block;
  margin-top:10px;
  margin-bottom:10px
}

.btn {
  border: 2px dashed gray;
  border-radius: 8px;
  display: block
}
.texto{
   position: absolute;
    left: 26px;
    top: -18px;
    background: white;
    padding: 2px 10px;
    font-size: 20px;
}
.upload-btn-wrapper input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}
.upload-btn-wrapper img{
  width:150px;
}
textarea{
   width: 100%;
    height: 150px;
    resize: none;
  }
.alls{
   width: 300px;
    margin: 5px auto;
    position: relative;
    margin-bottom: 25px;
    text-align: center;
}
.alls button{
   width: 200px;
    padding: 15px 30px;
    font-size: 20px;
    border: none;
    background: gold;
}
.upload{
            width: 300px;
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: block;
         text-align: center;
         position: fixed;
         top:40%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         }
         .upload img{
            width: 80px;
    height: 80px;
    margin: 10px;
    border-radius: 50%;
         }
         .say{
         font-weight: 600;
         padding-left:20px ;
         font-weight
         }
.upload button{
   padding: 10px 15px;
    font-size: 20px;
    background: gold;
    border: none;
    margin-bottom: 10px;
    margin-top: 20px;
}


/* tags input */

.typeahead{
    border: none;
    outline: none;
    font-size: 15px;

}
.tm-tag-remove{
    font-size: 20px;
    text-decoration: none;
    color: black;
    margin-left: 5px;
    font-family: monospace;
}
.tm-tag {
    padding: 8px 5px;
    background: gold;
    border-radius: 5px;
    margin-right: 5px;
    margin-bottom: 8px;
}
.form-group {
    width: 300px;
    padding: 10px 5px;
    border: 1px solid black;
    border-radius: 5px;
    display: flex;
    flex-wrap: wrap;
    margin:20px auto;
}

.form-group ul{
    position: absolute;
    list-style: none;
    z-index:5;
    background: white
}
.typeahead li{
    padding: 10px 10px;
    border: 1px solid #c1c1c1;
    font-size: 20px;
}
.typeahead strong{
    color: red
}
.typeahead li:hover{
    background: #c1c1c1
}
.typeahead a{
    text-decoration: none;
    color: black;
}



         }
      </style>
   </head>
   <body onload="load1()">
      <div id="load1" class="loadbg1">
         <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
         </div>
      </div>
      <script>
         function jshover(){
         
             document.getElementById("ridss").style.visibility = 'visible';
         }
         function jshoverout(){
             document.getElementById("ridss").style.visibility = 'hidden';
         }
         
         function seaa(){
             document.getElementById("sein").style.display = 'block';
         }
             
      </script>
      <div id="navv" class="nav">
         <!--Vertical Slider Img-->
         <div   onmouseover="jshover()" onmouseout="jshoverout()" class="slide">
            <img class="slicon" src="/Assets/Icons/menu.png">
            <!--Vertical Slider Starts-->
            <div class="left">
               <!--Vertical Slider Menu Starts-->
               <div class="menu">
                  <ul>
                     <li><a href="/Admin/AddPro">Add Product</a></li>
                     <li><a href="/Admin/Product">Product</a></li>
                     <li><a href="/Admin/Users">Users</a></li>
                     <li><a href="/Admin/Orders">Orders</a></li>
                     <li><a href="/Admin/Address">Address</a></li>
                     <li><a href="/Admin/Search">Keyword</a></li>
                     <li><a href="/Admin/Notifications">Notifications</a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="ridss" class="sliderbg">
         </div>
         <!-- Vertical silder ends-->
         <div class="til">
            Add Product
         </div>
      </div>
      </div>
      <!--navbar Ends-->


<div class="main">


<form method="POST" enctype="multipart/form-data">
   <div class="all">
       <div class="text">
Product Id
       </div>
       <input type="text" required placeholder="Enter Product Id" name="code">
    </div>

    <div class="all">
       <div class="text">
Brand Name
       </div>
       <input type="text" required placeholder="Enter Brand Name" name="name">
    </div>

    <div class="all">
       <div class="text">
Product Name
       </div>
       <input type="text" required placeholder="Enter Product Name" name="descp">
    </div>


    <div class="all">
    <select name="rating" style="margin-bottom:20px">
<option>Select Rating</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
</div>

<div class="all">
       <div class="text">
Product Price
       </div>
       <input type="number" required placeholder="Enter Product Price" name="prevprice">
    </div>

    <div class="all">
       <div class="text">
Sale Price
       </div>
       <input type="number" required placeholder="Enter Sale Price" name="price">
    </div>
    
    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" required placeholder="Enter Size One" name="1">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="2">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="3">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="4">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="5">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="6">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="7">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="8">
    </div>

    <div class="all">
       <div class="text">
Size
       </div>
       <input  type="text" placeholder="Enter Size" name="9">
    </div>

<div class="filing">
<div class="texto">
Images
       </div>

<div class="upload-btn-wrapper">
  <label class="btn"><img id="imgg1" src="/Assets/Icons/drop.png" alt="your image" /></label>
  <input type="file" onchange="fileo(this);" name="file1" />
</div>

<div class="upload-btn-wrapper">
  <label class="btn"><img id="imgg2" src="/Assets/Icons/drop.png" alt="your image" /></label>
  <input type="file" onchange="filet(this);" name="file2" />
</div>

<div class="upload-btn-wrapper">
  <label class="btn"><img id="imgg3" src="/Assets/Icons/drop.png" alt="your image" /></label>
  <input type="file" onchange="fileh(this);" name="file3" />
</div>

<div class="upload-btn-wrapper">
  <label class="btn"><img id="imgg4" src="/Assets/Icons/drop.png" alt="your image" /></label>
  <input type="file" onchange="filef(this);" name="file4" />
</div>

<div class="upload-btn-wrapper">
  <label class="btn"><img id="imgg5" src="/Assets/Icons/drop.png" alt="your image" /></label>
  <input type="file" onchange="filev(this);" name="file5" />
</div>

<div class="upload-btn-wrapper">
  <label class="btn"><img id="imgg6" src="/Assets/Icons/drop.png" alt="your image" /></label>
  <input type="file" onchange="filex(this);" name="file6" />
</div>

</div>


<div class="all">
<select style="margin-bottom:20px" name="sec" id="section" onChange="Section()">
    <option>Select Section</option>
    <option value="Men">Men</option>
    <option value="Women">Women</option>
    <option value="Kids">Kids</option>
    <option value="Beauty">Beauty</option>
    <option value="Jewellery">Jewellery</option>
    <option value="Accessories">Accessories</option>
    <option value="Bags">Bags</option>
    <option value="Footwear">Footwear</option>
    </select>
<select style="margin-bottom:20px" name="cat" id="category" onChange="Category()">
        <option>Select Catgory</option>
    </select>
<select style="margin-bottom:20px" name="sub" id="sub">
        <option>Select Sub-Catgory</option>
    </select>
    </div>

<div class="all">
<textarea name="del"></textarea>
                <script>
                        CKEDITOR.replace('del');
                </script>
</div>
<div class="all">
<textarea name="about"></textarea>
</div>

<div class="form-group">
            <input type="text" name="tags" autocomplete="off" placeholder="Type here.." class="typeahead tm-input form-control tm-input-info"/>
        </div>

<div class="alls">
<button>Add</button>
</div>
</form>


</div>

<div style="display:<?php echo $display; ?> " id="upload" class="upload">
   <img id="imgg" src="/Assets/Icons/<?php echo $img; ?>">
   <div id="say" class="say"><?php echo $one ; ?></div>
   <button onclick="okay()">Okay</button>
</div>



<script src="/Assets/Js/JQuery.js"></script>
   <script src="tagmanager.min.js"></script>
    <script src="bootstrap3-typeahead.min.js"></script>  
<script>
  $(document).ready(function() {
    var tags = $(".tm-input").tagsManager();
    jQuery(".typeahead").typeahead({
      source: function (query, process) {
        return $.get('data.php', { query: query }, function (data) {
          data = $.parseJSON(data);
          return process(data);
        });
      },
      afterSelect :function (item){
        tags.tagsManager("pushTag", item);
      }
    });
  });
</script>

<script>

function fileo(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg1')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }


        function filet(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg2')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function fileh(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg3')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function filef(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg4')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function filev(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg5')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function filex(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imgg6')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

</script>

      <script>
         function load1(){
             document.getElementById("load1").style.display = "none";
         }
         
         function okay(){
             document.getElementById("upload").style.display = "none";
         }
      </script>

<script  type="text/javascript">
        function Section()
        {
        var a = document.getElementById('section').value;
        if (a === "Men") {
            var array = ["Select Catgory", "Men^s_TopWear", "Men^s_BottomWear", "Men^s_Accessories","Men^s_FootWear", "Men^s_Ethnic_Wear", "Men^s_InnerWear", "Men^s_SleepWear"];
        }
        else if (a === "Women") {
            var array = ["Select Catgory", "Saree", "Women^s_Kurtis", "Women^s_Kurta_Sets", "Women^s_Suit", "Women^s_Dress_Material", "Women^s_Other_Ethnic_Wear", "Women^s_TopWear", "Women^s_BottomWear", "Women^s_InnerWear", "Women^s_SleepWear", "Women^s_Other_Ethnic_Wear"];
        }
        else if (a === "Kids") {
            var array = ["Select Catgory", "Boys_+2_Years", "Girls_+2_Years", "Badies_0-2_Years", "Toys", "Kids_Accessories", "Baby_Care"];
        }
        else if (a === "Beauty") {
            var array = ["Select Catgory", "Makeup", "Skincare"];
        }

        else if (a === "Jewellery") {
            var array = ["Select Catgory", "Jewellery"];
        }
        else if (a === "Accessories") {
            var array = ["Select Catgory", " Men's_Accessories", "Women^s_Accessories", "Kids_Accessories"];
        }
        else if (a === "Footwear") {
            var array = ["Select Catgory", "Men^s_Footwear", "Women^s_Footwear","Kids_Footwear"];
        }
        else if (a === "Bags") {
            var array = ["Select Catgory", "Men^s_Bags", "Women^s_Bags","Kids_Bags"];
        }
        else{
            var array = [];
        }
        var string ="";
        for (i=0; i<array.length; i++) {
            string = string+"<option value="+array[i]+">"+array[i]+"</option>";
        }
        document.getElementById('category').innerHTML = string;
      
        }

        function Category()
        {
        var g = document.getElementById('category').value;
        if (g === "Men^s_TopWear") {
            var print = ["Select_Sub-Catgory", "Men^s_T-Shirts", "Men^s_Shirts", "Men^s_WinterWear", "Men^s_Jackets", "Men^s_Sweater","Men^s_SweaterShirts"];
        }
        else if (g === "Men^s_BottomWear") {
            var print = ["Select Sub-Catgory", "Men^s_Track_Suits", "Men^s_Track_Pants", "Men^s_Jeans", "Men^s_Trouses"];
        }
        else if (g === "Men^s_Accessories") {
            var print = ["Select Sub-Catgory", "Men^s_Watches", "Men^s_Belts", "Men^s_Wallets","Men^s_Jewellery", "Men^s_Sunglasses", "Men^s_Bags"];
        }
        else if (g === "Men^s_FootWear") {
            var print = ["Select Sub-Catgory", "Men^_Sports_Shoes", "Men^s_Casual_Shoes", "Men^s_Formal_Shoes", "Men^s_Chappals", "Men^s_Sandals"];
        }
        else if (g === "Men^s_Ethnic_Wear") {
            var print = ["Select Sub-Catgory", "Men^s_Kurta", "Men^s_Kurta_Sets", "Men^s_Ethnic_Jackets", "Men^s_Ethnic_BottomWear" ];
        }
        else if (g === "Men^s_SleepWear") {
            var print = ["Select Sub-Catgory", "Men^s_Vests", "Men^s_Boxers"];
        }
        else if (g === "Men^s_InnerWear") {
            var print = ["Select Sub-Catgory", "Men^s_Underwear"];
        }

        else if (g === "Saree") {
            var print = ["Select Sub-Catgory", "Silk_Saree", "Cotton_Silk_Saree", "Cotton_Saree", "Georgette_Saree", "Chiffon_Saree", "Satin Saree", "Solid Saree", "Enbroidered Saree", "Zari Woven Saree"];
        }
        else if (g === "Women^s_Kurtis") {
            var print = ["Select Sub-Catgory", "Women^s_Cotton_Kurtis", "Women^s_Rayon_Kurtis", "Women^s_Anarkali_Kurtis", "Women^s_Embroidered_Kurtis", "Women^s_Solid_Kurtis"];
        }
        else if (g === "Women^s_Kurta_Sets") {
            var print = ["Select Sub-Catgory", "Women^s_Rayon_Kurtis_sets", "Women^s_Palazzo_Kurtis_sets", "Women^s_Embroidered_Kurtis_sets", "Women^s_Cotton_Kurtis_sets", "Women^s_Pant_Sets"];
        }
        else if (g === "Women^s_Suit") {
            var print = ["Select Sub-Catgory", "Women^s_Cotton_Suits", "Women^s_Embroidered_Suits", "Women^s_Jaipuri_Suits", "Women^s_Chanderi_Suits", "Women^s_Crepe_Suits"];
        }
        else if (g === "Women^s_Dress_Material") {
            var print = ["Select Sub-Catgory", "Women^s_Cotton_Dress_Matarial", "Women^s_Embroidered_Dress_Matarial", "Women^s_Jaipuri_Dress_Matarial", "Women^s_Chanderi_Dress_Matarial", "Women^s_Crepe_Dress_Matarial"];
        }
      
        else if (g === "Women^s_TopWear") {
            var print = ["Select Sub-Catgory", "Women^s_Dresses" , "Women^s_Tops", "Women^s_Tunics", "Women_Winterwear", "Women^s_Jumpsuits", "Women^s_Topwear_Sets"];
        }
        else if (g === "Women^s_BottomWear") {
            var print = ["Select Sub-Catgory","Women^s_Jeans", "Women^s_Jeggings", "Women^s_Palazzos", "Women^s_Shorts", "Women^s_Skirts"];
        }
        else if (g === "Women^s_InnerWear") {
            var print = ["Select Sub-Catgory", "Bras", "Briefs"];
        }
        else if (g === "Women^s_SleepWear") {
            var print = ["Select Sub-Catgory", "Nightsuits", "Badydolls"];
        }
        else if (g === "Women^s_Other_Ethnic_Wear") {
            var print = ["Select Sub-Catgory", "Blouses", "Dupattas", "Lehengas", "Ethnic_Bottomwear"];
        }

        else if (g === "Boys_+2_Years") {
            var print = ["Select Sub-Catgory", "Boys_Sets", "Boys_Dresses", "Boys_Ethnicwear", "Boys_Nightwear", "Boys_Winterwear"];
        }
        else if (g === "Girls_+2_Years") {
            var print = ["Select Sub-Catgory", "Girls_Sets", "Girls_Dresses", "Girls_Ethnicwear", "Girls_Nightwear", "Girls_Winterwear"];
        }
        else if (g === "Badies_0-2_Years") {
            var print = ["Select Sub-Catgory","Baby_Sets", "Babies_Onesies", "Babies_Rompers", "Babies_Ethnicwear"]
        }
        else if (g === "Toys") {
            var print = ["Select Sub-Catgory", "Soft Toys",];
        }
        else if (g === "Kids_Accessories") {
            var print = ["Select Sub-Catgory", "Boys_hoes", "Girls_Shoes", "Boys_Stationery","Girls_Stationery", "Boys_Watches","Girls_Watches", "Boys_Bags", "Girls_Bags", "Boys_Backpacks", "Girls_Backpacks"];
        }
        else if (g === "Baby_Care") {
            var print = ["Select Sub-Catgory", "Bedding", "Blankets", "Diapers", "Newborn_Care"];
        }
        else if (g === "Makeup") {
            var print = ["Select Sub-Catgory","Face_MakeUp", "Eyes_MakeUp", "Lips_MakeUp", "Nails_MakeUp", "Makeup_Tools", "MakeUp_Appliances"];
        }
        else if (g === "Skincare") {
            var print = ["Select Sub-Catgory", "Facecare", "BathCare", "BodyCare", "HairCare", " Men_Grooming", "Fragnances"];
        }
        else if (g === "Jewellery") {
            var print = ["Select Sub-Catgory","Jewellery_Sets", "Mangalsutras", "Earrings", "Studs", "Bangles", "Bracelets", "Necklaces", "Chains", "Men_Jewellery", "Rings", "Anklets", "Toe_Rings"];
        }
        else if (g === "Women^s_Accessories") {
            var print = ["Select Sub-Catgory","Women^s_Watches", "Women^s_Wallets", "Women^s_Sunglasses", "Women^s_Bags","Women^s_Socks", "Women^s_Apparel_Accessories"];
        }

        else if (g === "Men^s_Accessories") {
            var print = ["Select Sub-Catgory", "Men^s_Watches", "Men^s_Belts", "Men^s_Wallets", "Men^s_Sunglasses", "Men^s_Bags"];
        }
        else if (g === "Men^s_Footwear") {
            var print = ["Select Sub-Catgory", "Men^s_Sports_Shoes", "Men^s_Casual_Shoes", "Men^s_Formal_Shoes", "Men^s_Chappals", "Men^s_Sandals"];
        }
        else if (g === "Kids_Footwear") {
            var print = ["Select Sub-Catgory","Boys_Shoes", "Girls_Shoes"];
        }
        else if (g === "Women^s_Footwear") {
            var print = ["Select Sub-Catgory","Women^s_Flats","Women^s_Heels", "Women^s_Sandals", "Women^s_Bellies", "Women^s_Juttis", "Women^s_Shoes", "Women^s Boots", "Women^s Flipflops"];
        }
        else if (g === "Women^s_Bags") {
            var print = ["Select Sub-Catgory", "Women^s_Handbags", "Women^s_Wallets", "Women^s_Clutches", "Women^s_Backpacks", "Women^s_Slingbags"];
        }
        else if (g === "Men^s_Bags") {
            var print = ["Select Sub-Catgory", "Men^s_Wallets", "Men^s_Backpacks"];
        }
        else if (g === "Kids_Bags") {
            var print = ["Select Sub-Catgory", "Boys_Bags", "Girls_Bags", "Boys_Backpacks", "Girls_Backpacks"];
        }
        
         else {
             var print = [];
         }
        var joint ="";
        for (s=0; s<print.length; s++) {
            joint = joint+"<option value="+print[s]+">"+print[s]+"</option>";
        }
        document.getElementById('sub').innerHTML = joint;
      
        }
        
        </script>
   </body>
</html>