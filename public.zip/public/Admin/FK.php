<?php
$url = $_GET['url'];
$about1 = "";
$about2 = "";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$res = curl_exec($ch);
$res = trim(preg_replace('/[\t\n\r\s]+/', ' ', $res));
curl_close($ch);

$dom = new DomDocument();
@ $dom->loadHTML($res);
$dom->preservewhiteSpace = false;
$xpath = new DOMXpath($dom);

$mrp = "";
$color = "";
$storage = "";
$ram = "";
$size = "";
$dis = "";
$img[2] = "";
$img[3] = "";
$img[4] = "";
$img[5] = "";
$img[6] = "";
$brand = "";
$brands = $xpath->query("//*[contains(@class, 'G6XhRU')]");
if(!empty($brands->item(0))){
    $brand = $brands->item(0)->textContent;
    $brand = str_replace("'","^",$brand);
}
$titles = $xpath->query("//*[contains(@class, 'B_NuCI')]");
$title = $titles->item(0)->textContent;
$title = str_replace("'","^",$title);

$prices = $xpath->query("//*[contains(@class, '_30jeq3 _16Jk6d')]");
$price = $prices->item(0)->textContent;
$price = preg_replace('/[^0-9.]/','',$price);
$mrps = $xpath->query("//*[contains(@class, '_3I9_wc _2p6lqe')]");
if(!empty($mrps->item(0)->textContent)){
    $mrp = $mrps->item(0)->textContent;
    $mrp = preg_replace('/[^0-9.]/','',$mrp);
}


$varis = $xpath->query("//*[contains(@class, '_22QfJJ')]");
foreach($varis as $as => $varo) {
   $vario = $varis->item($as)->C14N();
   
   $varity = new DomDocument();
@  $varity->loadHTML($vario);
$varitions = new DOMXpath($varity);
$cheva = $varitions->query("//*[contains(@class, '_22QfJJ')]/span/@id")->item(0)->textContent;
if($cheva == "Size"){
$sizes = $varitions->query("//*[contains(@class, '_1fGeJ5 _2UVyXR')]");
foreach ($sizes as $keyo => $valuse) {
  $sizeo = $sizes->item($keyo)->textContent;
  $sizeourl = $varitions->query("//*[contains(@class, '_1fGeJ5 _2UVyXR')]/@href")->item($keyo)->textContent;
  if(empty($sizeourl)){
    $size .= "<button>".$sizeo."</button>";   
  }
   else{
    $sizeoss = str_replace(" ","_",$sizeo);
    $size .= '<button style="background:lime" onclick=varifk("https://www.flipkart.com'.$sizeourl.'","'.$sizeoss.'","Size")>'.$sizeo.'</button>';   
   }

 }
}

if($cheva == "Color"){
    $colors = $varitions->query("//*[contains(@class, '_3V2wfe')]");
    foreach ($colors as $clo => $vace) {
      $colourl = $varitions->query("//*[contains(@class, '_3V2wfe')]/a/@href")->item($clo)->textContent;
      $colona = $varitions->query("//*[contains(@class, '_3V2wfe')]/div/div")->item($clo)->textContent;
        if(empty($colourl)){
            $color .= "<button>".$colona."</button>"; 
          }
           else{
            $colonass = str_replace(" ","_",$colona);
            $color .= '<button style="background:lime" onclick=varifk("https://www.flipkart.com'.$colourl.'","'.$colonass.'","Color")>'.$colona.'</button>';   
           }

     }
    }


    if($cheva == "Storage"){
        $storagess = $varitions->query("//*[contains(@class, '_1fGeJ5')]");
        foreach ($storagess as $stor => $valst) {
            $storagna = $storagess->item($stor)->textContent;
            $storagurl = $varitions->query("//*[contains(@class, '_1fGeJ5')]/@href")->item($stor)->textContent;
            if(empty($storagurl)){
                $storage .= "<button>".$storagna."</button>";   
              }
               else{
                $storagnass = str_replace(" ","_",$storagna);
                $storage .= '<button style="background:lime" onclick=varifk("https://www.flipkart.com'.$storagurl.'","'.$storagnass.'","Storage")>'.$storagna.'</button>';   
               }

         }
        }

        if($cheva == "RAM"){
            $rams = $varitions->query("//*[contains(@class, '_1fGeJ5')]");
            foreach ($rams as $stor => $valst) {
                $ramna = $rams->item($stor)->textContent;
                $ramurl = $varitions->query("//*[contains(@class, '_1fGeJ5')]/@href")->item($stor)->textContent;
                if(empty($ramurl)){
                    $ram .= "<button>".$ramna."</button>";  
                  }
                   else{
                    $ramnass = str_replace(" ","_",$ramna);
                    $ram .= '<button style="background:lime" onclick=varifk("https://www.flipkart.com'.$ramurl.'","'.$ramnass.'","RAM")>'.$ramna.'</button>';   
                   }

             }
            }


            if($cheva == "Display Size"){
                $displ = $varitions->query("//*[contains(@class, '_1fGeJ5')]");
                foreach ($displ as $diss => $valdis) {
                    $disna = $displ->item($diss)->textContent;
                    $disurl = $varitions->query("//*[contains(@class, '_1fGeJ5')]/@href")->item($diss)->textContent;
                    if(empty($disurl)){
                        $dis .= "<button>".$disna."</button>";  
                      }
                       else{
                        $disnass = str_replace(" ","_",$disna);
                        $dis .= '<button style="background:lime"  onclick=varifk("https://www.flipkart.com'.$disurl.'","'.$disnass.'","Display")>'.$disna.'</button>';   
                       }

                 }
                }


}



$imgs = $xpath->query("//*[contains(@class, '_20Gt85 _1Y_A6W _2_B7hD')]/div/div/@style");
$i = "1";
foreach ($imgs as $key => $value) {
$imgo = $imgs->item($key)->textContent;
$imgos =  str_replace("background-image:url(","",$imgo);
$imgg = explode("?",$imgos);
$imgd =  str_replace("/128","/800",$imgg[0]);
$img[$i] = $imgd;
$i++;
}

$abouts1 = $xpath->query("//*[contains(@class, '_3dtsli')]");
if(!empty($abouts1->item(0))){
    $about1 = $abouts1->item(0)->C14N();
    $about1 =  str_replace("'","^",$about1);
}
$abouts2 = $xpath->query("//*[contains(@class, '_2yIA0Y')]");
if(!empty($abouts2->item(0))){
    $about2 = $abouts2->item(0)->C14N();
    $about2 =  str_replace("'","^",$about2);
}
$about = $about1.$about2;

echo '<div class="div">
<div class="one">Brand :</div>
<div id="fkbr" class="two">'.$brand.'</div>
</div>
<div class="div">
<div class="one">Title :</div>
<div id="fkti" class="two">'.$title.'</div>
</div>
<div class="div">
<div class="one">Price :</div>
<div id="fkpr" class="two">'.$price.'</div>
</div>
<div class="div">
<div class="one">MRP :</div>
<div id="fkmr" class="two">'.$mrp.'</div>
</div>
<div class="div">
<div class="one">Sizes :</div>
<div id="fksi" class="two">'.$size.'<div id="fksizo"></div></div>
</div>
<div class="div">
<div class="one">Colours :</div>
<div id="fksi" class="two">'.$color.'<div id="fkcolo"></div></div>
</div>
<div class="div">
<div class="one">Storage :</div>
<div id="fksi" class="two">'.$storage.'<div id="fkstozo"></div></div>
</div>
<div class="div">
<div class="one">Ram :</div>
<div id="fksi" class="two">'.$ram.'<div id="fkramzo"></div></div>
</div>

<div class="div">
<div class="one">
<select>
<option>2GB and 32GB</option>
<option>3GB and 32GB</option>
<option>3GB and 64GB</option>
<option>4GB and 64GB</option>
<option>6GB and 64GB</option>
<option>6GB and 128GB</option>
<option>8GB and 128GB</option>
<option>8GB and 256GB</option>
</select>
</div>
<div id="fksi" class="two"><input type="text"><button>go</button></div>
</div>

<div class="div">
<div class="one">Display Size :</div>
<div id="fksi" class="two">'.$dis.'<div id="fkdiszo"></div></div>
</div>
<div class="div">
<div class="one">Img1 :</div>
<div id="fki1" class="two">'.$img[1].'</div>
</div>
<div class="div">
<div class="one">Img2 :</div>
<div id="fki2" class="two">'.$img[2].'</div>
</div>
<div class="div">
<div class="one">Img3 :</div>
<div id="fki3" class="two">'.$img[3].'</div>
</div>
<div class="div">
<div class="one">Img4 :</div>
<div id="fki4" class="two">'.$img[4].'</div>
</div>
<div class="div">
<div class="one">Img5 :</div>
<div id="fki5" class="two">'.$img[5].'</div>
</div>
<div class="div">
<div class="one">Img6 :</div>
<div id="fki6" class="two">'.$img[6].'</div>
</div>
<div class="div">
<div class="one">About :</div>
<div id="fkab" class="two">'.$about.'</div>
</div>';
?>