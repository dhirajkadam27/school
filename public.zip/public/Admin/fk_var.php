<?php
$url = $_GET['url'];
$type = $_GET['type'];
$vana = $_GET['varina'];
$vana = str_replace("_"," ", $vana);
$proid = $_GET['ids'];
$about1 = "";
$about2 = "";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$res = curl_exec($ch);
$res = trim(preg_replace('/[\t\n\r\s]+/', ' ', $res));
curl_close($ch);

$dom = new DomDocument();
@ $dom->loadHTML($res);
$dom->preservewhiteSpace = false;
$xpath = new DOMXpath($dom);

$mrp = "";
$color = "";
$storage = "";
$ram = "";
$size = "";
$img[2] = "";
$img[3] = "";
$img[4] = "";
$img[5] = "";
$img[6] = "";
$brand = "";
$brands = $xpath->query("//*[contains(@class, 'G6XhRU')]");
if(!empty($brands->item(0))){
    $brand = $brands->item(0)->textContent;
    $brand = str_replace("'","^",$brand);
}
$titles = $xpath->query("//*[contains(@class, 'B_NuCI')]");
$title = $titles->item(0)->textContent;
$title = str_replace("'","^",$title);

$prices = $xpath->query("//*[contains(@class, '_30jeq3 _16Jk6d')]");
$price = $prices->item(0)->textContent;
$price = preg_replace('/[^0-9.]/','',$price);
$mrps = $xpath->query("//*[contains(@class, '_3I9_wc _2p6lqe')]");
if(!empty($mrps->item(0)->textContent)){
    $mrp = $mrps->item(0)->textContent;
    $mrp = preg_replace('/[^0-9.]/','',$mrp);
}

$imgs = $xpath->query("//*[contains(@class, 'q6DClP')]/@style");
$i = "1";
foreach ($imgs as $key => $value) {
    $imgo = $imgs->item($key)->textContent;
    $imgos =  str_replace("background-image:url(","",$imgo);
    $imgg = explode("?",$imgos);
    $imgd =  str_replace("/128","/800",$imgg[0]);
    $img[$i] = $imgd;
    $i++;
}

$abouts1 = $xpath->query("//*[contains(@class, '_3dtsli')]");
if(!empty($abouts1->item(0))){
    $about1 = $abouts1->item(0)->C14N();
    $about1 =  str_replace("'","^",$about1);
}
$abouts2 = $xpath->query("//*[contains(@class, '_2yIA0Y')]");
if(!empty($abouts2->item(0))){
    $about2 = $abouts2->item(0)->C14N();
    $about2 =  str_replace("'","^",$about2);
}
$about = $about1.$about2;

echo '<div class="div">
<div class="one">Brand :</div>
<div id="fkbr" class="two">'.$brand.'</div>
</div>
<div class="div">
<div class="one">Title :</div>
<div id="fkti" class="two">'.$title.'</div>
</div>
<div class="div">
<div class="one">Price :</div>
<div id="fkpr" class="two">'.$price.'</div>
</div>
<div class="div">
<div class="one">MRP :</div>
<div id="fkmr" class="two">'.$mrp.'</div>
</div>

<div class="div">
<div class="one">Img1 :</div>
<div id="fki1" class="two">'.$img[1].'</div>
</div>
<div class="div">
<div class="one">Img2 :</div>
<div id="fki2" class="two">'.$img[2].'</div>
</div>
<div class="div">
<div class="one">Img3 :</div>
<div id="fki3" class="two">'.$img[3].'</div>
</div>
<div class="div">
<div class="one">Img4 :</div>
<div id="fki4" class="two">'.$img[4].'</div>
</div>
<div class="div">
<div class="one">Img5 :</div>
<div id="fki5" class="two">'.$img[5].'</div>
</div>
<div class="div">
<div class="one">Img6 :</div>
<div id="fki6" class="two">'.$img[6].'</div>
</div>
<div class="div">
<div class="one">About :</div>
<div id="fkab" class="two">'.$about.'</div>
</div>

<div id="sql">
INSERT INTO `variations`(`site`,`productid`,`url`, `type`, `variname`, `name`, `descp`, `original`, `mrp`, `img1`, `img2`, `img3`, `img4`, `img5`, `img6`, `about`) VALUES ('."'"."FK"."'".','."'".$proid."'".','."'".$url."'".','."'".$type."'".','."'".$vana."'".','."'".$brand."'".','."'".$title."'".','."'".$price."'".','."'".$mrp."'".','."'".$img[1]."'".','."'".$img[2]."'".','."'".$img[3]."'".','."'".$img[4]."'".','."'".$img[5]."'".','."'".$img[6]."'".', '."'".$about."'".')
</div>
';
?>