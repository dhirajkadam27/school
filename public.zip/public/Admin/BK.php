<?php
$url = $_GET['url'];

$ch = curl_init();
$useragent="Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1";
curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$res = curl_exec($ch);
$res = trim(preg_replace('/[\t\n\r\s]+/', ' ', $res));
curl_close($ch);


$img[2] = "";
$img[3] = "";
$img[4] = "";
$img[5] = "";
$img[6] = "";


$dom = new DomDocument();
@ $dom->loadHTML($res);
$xpath = new DOMXpath($dom);
$brand = "";
$title = $dom->getElementById('testProName')->textContent;
$title = str_replace("'","^",$title);

$price = $dom->getElementById('testNetProdPrice')->textContent;
$price = preg_replace('/[^0-9.]/','',$price);
$mrp = $dom->getElementById('testOriginalPrice')->textContent;
$mrp = preg_replace('/[^0-9.]/','',$mrp);
$sizes = $xpath->query("//*[contains(@class, 'eachSize   ')]");
$remove = $xpath->query("//*[contains(@class, 'eachSize   disableSize')]");
$i = "0";
$l = "0";
$size = array();
$remo = array();
foreach ($sizes as $key) {
    $size[] = $sizes->item($i)->textContent;
    $i++;
}
foreach ($remove as $remos) {
  $remo[] = $remove->item($l)->textContent;
  $l++;
}

$allsizes = array_diff($size,$remo);
$siall = implode(",",$allsizes);

$colors = $xpath->query("//*[contains(@class, 'multiColorBox clearfix')]");


$abouts = $xpath->query("//*[contains(@class, 'descriptionWarpper')]");
$about = $abouts->item(0)->textContent;
$about = str_replace("'","^",$about);
$about = str_replace("PRODUCT DESCRIPTION","",$about);
$about = str_replace("REGULAR FIT","<br><br><b>REGULAR FIT</b><br>",$about);
$about = str_replace("SINGLE JERSEY, 100% COTTON","<br><br><b>SINGLE JERSEY, 100% COTTON</b><br>",$about);
$about = str_replace("15 DAY RETURNS","<br><br><b>15 DAY RETURNS</b><br>",$about);

for ($oo=0; $oo < 6; $oo++) { 
  $imgs = $xpath->query("//*[contains(@id, 'testMainSlider-".$oo."')]/img/@data-src");
  $img[$oo] = $imgs->item(0)->textContent;
}
 


echo '<div class="div">
<div class="one">Brand :</div>
<div id="bkbr" class="two">'.$brand.'</div>
</div>
<div class="div">
<div class="one">Title :</div>
<div id="bkti" class="two">'.$title.'</div>
</div>
<div class="div">
<div class="one">Price :</div>
<div id="bkpr" class="two">'.$price.'</div>
</div>
<div class="div">
<div class="one">MRP :</div>
<div id="bkmr" class="two">'.$mrp.'</div>
</div>
<div class="div">
<div class="one">Sizes :</div>
<div id="bksi" class="two">'.$siall.'</div>
</div>
<div class="div">
<div class="one">Img1 :</div>
<div id="bki1" class="two">'.$img[1].'</div>
</div>
<div class="div">
<div class="one">Img2 :</div>
<div id="bki2" class="two">'.$img[2].'</div>
</div>
<div class="div">
<div class="one">Img3 :</div>
<div id="bki3" class="two">'.$img[3].'</div>
</div>
<div class="div">
<div class="one">Img4 :</div>
<div id="bki4" class="two">'.$img[4].'</div>
</div>
<div class="div">
<div class="one">Img5 :</div>
<div id="bki5" class="two">'.$img[5].'</div>
</div>
<div class="div">
<div class="one">Img6 :</div>
<div id="bki6" class="two">'.$img[6].'</div>
</div>
<div class="div">
<div class="one">About :</div>
<div id="bkab" class="two">'.$about.'</div>
</div>';
?>