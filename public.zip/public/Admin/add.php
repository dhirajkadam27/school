<?php 

$code = "https://images.meesho.com/images/products/19934601/a5644_512.jpg";

$code = str_ireplace("https://images.meesho.com/images/products/", "", $code);

$code = substr($code, 0, strpos($code, "/"));

echo $code;
?>