<?php
   ini_set('session.cookie_lifetime', 5184000);
   ini_set('session.gc_maxlifetime', 5184000);
   if(isset($_COOKIE[session_name()])){
       session_start();
   }
   else{
       session_start();
   }
   
   if(isset($_SESSION["sell"]))
   {
       header("Location: /AddPro");
   }

$display = "none";

if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $pass = $_POST['pass'];
    if($pass == "sellme"){
        $_SESSION['sell'] = "$name";
        header("Location: AddPro");
    }
    else{
        $display = "block";
    }
}
    ?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
body{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    padding: 0;
    margin: 0;
}
.div{
    display: block;
    text-align: center;
}
.div p{
    margin-top: 0;
    font-size: 30px;
    font-weight: 600;
    color: black;
    background-color: gold;
    padding: 10px 0;
}
form{
    width: 250px;
    margin: 5px auto;
    margin-top: 120px;
}
input{
    width: 200px;
    padding: 5px 10px;
    margin-bottom: 10px;
}
button{
    width: 80px;
    padding: 6px;
    font-size: 20px;
    font-weight: 600;
    border: none;
    background: gold;
}

.upload{
            width: 300px;
         box-shadow: 1px 1px 5px 1px rgb(169 169 169);
         display: block;
         text-align: center;
         position: fixed;
         top:40%;
         left: 50%;
         z-index: 10;
         border-radius: 10px;
         background: white;
         transform: translate(-50%, -50%);
         -webkit-transform: translate(-50%, -50%);
         -moz-transform: translate(-50%, -50%);
         -o-transform: translate(-50%, -50%);
         }
         .upload img{
            width: 80px;
    height: 80px;
    margin: 10px;
    border-radius: 50%;
         }
         .say{
         font-weight: 600;
         padding-left:20px ;
         font-weight
         }
.upload button{
   padding: 10px 15px;
    font-size: 20px;
    background: gold;
    border: none;
    margin-bottom: 10px;
    margin-top: 20px;
}
    </style>
</head>
<body>
    <div class="div">
        <p>Derbun Seller Panel</p>
        <form method="POST">
            <input type="text" name="name" placeholder="name">
            <input type="password" name="pass" placeholder="password">
            <button>Done</button>
        </form>
    </div>

    <div style="display:<?php echo $display; ?> " id="upload" class="upload">
        <img id="imgg" src="/Assets/Icons/failed.jpg">
        <div id="say" class="say">Falied</div>
        <button onclick="okay()">Okay</button>
     </div>

     <script>
         function okay(){
             document.getElementById("upload").style.display = "none";
         }
      </script>

</body>
</html>