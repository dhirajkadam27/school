<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
$id = $_GET['id'];

if(!isset($_SESSION['no'])){
    header("Location: /Login?ref=$_SERVER[PHP_SELF]");
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Notification</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
 <style>
body{
    padding: 0;
    margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;


}
img[alt="www.000webhost.com"]{
               display: none;
           } 
.nav{
    width: 100%;
    height: 50px;
    background: gold;
    display: flex;
}
.back{
    position: fixed;
    left: 0;
    top: 0;
    z-index: 5;
    background:gold
}
.back img{
    width: 30px;
    margin: 8px 10px;
}
.title{
    font-size: 24px;
    font-weight: 600;
    text-align: center;
    width: 100%;
    line-height: 50px
}
.main{
    width: 100%;
    position: fixed;
    top: 60px;
}

.msg{
    width: 100%;
    margin-top: 15px;
}
.head{
    width: 100%;
    position: relative;
    margin-top: 10px;
}
.dati{
    font-size: 15px;
    margin-top: 6px;
    width: 100%;
    text-align: center;
}
.cont{
    width: 85%;
    background: #f1f1f1;
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    margin: 10px auto;

}
    </style>
</head>
<body>
    <div class="nav">
        <div id="lonoz2" onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>
        <div id="title" class="title">
        </div>
    </div>

    <div class="main">
        

    <?php

$query = "SELECT * FROM notify where id = $id";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);

if ($result['seen'] = $id) {
            echo  '<div class="msg">
                    <div class="head"><div class="dati">'.$result['datetime'].'</div></div>
                    <div class="cont">'.$result['msg'].'</div>
                </div>';
        
}

$queryy = "UPDATE notify SET `seen`='Receive' where id = $id";
mysqli_query($conn, $queryy);

?>

<script>
  
  document.getElementById('title').innerHTML = "<?php echo $result['title'] ?>";
    </script>
    </div>

    <script>
  $("#lonoz2").click(function(){
        document.getElementById("load1").style.display = "block";
  });

</script>


</body>
</html>