<?php
$id = $_GET['id'];
$nameo = $_GET['name'];
$site = $_GET['site'];

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/config.php';
$nameos = str_replace("_"," ", $nameo);
$query = "SELECT * FROM variations where site='$site' AND productid='$id' AND variname='$nameos'";
$data = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($data);
echo "".$result['name']."~#~".$result['descp']."~#~".$result['original']."~#~".$result['mrp']."~#~".$result['about']."";


?>