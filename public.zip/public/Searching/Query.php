<?php	
	// include database connection file
	$patho = $_SERVER['DOCUMENT_ROOT'];
	include $patho.'/Connection/config.php';
	// autocomplete textbox jquery ajax in PHP
	if (isset($_POST['city'])) {

  		$output = "";
  		$city = $_POST['city'];
  		$query = "SELECT * FROM `search` WHERE src LIKE '%$city%'";
  		$data = mysqli_query($conn, $query);
		$total = mysqli_num_rows($data);

  		$output = '<ul class="list-unstyled">';		

  		if($total!=0){
			while($result = mysqli_fetch_assoc($data)){
		  $cu = $result['src'];
		  
		  $output .= '<a href="/Search?q='.("$cu").'"><li>'.("$cu").'</li></a>';
		
		}
  		}else{
  			  $output .= '<li></li>';
  		}
  		
	  	$output .= '</ul>';
	  	echo $output;
	}

?>
