
<!DOCTYPE html>
<html>
<head>
    <title>Legal</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
 <style>
body{
    padding: 0;
    margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
background: #f1f1f1

}
img[alt="www.000webhost.com"]{
               display: none;
           } 
.nav{
    width: 100%;
    height: 50px;
    background: gold;
    display: flex;
}
.back img{
    width: 30px;
    margin: 9px 10px;
}
.title{
    font-size: 27px;
    margin-left: 15px;
    font-weight: 600;
    line-height: 50px
}
.main{
    width: 90%;
    position: fixed;
    top: 75px;
    left:5%;
}

.main p{
margin-bottom:50px
}

.main p img{
width:20px
}

    </style>
</head>
<body>
    <div class="nav">
        <div onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>
        <div class="title">
           Help
        </div>
    </div>

    <div class="main">
        <b>Payment</b>
   <p> Cash on delivery option is available on every product.</p>
    
    <b>Orders</b>
    <p>To Track your, click on menu icon  <img src="/Assets/Icons/menu.png"> or click on Account icon <img src="/Assets/Icons/user g.png"> and the click on orders. </p>
    
    <b>Notifications</b>
    
    <p>If you want to see notifications related your orders and offers. Then click on menu icon  <img src="/Assets/Icons/menu.png"> or click on Account icon <img src="/Assets/Icons/user g.png"> and the click on notifications.</p>
    
    </div>


    <script>
  $("#lonoz2").click(function(){
        document.getElementById("load1").style.display = "block";
  });

</script>

</html>