<!DOCTYPE html>
<html>
<head>

<meta name='viewport' content='width=device-width, initial-scale=1'>

   <style>
       body{
           margin: 0;
           padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

       }

       input::-webkit-outer-spin-button, input::-webkit-inner-spin-button{
    -webkit-appearance: none;
    margin: 0;
  }
  input[type=number]{
    -moz-appearance: textfield;
  }
  
       img[alt="www.000webhost.com"]{
               display: none;
           } 
       @media only screen and (min-width:320px) and (max-width: 480px){

        .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 5;
            }
            .back img{
                width: 30px;
                height: 30px;
                margin-top: 8px;
                margin-right: 18px;
                margin-left: 10px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height: 50px;
            }
            .main{
            width:100%;
            height:100%;
            padding-top: 80px;
            }
            .top{
                text-align: center;
                font-size: 23px;
                font-weight: 600;
                margin-top: -32px;
                color: #ff8200;
                margin-bottom: 19px;
            }
            .all{
                width: 100%;
                padding: 50px 0;
            }
            .input{
                margin:5px auto;
               
            }
            .code{
                display: flex;
                justify-content: center;
            }
            #cap{
                width: 90px;
    text-align: center;
    padding: 10px;
    font-weight: 600;
    font-size: 20px;
    color: #ff0000;
    background: #c8f1fd;
    border: none;
            }
            .text{
                font-size: 11px;
                 text-align: center;
                 margin-bottom: 15px;
                 font-weight: 600;
                color: #8c8c8c;
            }
            .code img{
                width: 30px;
                height: 30px;
                margin-left: 17px;
                margin-right: -25px;
                margin-top: 8px;
            }
            .button{
                width: 100%;
            }
            .button input{
                display: block;
               margin: 15px auto;
               width:70%;
               height:30px
            }
            #capt{
                
    text-align: center;
    color: red;
    margin-bottom: 11px;
    margin-top: -15px;
    font-weight: 600;

            }
            .button button{
                display: block;
                margin: 5px auto;
                padding: 10px 40px;
                font-weight: 500;
                margin-top: 60px;
                font-size: 26px;
                border: none;
                border-radius: 5px;
                background: gold;
            }


       }


          /* max size */
          @media only screen and (min-width:800px){

       .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 5;
            }
            .back img{
                width: 30px;
    margin: 10px;
    margin-right: 25px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
              line-height: 50px;
            }
            .main{
            width:100%;
            height:100%;
            padding-top: 80px;
            }
            .top{
                text-align: center;
                font-size: 23px;
                font-weight: 600;
                margin-top: -32px;
                color: #ff8200;
                margin-bottom: 19px;
            }
            .all{
                width: 30%;
                margin:5px auto;
                box-shadow: 1px 1px 5px 2px #d0d0d0;
                padding: 50px 0;
            }
            .input{
                width: 80%;
                margin:5px auto;
               
            }
            .code{
                display: flex;
                justify-content: center;
            }
            #cap{
                width: 90px;
    text-align: center;
    padding: 10px;
    font-weight: 600;
    font-size: 20px;
    color: #ff0000;
    background: #c8f1fd;
    border: none;
            }
            .text{
                font-size: 11px;
                 text-align: center;
                 margin-bottom: 15px;
                 font-weight: 600;
                color: #8c8c8c;
            }
            .code img{
                width: 30px;
                height: 30px;
                margin-left: 17px;
                margin-right: -25px;
                margin-top: 8px;
            }
            .button{
                width: 100%;
            }
            .button input{
                display: block;
               margin: 15px auto;
               width:70%;
               height:30px
            }
            #capt{
                
    text-align: center;
    color: red;
    margin-bottom: 11px;
    margin-top: -15px;
    font-weight: 600;

            }
            .button button{
                display: block;
               margin: 5px auto;
               padding: 10px 40px;
               font-weight: 600;
               font-size: 15px;
               border: none;
               border-radius: 5px;
               background: gold;
            }

  }
   </style>
</head>
<body onload="loa()">

    <div class="head">
        <div onclick="window.history.back()" class="back">
        <img src="/Assets/Icons/arrowl.png">
    </div>
    <div class="title">
        Confirmation
    </div>
    </div>

    <div class="main">
        <div class="all">
              <div class="input">
                <div class="top">Confirmation</div>
<div id="capt"></div>
              <div class="text">Enter The Below Code To Confirm Your Order </div>
                      <div class="code">
                        
                        
                          <input id="cap" type="text" name="code">
                          <img onclick="rel()" src="/Assets/Icons/reload.png">
                         
                      </div>
                      <div class="button">
                          <input type="number" id="caps" placeholder="Enter The Above Characters">
                          <button onclick="check()">Confirm Order</button>
                      </div>
           
             </div>
        </div>
    </div>
    <script>
   function loa(){
       var alpha = ['1','2','3','4','5','6','7','8','9','0'];

       var a =  alpha[Math.floor(Math.random()*10)];
       var b =  alpha[Math.floor(Math.random()*10)];
       var c =  alpha[Math.floor(Math.random()*10)];
       var d = alpha[Math.floor(Math.random()*10)];

       var sum = a+b+c+d;

       document.getElementById('cap').value = sum;
   }
   function rel(){
       var alpha = ['1','2','3','4','5','6','7','8','9','0'];

       var a =  alpha[Math.floor(Math.random()*10)];
       var b =  alpha[Math.floor(Math.random()*10)];
       var c =  alpha[Math.floor(Math.random()*10)];
       var d = alpha[Math.floor(Math.random()*10)];

       var sum = a+b+c+d;

       document.getElementById('cap').value = sum;
   }
   function check(){
       var vali = document.getElementById('cap').value;
       var vall = document.getElementById('caps').value;
       if(vali == vall){
        window.location.replace('Done');
       }
       else{
           
        document.getElementById('capt').innerHTML = "Wrong Capctha Code";
        setInterval(() => {
            document.getElementById('capt').style.display = "none";
        }, 2000);
       }
   }
    </script>
</body>
</html>