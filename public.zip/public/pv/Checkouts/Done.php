<!DOCTYPE html>
<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1'>

    <title>Order Placed</title>
  <style>
             body{
                margin:0;
                padding:0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

  }
  img[alt="www.000webhost.com"]{
               display: none;
           } 

  @media only screen and (min-width:320px) and (max-width: 480px){
  .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 2;
                display:flex;
            }
            .back img{
                width: 30px;
               height: 30px;
               margin-left: 15px;
               margin-top: 8px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
               line-height: 50px;
                margin-left:19px
            }

            .main{
                text-align: center;
                margin-top: 50px;
                
            }
           .info{
            margin: 5px auto;
            margin-top: -345px;
           }
           .info img{
               width:150px;
               height: 150px;
               transition: all 0.5s;
           }
           .info p{
               font-size: 49px;
               font-weight: 700;
               margin:0;
           }
           .info h5{
           color: #848484;
           margin: 0;
           }
           
           .info button{
               padding:8px 39px ;
               background-color: gold;
               border: none;
               font-size: 25px;
               border-radius: 5px;
               margin-top: 15px;
           }
#imgg{
    width: 100%;
    height: 50vh;
    margin-top: 110px;
}

  }



  /* max size */
  @media only screen and (min-width:800px){

  .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 2;
                display:flex;
            }
            .back img{
                width: 30px;
    margin: 10px;
    margin-right: 25px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
               line-height: 50px;
            }
            .main{
                text-align: center;
                margin-top: 50px;
                position: relative;
            }
           .info{
               position: absolute;
               top:30%;
               left:40%
           }
           .info img{
               width:150px;
               height: 150px;
               transition: all 0.5s;
           }
           .info p{
               font-size: 49px;
               font-weight: 700;
               margin:0;
           }
           .info h5{
           color: #848484;
           margin: 0;
           }
           
           .info button{
               padding:8px 39px ;
               background-color: gold;
               border: none;
               font-size: 25px;
               border-radius: 5px;
               margin-top: 15px;
           }


  }
    </style>
</head>
<body onload="loa()">

<form id="done">
<input type="hidden" id="prodid" name="prodid">
<input type="hidden" id="prod" name="prod">
<input type="hidden" id="mrp" name="mrp">
<input type="hidden" id="price" name="price">
<input type="hidden" id="size" name="size">
<input type="hidden" id="qty" name="qty">
</form>

<div class="head">
        <div onclick="window.history.back()" class="back">
        <img src="/Assets/Icons/arrowl.png">
    </div>

    <div class="title">
        Order Placed
    </div>
    </div>


    <div class="main">
        <div class="gif">
            <img id="imgg" src="/Assets/Icons/done.gif">
            <div class="info">
                <img id="im" src="/Assets/Icons/loader.gif" alt="Message">
            <p id="msg"></p>
            <h5 id="msgg" style="margin-top: 15px;"></h5>
            <h5 id="subdis" style="color:#FF8E04;margin-top: 5px;"></h5>
            </div>
        </div>
    </div>

    <script src="/Assets/Js/JQuery.js"></script>
<script>
$(document).ready(function(){

    document.getElementById("prodid").value = sessionStorage.getItem('buyid');
    document.getElementById("prod").value = sessionStorage.getItem('sub');
    document.getElementById("mrp").value = sessionStorage.getItem('mrp');
    document.getElementById("price").value = sessionStorage.getItem('price');
    document.getElementById("size").value = sessionStorage.getItem('sizes');
    document.getElementById("qty").value = sessionStorage.getItem('qty');

       $.ajax({
           url: "final",
           type: "POST",
           data: $('#done').serialize(),
           success: function(datas){
        if(datas==1){
            document.getElementById("im").src = "/Assets/Icons/done.png";
            document.getElementById("msg").innerHTML = "Done";
            document.getElementById("msgg").innerHTML = "Your Order Has Been Placed Successfully.";
            var subdiss = sessionStorage.getItem('mrp') - sessionStorage.getItem('price');
        document.getElementById("subdis").innerHTML = "₹" + subdiss;
        document.getElementById("im").style.transform = "rotate(1080deg)";
              }
              else{
                document.getElementById("im").src = "/Assets/Icons/failed.jpg";
            document.getElementById("msg").innerHTML =  "Failed";
            document.getElementById("msgg").innerHTML = "Could Not Placed The Order.";
            document.getElementById("im").style.transform = "rotate(1080deg)";
              }
           },
           error: function(nodata){
            document.getElementById("im").src = "/Assets/Icons/failed.jpg";
            document.getElementById("msg").innerHTML =  "Failed";
            document.getElementById("msgg").innerHTML = "Could Not Placed The Order.";
            document.getElementById("im").style.transform = "rotate(1080deg)";
}

       });

});
</script>

</body>
</html>