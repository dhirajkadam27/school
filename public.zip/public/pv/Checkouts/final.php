<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

$no = $_SESSION['no'];

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';

date_default_timezone_set('Asia/Kolkata');
$date1 = date("d/m/Y h:iA");
$date2 = "";
$date3 = "";
$date4 = "";

$soy = "SELECT * FROM `users` where number = $no";
$us = mysqli_query($conn, $soy);
$net = mysqli_num_rows($us);
$resultno = mysqli_fetch_assoc($us);
if($net!=0){
        $name = $resultno['fn'];
}


$sr = 1;
$ze = 0;
   $proid = $_POST['prodid'];
   $pro = $_POST['prod'];
   $mrp = $_POST['mrp'];
   $price = $_POST['price'];
   $size = $_POST['size'];
   $proqty = $_POST['qty'];
   $dis = $proqty*$mrp - $proqty*$price;
   $track = "Ordered"; 
   $pro = str_ireplace("'", "^", $pro);
   $nu = substr($no ,8,10);
   $or =  date("jmYhis");
   $f = substr($name ,0,2);
   $f= strtoupper($f);
   $orderid = $or.$nu.$ze.$sr ;
         
   $sql = "INSERT INTO `orders` (`orderId`, `userId`, `productId`, `product`, `mrp`, `Price`, `qty`, `size`, `track`, `date1`, `date2`, `date3`, `date4`)  VALUES ('$orderid', '$no', '$proid', '$pro', '$mrp', '$price', '$proqty', '$size','$track', '$date1', '$date2', '$date3','$date4')";
   if(mysqli_query($conn, $sql)){
   echo "1";
   }
   else{
echo "0";
   }
?>