<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
date_default_timezone_set("Asia/Kolkata");
$no = $_SESSION['no'];

$display = "none";
$display1 = "none";
$view = "none";
$view1 = "none";

$subtotal = 0;
$grandtotal = 0;
$subdis = 0;

error_reporting(0);
$no = $_SESSION['no'];
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
$query = "SELECT * FROM address WHERE no = $no";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data); 
if (!empty($result["name"])) {
    $view = "flex";
    $id ="adr";
    $value = "yes";
}
elseif (empty($result["name"])) {
    $view1 = "flex";
    $id1 ="adr";
    $id ="adr1";
    $value = "no";
}
?>
<html>
    <head>
    <meta name='viewport' content='width=device-width, initial-scale=1'>

 <style>
            body{
                margin:0;
                padding:0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

  }

  img[alt="www.000webhost.com"]{
               display: none;
           } 

  .loadbg{
            width: 100%;
            height: 100%;
            background-color: white;
            position: absolute;
            top: 0;
            left: 0;
            display:none
        }
        .loader{
            width:150px;
            box-shadow: 1px 1px 5px 1px rgb(201, 201, 201);
            display: flex;
            position: absolute;
            top:50%;
            left: 50%;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader img{
            width:45px;
            height: 45px;
            margin-top: 5px;
            margin-left: 5px;
        }
        .loader p{
            font-weight: 600;
            padding-left:20px ;
        }

  @media only screen and (min-width:320px) and (max-width: 480px){
.head{
    display:none
}

.mai{
                position:absolute;
                top:50px;
                width:100%;
            }
            .part{
                width:100%;
                display: block;
                margin-top: 18px;
            }
            .part1{
                width:100%;
                margin-right: 19px;
                padding:0 0;
            }
            .prod{
                background-color: rgb(255, 255, 255);
            }
            .items{
                margin-bottom:15px;
                display:flex;
                background-color: rgba(228, 228, 228, 0.076);
                padding-bottom: 10px;
                padding-left: 15px;
                /* display: none; */
                position: relative;
            }
            .protit{
                font-weight: 600;
                margin-top:8px
            }
            .prosubtit{
                font-weight: 400;
                margin-top:2px;
                margin-bottom:8px;
                color: rgb(119, 119, 119);
            }
            .partdesc{
                margin-left:18px
            }
            .proimg img{
                width:150px;
                height:140px;
            }
            .prising{
                display:flex;
                margin-top:-5px;
                font-size: 11px;
            }
            .propri{
                font-size: 30px;
                font-weight: 500;
                margin-top: -3px;
            }
            .promrp{
                margin-top: 17px;
                margin-left:8px
            }
            .prodis{
                margin-top: 17px;
                margin-left:3px;
                color:red
            }
           
            .qtyfil{
                display: flex;
                margin-top: 40px;
                margin-left: -160px;
                padding-bottom: 5px;
            }
            .qsu{
                background-color: rgba(255, 217, 0, 0.076);
                outline: none;
                margin: 0 5px;
                padding: 3px 12px;
                font-size: 20px;
                border: 1px solid rgb(167, 167, 167);
                border-radius: 50%;
            }
            .qsu:hover{
                background:gold;
            }
            .qad:hover{
                background:gold;
            }
            .qad{
                background-color: rgba(255, 217, 0, 0.076);
                outline: none;
                margin: 0 5px;
                padding: 3px 12px;
                font-size: 20px;
                border: 1px solid rgb(167, 167, 167);
                border-radius: 50%;
            }
            .spinbtn{
                padding:1px 15px;

            }
            .sizecho{
                color:rgb(104, 104, 104)
            }
            .rebtn{
                border: 1px solid rgb(158, 158, 158);
                outline:none;
                width:100px;
                height: 30px;
                margin-left: 30px;
                border-radius: 2px;
                background-color: transparent;
            }
            .rebtn:hover{
                background-color:gold;
            }
            .remd{
                border-left: 1px solid rgb(172, 171, 171);
                margin-left: 19px;
            }
            .adds{
                width:100%;
                background-color: rgb(255, 255, 255);
                border-radius: 7px;
                position: relative;
            }
            .ade{
                margin-left: 20px;
            }
            .names{
                font-size: 20px;
            }
            .mno {
    font-size: 19px;
    margin-top: 10px;
}

            .delihead{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
               border-radius: 5px;
               margin-bottom: 15px;
               position: fixed;
               top:0;
            }
            #delih1{
z-index: 10;
            }
            .delihead p{
                font-size:22px;
                margin-top:8px;
                margin-left:5px;
                font-weight:600;
            }
            .arr p{
                display:none
         }
         .delihead button{
                visibility: hidden
         }
            .delihead img{
                width: 30px;
                height: 30px;
                margin-top: 8px;
                margin-left: 10px;
                margin-right: 15px;
            }
            .deliv{
                
    width: 100%;
    padding-bottom: 20px;
    border-bottom: 1px solid silver;
                display: none;
               
            }
            .editadd{
                width:100%;
                background:#00adff08;
                background-color: rgb(255, 255, 255);
                border-radius: 10px;
            }
            .editadd button{
                padding:8px 10px;
                font-weight:bold;
                background:#ff7600;
                border:none;
                outline:none;
                color:white;
                margin:15px 15px;
                margin-top:-5px;
                /* display: none; */
            }
            #cont4{
                display:none;
            }            
            .spinbtn{
                width: 50px;
                height: 30px;
                text-align: center;
            }
            .deliv button{
                /* padding:8px 10px;
                font-weight:bold;
                background:#ff7600;
                border:none;
                outline:none;
                color:white;
                margin:15px 0; */
            }
            .inpadd{
                text-align:center;
                display: none;
            }
            .inpadd input{
                width: 80%;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
            }
           
            .inpadd textarea{
                width: 80%;
    height: 130px;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
            }
            .btnsa button{
                width: 90%;
    padding: 13px 10px;
    font-size: 20px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    margin: 10px 5%;
    margin-top: 15px;
            }
            .inpa{
                text-align:center;
                display:none
            }
            .inpa input{
                width: 80%;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
            }
           
            .inpa textarea{
                width: 80%;
    height: 130px;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
            }
            .pay{
                width:100%;
                background:#00adff08;
                background-color: rgb(255, 255, 255);
            }
            #delih3{
                display: none
            }
            #delih2{
                visibility: hidden
            }
            .paym{
                width: 100%;
                text-align: center;
                display: none;
                font-size: 25px;
                font-weight: 600;
                margin-bottom: 25px;
            }
            .paym img{
                width: 30px;
                margin-bottom: -7px;
            }
            .paym label{
                margin-left: 10px;
            }
            .paym button {
    width: 90%;
    height: 50px;
    position: fixed;
    bottom: 10px;
    left: 0;
    margin-left: 5%;
    border: none;
    background: gold;
    font-size: 21px;
    font-weight: 600;
}


            .cont1{
        display: none

            }
            .cont4{
        display: none

            }
            .mocon{
    width:100%;
    position:fixed;
    bottom:0;
    display:flex;
    background: white;
    left:0;
}
.mopri{
    width: 50%;
    font-size: 22px;
    font-weight: 600;
    text-align: center;
    padding-top: 15px;
}
.mobtn {
    width: 50%;
    padding-top: 8px;
    padding-bottom: 9px;
}
.mobtn button{
    display: block;
    width: 90%;
    height: 42px;
    border: none;
    background: gold;
    margin-left: 5%;
    border-radius: 5px;
    font-size: 15px;
    font-weight: 600;
}
#edd {
    width: 150px;
    height: 50px;
    border: none;
    background: gold;
    font-size: 15px;
    font-weight: 600;
    margin-top: 23px;
    margin-left: 188px;
}
            #edad{
                display: none;
            }
            .cont2{
    padding: 9px 19px;
    width: 90%;
    height: 50px;
    position: fixed;
    bottom: 10px;
    left: 0;
    margin-left: 18px;
    border: none;
    background: gold;
    font-size: 21px;
    font-weight: 600;
    background: gold
}
            .chan1{
                background-color: rgb(255 118 0 / 52%);
    height: 30px;
    position: absolute;
    right: 29px;
    top: 5px;
    border: 2px solid #fff8f1;
    color: #ffffff;
    font-weight: 600;
    border-radius: 7px;
    outline: none;
    display: none;
            }
            .chan2{
                background-color: rgb(255 118 0 / 52%);
    height: 30px;
    position: absolute;
    right: 29px;
    top: 5px;
    border: 2px solid #fff8f1;
    color: #ffffff;
    font-weight: 600;
    border-radius: 7px;
    outline: none;
    display: none;
            }
            .btnsa{
                text-align: left;
            }
            .btns{
                text-align: left;
            }
            .btns button{
                width: 90%;
    padding: 13px 10px;
    font-size: 20px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    margin: 10px 5%;
    margin-top: 15px;
            }
            .part2{
                display: block
            }
            .order{
                width: 90%;
              padding: 10px 5%;
            }
            .order div{
                font-size: 20px;
                position: relative
            }
            
            .order span{
                font-size: 20px;
                position: absolute;
                right: 0
            }

            .order button{
                display: none
            }

            .error{
                width:100%;
                height:100%;
                position:absolute;
                top:50px;
                background:white;
                z-index:3;
            }

            
.error-sec{
                width: 100%;
    height:100%;
    background: white;
    position: fixed;
    top: 0;
    z-index: 1;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}

.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}
#addflex{
}
.mobifoot{
    width:100%;
    margin-top: 20px;
    padding-bottom: 90px;
}
.mofo{
    width: 50%;
    margin: 5px 25%;
    display: flex;
}
.foimg img{
    width:35px;
    padding-top: 1px;
}
.fosub{
    padding-left: 10px;
    font-size: 10px;
    font-weight: 500;
    color: #8c8c8c;
}







  }


  /* max size */
  @media only screen and (min-width:800px){

            .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 2;
            }
           

            .back img{
                transform: rotate(180deg);
                width:50px;
                height:50px
            }
            .title{
                font-size:25px;
                font-weight:bold;
                margin-top:7px
            }
            .mai{
                position:absolute;
                top:50px;
                width:100%;
            }
            .cou{
                margin-top:5px;
                margin-left: 35px;
            }
            .cou span{
                color:rgb(0, 177, 59);
            }
            .part{
                width:100%;
                display: flex;
                justify-content: center;
                margin-top: 18px;
            }
            .part1{
                width:64%;
                margin-right: 19px;
                padding:0 0;
                margin-bottom: 40px;
            }
            .prod{
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
            }
            .items{
                margin-bottom:15px;
                display:flex;
                background-color: rgba(228, 228, 228, 0.076);
                padding-bottom: 10px;
                padding-left: 15px;
                /* display: none; */
                position: relative;
            }
            .protit{
                font-weight: 600;
                margin-top:8px
            }
            .prosubtit{
                font-weight: 400;
                margin-top:2px;
                margin-bottom:8px;
                color: rgb(119, 119, 119);
            }
            .partdesc{
                margin-left:18px
            }
            .proimg img{
                width:150px;
                height:140px;
            }
            .prising{
                display:flex;
                margin-top:-5px
            }
            .propri{
                font-size: 30px;
                font-weight: 500;
                margin-top: -3px;
            }
            .promrp{
                margin-top: 9px;
                margin-left:8px
            }
            .prodis{
                margin-top: 9px;
                margin-left:3px;
                color:red
            }
           
            .qtyfil{
                display: flex;
                margin-top: 40px;
                margin-left: -160px;
                padding-bottom: 5px;
            }
            .qsu{
                background-color: rgba(255, 217, 0, 0.076);
                outline: none;
                margin: 0 5px;
                padding: 3px 12px;
                font-size: 20px;
                border: 1px solid rgb(167, 167, 167);
                border-radius: 50%;
            }
            .qsu:hover{
                background:gold;
            }
            .qad:hover{
                background:gold;
            }
            .qad{
                background-color: rgba(255, 217, 0, 0.076);
                outline: none;
                margin: 0 5px;
                padding: 3px 12px;
                font-size: 20px;
                border: 1px solid rgb(167, 167, 167);
                border-radius: 50%;
            }
            .spinbtn{
                padding:1px 15px;

            }
            .sizecho{
                color:rgb(104, 104, 104)
            }
            .rebtn{
                border: 1px solid rgb(158, 158, 158);
                outline:none;
                width:100px;
                height: 30px;
                margin-left: 30px;
                border-radius: 2px;
                background-color: transparent;
            }
            .rebtn:hover{
                background-color:gold;
            }
            .remd{
                border-left: 1px solid rgb(172, 171, 171);
                margin-left: 19px;
            }
            .adds{
                width:100%;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 7px;
                position: relative;
            }
          .cont4{
              display: none
          }
            .delihead{
                width:100%;
                height:40px;
                background:gold;
                display:flex;
               border-radius: 5px;
               margin-bottom: 15px;
               position: relative;
            }
            .delihead p{
                font-size:22px;
                margin-top:4px;
                margin-left:5px
            }
            .arr p{
             background-color: white;
             padding: 1px 5px;
             font-size: 18px;
             border-radius: 5px;
             margin:6px 5px ;
             margin-left: 15px;
         }
            .delihead img{
             display:none
            }
            .deliv{
                width:100%;
                height:150px;
                margin: 10px 19px;
                display: none;
               
            }
            .editadd{
                width:100%;
                background:#00adff08;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
            }
            .editadd button{
                padding:8px 10px;
                font-weight:bold;
                background:#ff7600;
                border:none;
                outline:none;
                color:white;
                margin:15px 15px;
                margin-top:-5px;
                /* display: none; */
            }
            .spinbtn{
                width: 50px;
                height: 30px;
                text-align: center;
            }
            .deliv button{
                padding:8px 10px;
                font-weight:bold;
                background:#ff7600;
                border:none;
                outline:none;
                color:white;
                margin:15px 0;
            }
            .inpadd{
                text-align:center;
                display: none;
            }
            .inpadd input{
                width:47%;
                height:30px;
                margin:15px 5px;
                outline-color:gold;
            }
           
            .inpadd textarea{
                width:95%;
                height:80px;
                resize:none;
                margin:15px 0;
                outline-color:gold
            }
            .inpa{
                text-align:center;
                display:none
            }
            .inpa input{
                width:47%;
                height:30px;
                margin:15px 5px;
                outline-color:gold;
            }
           
            .inpa textarea{
                width:95%;
                height:80px;
                resize:none;
                margin:15px 0;
                outline-color:gold
            }
            .pay{
                width:100%;
                background:#00adff08;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
            }
            .paym{
                width:90%;
                padding: 15px 20px;
                display: none;
                margin-top: -15px;
                font-size: 19px;
                font-weight: 600;
              padding-bottom: 30px;
            }
            .paym img{
                width: 65px;
               margin-bottom: -20px;
            }
            .paym label{
                margin-left: 9px;
               font-size: 25px;
            }
            .mocon{
                display: none
            }
            .cont1{
                padding: 9px 19px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    position: absolute;
    right: 26px;

            }
            .cont4{
                display: none;
                padding: 9px 19px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    position: absolute;
    right: 26px;

            }
            #edad{
                display: none;
            }
            .cont2{
                padding: 9px 19px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    position: absolute;
    right: 26px;

            }
            .chan1{
                background-color: rgb(255 118 0 / 52%);
    height: 30px;
    position: absolute;
    right: 29px;
    top: 5px;
    border: 2px solid #fff8f1;
    color: #ffffff;
    font-weight: 600;
    border-radius: 7px;
    outline: none;
    display: none;
            }
            .chan2{
                background-color: rgb(255 118 0 / 52%);
    height: 30px;
    position: absolute;
    right: 29px;
    top: 5px;
    border: 2px solid #fff8f1;
    color: #ffffff;
    font-weight: 600;
    border-radius: 7px;
    outline: none;
    display: none;
            }
            .btnsa{
                text-align: left;
            }
            .btns{
                text-align: left;
            }
            .btns button{
                padding: 8px 10px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    margin: 15px 15px;
    margin-top: -5px;
            }
            .part2{
                width:27%;
                height:250px;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
                position: relative;
                padding: 10px 0;
            }
            .order{
                position: absolute;
                left:5%;
                width: 90%;
            }
            .order span{
                position: absolute;
                right: 0;

            }
           .order button {
                width:90%; 
                height:40px; 
                font-weight: 600; 
                font-size: 15px;
                background-color: 
                gold;border:none;
                margin: 10px 15px;
                outline: none;
                margin-top: 20px;
                display: none;
            }
            .error{
                width:100%;
                height:100%;
                position:absolute;
                top:50px;
                background:white;
                z-index:3;
            }

            
.error-sec{
                width: 100%;
    height:100%;
    background: white;
    position: fixed;
    top: 0;
    z-index: 1;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}
.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}
.not{
    display:none
}
#oaa{
    display: block;
    width: 30px;
    margin: 5px 10px;
}
.mobifoot{
    display: none
}



  }
        </style>
    </head>
    <body onload="loading()">
        <?php
if(!isset($no)){
    $ref= "<script>  document.write(sessionStorage.getItem('ref')); </script>";
    header("Location: /Login?ref=".$ref."");
}


$proid = "<script>  document.write(sessionStorage.getItem('buyid')); </script>";
if(!isset($proid)) {
    $display = "block";
}

if (isset($proid)) {
    $img = "<script>  document.write(sessionStorage.getItem('img')); </script>";
    $nam = "<script>  document.write(sessionStorage.getItem('name')); </script>";
    $sub = "<script>  document.write(sessionStorage.getItem('sub')); </script>";
    $mrp = "<script>  document.write(sessionStorage.getItem('mrp')); </script>";
    $price = "<script>  document.write(sessionStorage.getItem('price')); </script>";
    $dis = "<script>  document.write(sessionStorage.getItem('dis')); </script>% OFF";
    $sizes = "<script>  document.write(sessionStorage.getItem('sizes')); </script>";
    $color = "<script>  document.write(sessionStorage.getItem('color')); </script>";
    $style = "<script>  document.write(sessionStorage.getItem('style')); </script>";
    if(empty($sizes)){
        $display1 = "block";
    }

}

?>

        <div class="head">
            <div id="lonoz2" onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrow.png">
        </div>
    
        <div class="title">
            Derbun
        </div>
        </div>
        <div style="display:<?php echo $display ?>" class="error">

        </div>
        <div class="mai" id="body">
        <div class="part">
            <div id="partt" class="part1">
               
                <div class="prod">
                    <div id="delih1" class="delihead"><div onclick="deda()" class="arr"><p>1</p></div><img onclick="window.history.back()" src="/Assets/Icons/arrowl.png"><p>Order Summary</p><button id="chan1" onclick="chan1()" class="chan1">Change</button></div>   
                    <div id="items" class="items">
                    <div class="partimg">
                    <div class="proimg"><img id="seimg" ></div>
                </div>
                <div class="partdesc">
                    <div class="protit"><?php echo  $nam ?></div>
                    <div class="prosubtit"><?php echo  $sub?></div>
                    <div class="prising">
                    <div class="propri">₹<?php echo  $price ?></div>
                    <div class="promrp"><strike>₹<?php echo  $mrp ?></strike></div>
                    <div class="prodis">   <?php echo  $dis ?></div>
                </div>
          
    <script>
    var sizes = sessionStorage.getItem('sizes');
    var color = sessionStorage.getItem('color');
var style = sessionStorage.getItem('style');

if(sizes !== ""){
    document.write('<div class="sizecho">Size : '+sizes+'</div>');
}

if(color !== ""){
    document.write('<div class="sizecho">Color : '+color+'</div>');
}

if(style !== ""){
    document.write('<div class="sizecho">Style : '+style+'</div>');
}
    </script>

                <div class="qtyfil">
                   <button class="qsu" onclick="sub()">-</button>
                    <input class="spinbtn" type="text" id="spin" value="1">
                    <button class="qsu" onclick="add()">+</button>
                    <div class="remd">
                <button class="rebtn" onclick="window.history.back()">Back</button>
                </div>
                <button onclick="cont1()" id="cont6" class="cont1">Continue</button>
                <button onclick="cont4()" id="cont7" class="cont4">Continue</button>
            </div>
            </div>
                <div class="mocon">
<div id="mopri" class="mopri"></div>
 <div class="mobtn"><button onclick="cont1()" id="cont1" class="cont1">Contiune</button><button onclick="cont4()" id="cont4" class="cont4">Contiune</button></div>
</div>
            </div>
            </div>

         
<script>
    function loading(){
        document.getElementById("seimg").src = sessionStorage.getItem('img');
        document.getElementById("subtotal").innerHTML = "₹" + sessionStorage.getItem('mrp');
        document.getElementById("grandtotal").innerHTML = "₹" + sessionStorage.getItem('price');
        document.getElementById("mopri").innerHTML = "₹" + sessionStorage.getItem('price');
        var subdiss = sessionStorage.getItem('mrp') - sessionStorage.getItem('price');
        document.getElementById("subdis").innerHTML = "₹" + subdiss;
        document.getElementById("orsa").innerHTML    = "You Have Saved ₹" + subdiss;
  }

    function add(){
                        document.getElementById("spin").value = n++;
                        document.getElementById("spin").value = n;
                        sessionStorage.setItem('qty', document.getElementById("spin").value);
                        document.getElementById("subtotal").innerHTML = "₹" + n*sessionStorage.getItem('mrp');
                        document.getElementById("grandtotal").innerHTML = "₹" + n*sessionStorage.getItem('price');
                        document.getElementById("mopri").innerHTML = "₹" + n*sessionStorage.getItem('price');
                        var subdiss = n*sessionStorage.getItem('mrp') - n*sessionStorage.getItem('price');
                        document.getElementById("subdis").innerHTML = "₹" + subdiss;
                        document.getElementById("orsa").innerHTML    = "You Have Saved ₹" + n*subdiss;
                    }
                    function sub(){
                        if(n>1){
                        document.getElementById("spin").value = --n;
                        document.getElementById("spin").value = n;
                        sessionStorage.setItem('qty', document.getElementById("spin").value);
                        document.getElementById("subtotal").innerHTML = "₹" + n*sessionStorage.getItem('mrp');
                        document.getElementById("grandtotal").innerHTML = "₹" + n*sessionStorage.getItem('price');
                        document.getElementById("mopri").innerHTML = "₹" + n*sessionStorage.getItem('price');
                        var subdiss = n*sessionStorage.getItem('mrp') - n*sessionStorage.getItem('price');
                        document.getElementById("subdis").innerHTML = "₹" + subdiss;
                        document.getElementById("orsa").innerHTML    = "You Have Saved ₹" + n*subdiss;
                        }
                    }

</script>



                    




               <div id="adds" class="adds">
                <div style="display:<?php echo $view ?>" id="delih2" class="delihead"><div onclick="deda()" class="arr"><p>2</p></div><img onclick="deliadd()" src="/Assets/Icons/arrowl.png"><p>Delivery Address</p><button id="chan2" onclick="chan2()"  class="chan2">Change</button></div>
                <div id="<?php echo  $id ?>" class="deliv">
                    <div class="ade">
  <?php
 echo '<div class="names"><b>'.$result["name"].'</b></div>
  <div class="mno">Mobile No : '.$no.'</div>
  <div class="mno">'.$result["address"].'</div>
  <div class="mno">'.$result["state"].'- <b>'.$result["pincode"].'</b></div>';

              
                ?>
                </div>
                <button id="edd" onclick="edit()" >Edit Address</button>
                <button onclick="cont2()" class="cont2" style="padding: 9px 19px;">Deliver Here</button>
                </div>
                

                </div>

                  <div id="edadd" class="editadd">
                <div id="edad" class="delihead"><div onclick="edi()" class="arr"><img id="oaa" src="/Assets/Icons/arrowl.png"></div><p>Edit Address</p></div>
               <div id="aa" class="inpadd">
               <form id="upda" class="adsform" method="post">
               <input type="text" name="name" value="<?php echo $result["name"]  ?>" placeholder="Name">
               <input type="tel" name="no1" value="<?php echo $no  ?>" disabled placeholder="10 Digit Mobile Number">
               <input type="tel" name="pin" value="<?php echo $result["pincode"]  ?>" placeholder="Pincode">
               <input type="text" value="<?php echo $result["city"]  ?>" name="city" placeholder="City">
               <textarea name="address" placeholder="Address"><?php echo $result["address"]  ?></textarea>
               <input type="text" value="<?php echo $result["location"]  ?>" name="location" placeholder="City/District/Town">
               <input type="text" value="<?php echo $result["state"]  ?>" name="state" placeholder="State">
               <input type="text" value="<?php echo $result["landmark"]  ?>" name="landmark" placeholder="LandMark">
               <input type="text" value="<?php echo $result["no2"]  ?>" name="no2" placeholder="Alternate Mobile No.">
               </form>
               <div class="respone"></div>
               <div class="btnsa">
               <button onclick="cont3()"  class="adsave">Update</button>
               </div>
               </div>
                </div>
                   

                   
      


               <div id="adds" class="adds">
                <div style="display:<?php echo $view1 ?>" id="addflex" class="delihead"><div onclick="deda()" class="arr"><p>2</p></div><img onclick="deliadds()" src="/Assets/Icons/arrowl.png"><p>Add Delivery Address</p></div>
               <div   id="<?php echo $id1 ?>" class="inpa">
               <form id="savads"  class="adsform">
               <input type="text" value="<?php echo $result["name"]  ?>"  name="name"  placeholder="Name">
               <input type="tel" name="no1" value="<?php echo $no  ?>" disabled placeholder="10 Digit Mobile Number">
               <input type="tel" value="<?php echo $result["pincode"]  ?>" name="pin"  placeholder="Pincode">
               <input type="text" value="<?php echo $result["city"]  ?>"  name="city" placeholder="City">
               <textarea name="address"  placeholder="Address"><?php echo $result["address"]  ?></textarea>
               <input type="text" value="<?php echo $result["location"]  ?>"  name="location" placeholder="City/District/Town">
               <input type="text" value="<?php echo $result["state"]  ?>" name="state" placeholder="State">
               <input type="text" value="<?php echo $result["landmark"]  ?>" name="landmark" placeholder="LandMark">
               <input type="text" value="<?php echo $result["no2"]  ?>" name="no2" placeholder="Alternate Mobile No.">
               </form>
               <div class="show"></div>
               <div class="btns">
               <button onclick="okay()" class="adrsave">Save Address</button>
               </div>
               </div>
                </div>


                <script src="/Assets/Js/JQuery.js"></script>

                <script>
$(document).ready(function(){
    $(".adsave").click(function(){
        $.ajax({
           url: "Checkouts/Update",
           type: "POST",
           data: $('#upda').serialize(),
           success: function(data){
            $(".ade").load('Checkouts/Display');
           }
       });
    });
});
</script>

                <script>
$(document).ready(function(){
    $(".adrsave").click(function(){
       $.ajax({
           url: "Checkouts/Save",
           type: "POST",
           data: $('#savads').serialize(),
           success: function(data){
            document.getElementById("adr").style.display = "none";
            document.getElementById("addflex").style.display = "none";
            document.getElementById("adr1").style.display = "block";
            document.getElementById("delih2").style.display = "flex";
            $(".ade").load('Checkouts/Display');
           }
       });
    });
});
</script>
<script>
$(document).ready(function(){
    $(".cont2").click(function(){
        $(".ade").load('Checkouts/Display');
        $(".loadbg").show();
    });
});
</script>
<script>
$(document).ready(function(){
    $(".adsave").click(function(){
        $(".ade").load('Checkouts/Display');
        $(".loadbg").show();
    });
});
</script>





                <script>

      var values = "<?php echo $value ; ?>" ;

if (window.matchMedia("(max-width: 480px)").matches) {
    
if (values == "yes") {
    function deliadd(){
                    document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("addflex").style.zIndex = "unset";
                       document.getElementById("delih1").style.zIndex = "11";
                }
                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.getElementById("addflex").style.zIndex = "11";
                       document.getElementById("delih1").style.zIndex = "unset";
                       document.getElementById("order").style.display = "none";

                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                    }

                    function chan2(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                    }

                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                    }
                   
                    function  payba(){
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("order").style.display = "none";
                     }

                    function cont2(){
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("adr1").style.display = "none";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr1").style.display = "none";
                    }
                   
}
   

if (values == "no") {
    function deliadd(){
                    document.getElementById("adr1").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("addflex").style.zIndex = "unset";
                       document.getElementById("delih1").style.zIndex = "11";
                       document.getElementById("cont1").style.display = "none";
                       document.getElementById("cont4").style.display = "block";

                }
                function deliadds(){
                    document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("addflex").style.zIndex = "unset";
                       document.getElementById("delih1").style.zIndex = "11";

                }
                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.getElementById("addflex").style.zIndex = "11";
                       document.getElementById("delih1").style.zIndex = "unset";
                       document.getElementById("order").style.display = "none";

                    }
                    function cont4(){
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.getElementById("addflex").style.zIndex = "11";
                       document.getElementById("delih1").style.zIndex = "unset";
                       document.getElementById("order").style.display = "none";

                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                    }

                    function chan2(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                    }

                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                    }
                   
                    function  payba(){
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("order").style.display = "none";
                     }

                    function cont2(){
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("adr1").style.display = "none";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr1").style.display = "none";
                    }


}



}


if (window.matchMedia("(min-width: 480px)").matches) {

    if (values == "yes") {
        function deliadd(){
                    document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("addflex").style.zIndex = "unset";
                       document.getElementById("delih1").style.zIndex = "11";
                }
                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.getElementById("addflex").style.zIndex = "11";
                       document.getElementById("delih1").style.zIndex = "unset";
                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                    }

                    function chan2(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                    }

                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                    }
                   
                    function  payba(){
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("order").style.display = "none";
                     }

                    function cont2(){
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("adr1").style.display = "none";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                    }
            
    }


    if (values == "no") {

        function deliadd(){
                    document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("addflex").style.zIndex = "unset";
                       document.getElementById("delih1").style.zIndex = "11";
                }
                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.getElementById("addflex").style.zIndex = "11";
                       document.getElementById("delih1").style.zIndex = "unset";
                    }
                    function cont4(){
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.getElementById("addflex").style.zIndex = "11";
                       document.getElementById("delih1").style.zIndex = "unset";
                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "flex";
                       document.getElementById("cont6").style.display = "none";
                       document.getElementById("cont7").style.display = "block";

                    }

                    function chan2(){
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                    }

                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                    }
                   
                    function  payba(){
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("order").style.display = "none";
                     }

                    function cont2(){
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("order").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("adr1").style.display = "none";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("adr1").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                    }
                    function okay(){
                    

                    }


    }
 


}

          
                    function place(){
                        window.location.replace('Checkouts/Confirm');
                    }
                    var n =  document.getElementById("spin").value;
                



                </script>



<div id="pay" class="pay">
    <div id="delih3" class="delihead"><div onclick="deda()" class="arr"><p>3</p></div><img onclick="payba()" src="/Assets/Icons/arrowl.png"><p>Payment</p></div>
    <div id="paym" class="paym">
    <img src="/Assets/Icons/tick.png"><label>Cash On Delivery</label>
   <button class="not" onclick="place()">Proceed</button>
   </div>
    </div>
            
            </div>
            <div id="part" class="part2">
                <div id="order" class="order">
                <div style="margin-bottom: 20px; color: rgb(123, 123, 123); font-weight: 600;" class="ordertit">Order Details</div>
                <div style="margin:10px 0" class="ordermrp">Items MRP<span id="subtotal"></span></div>
                <div style="margin:10px 0" class="orderdis">Discount<span style="color:rgb(7, 162, 59)" id="subdis"></span></div>
                <div style="margin:10px 0" class="ordership">Delivery Charges<span style="color:rgb(7, 162, 59)">Free</span></div>
                <div style="margin:15px 0;padding-top: 6px;border-top: 1px solid #ababab;" class="ordertotal">Total Amount<span id="grandtotal"></span></div>
                <button id="buybtn" onclick="place()">Proceed</button>
                <!-- <div style="text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;" class="ordersave">You Have Saved 5454</div> -->
                <div style="text-align:center;margin-top: 33px;color: rgb(255 118 0);font-weight: 500;font-size: 25px;" id="orsa" class="ordersave"></div>
               </div>
                
               <div class="mobifoot">
<div class="mofo">
<div class="foimg"><img src="/Assets/Icons/payment.png"></div>
<div class="fosub">Safe And Secure Payment. 100% Original Products.</div>
</div>
</div>


            </div>

        </div>
    </div>

    <div style="display:<?php echo $display1 ?>" class="error-sec">
        <div class="error-img">
            <img src="/Assets/Icons/error 1.png">
            <div class="error-btn">
                <button onclick="window.history.go(-2)">Back</div>
            </div>
       </div>
     
</div>


<script>
  $("#lonoz2").click(function(){
        document.getElementById("load1").style.display = "block";
  });

</script>


    </body>
</html>