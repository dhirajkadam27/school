<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}


if(!isset($_SESSION['no'])){
  header("Location: /Login?ref=$_SERVER[PHP_SELF]");
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Connecting</title>
  <style>
  body{
      padding: 0;
      margin:0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

  }
  .nav{
    width: 100%;
    height: 80px;
    background: gold;
  }
  .nav img{
    width: 185px;
    margin-left: 20px;
  }
  p{
    text-align: center;
    font-size: 25px;
    font-weight: 700;
    margin-bottom: 0;
  }
    .design {
      width: 100%;
      height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      position: relative;
    }
 
    .circle {
      border-radius: 50%;
      background-color: deepskyblue;
      width: 150px;
      height: 150px;
      position: absolute;
      opacity: 0;
      animation: scaleIn 4s infinite cubic-bezier(.36, .11, .89, .32);
    }
 
    .site {
      z-index: 10;
      padding: 5px;
    }
 
    .site img {
      width: 150px;
    }

    @keyframes scaleIn {
  from {
    transform: scale(.5, .5);
    opacity: .5;
  }
  to {
    transform: scale(2.5, 2.5);
    opacity: 0;
  }
}
  </style>
</head>
 
<body>
 <div class="nav">
<img src="/Assets/Icons/Logo.png">
 </div>
  <div class="main">
  <p>Connecting...</p>
    <div class="design">
      <div class="site">
        <img id="imo" src="b.png" />
      </div>
      <div class="circle" style="animation-delay: -3s"></div>
    <div class="circle" style="animation-delay: -2s"></div>
    <div class="circle" style="animation-delay: -1s"></div>
    <div class="circle" style="animation-delay: 0s"></div>
    </div>
  </div>

  <script>
 document.getElementById("imo").src = sessionStorage.getItem('site')+".png";
 setInterval( function(){
  window.location.replace('/pv/Checkout');
 }, 2000);
  </script>
</body>
 
</html>