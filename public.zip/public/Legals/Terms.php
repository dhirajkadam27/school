<!DOCTYPE html>
<html>
<head>
    <title>Privacy Policy</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
 <style>
body{
    padding: 0;
    margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
background: #f1f1f1

}
img[alt="www.000webhost.com"]{
               display: none;
           } 
.nav{
    width: 100%;
    height: 50px;
    background: gold;
    display: flex;
}
.back img{
    width: 30px;
    margin: 9px 10px;
}
.title{
    font-size: 27px;
    margin-left: 15px;
    font-weight: 600;
    line-height: 50px
}
.main{
    width: 100%;
    margin-top: 40px;
}
.all{
    width:70%;
    margin:20px auto;
    background: white;
    padding:5px 15px
}
    </style>
</head>
<body>
    <div class="nav">
        <div onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>
        <div class="title">
        Terms of service
        </div>
    </div>
    <div class="main">
  <div class="all">
  <p>This Terms of service was last Updated on 17 May 2021.<br><br>


<h2>OVERVIEW</h2>
<p>
This Terms of Service Agreement ("Agreement") is entered into by and between Derbun, registered address Kouthali, India ("Company") and you, and is made effective as of the date of your use of this website derbun.com ("Site") or the date of electronic acceptance.<br><br>
This Agreement sets forth the general terms and conditions of your use of the derbun.com as well as the products and/or services purchased or accessed through this Site (the "Services").Whether you are simply browsing or using this Site or purchase Services, your use of this Site and your electronic acceptance of this Agreement signifies that you have read, understand, acknowledge and agree to be bound by this Agreement our Privacy policy. The terms "we", "us" or "our" shall refer to Company. The terms "you", "your", "User" or "customer" shall refer to any individual or entity who accepts this Agreement, uses our Site, has access or uses the Services. Nothing in this Agreement shall be deemed to confer any third-party rights or benefits.<br><br>
Company may, in its sole and absolute discretion, change or modify this Agreement, and any policies or agreements which are incorporated herein, at any time, and such changes or modifications shall be effective immediately upon posting to this Site. Your use of this Site or the Services after such changes or modifications have been made shall constitute your acceptance of this Agreement as last revised.<br><br>
IF YOU DO NOT AGREE TO BE BOUND BY THIS AGREEMENT AS LAST REVISED, DO NOT USE (OR CONTINUE TO USE) THIS SITE OR THE SERVICES.<br><br>
</p>


<h2>ELIGIBILITY</h2>
<p>
This Site and the Services are available only to Users who can form legally binding contracts under applicable law. By using this Site or the Services, you represent and warrant that you are (i) at least eighteen (18) years of age, (ii) otherwise recognized as being able to form legally binding contracts under applicable law, and (iii) are not a person barred from purchasing or receiving the Services found under the laws of the India or other applicable jurisdiction.<br><br>
If you are entering into this Agreement on behalf of a company or any corporate entity, you represent and warrant that you have the legal authority to bind such corporate entity to the terms and conditions contained in this Agreement, in which case the terms "you", "your", "User" or "customer" shall refer to such corporate entity. If, after your electronic acceptance of this Agreement, Company finds that you do not have the legal authority to bind such corporate entity, you will be personally responsible for the obligations contained in this Agreement.
</p>

<h2> RULES OF USER CONDUCT</h2>
<b>
By using this Site You acknowledge and agree that:
</b>
<ul>
<li>Your use of this Site, including any content you submit, will comply with this Agreement and all applicable local, state, national and international laws, rules and regulations.</li>
</ul>
<b>
You will not use this Site in a manner that:
</b>
<ul>
<li>Is illegal, or promotes or encourages illegal activity;</li>
<li>Promotes, encourages or engages in child pornography or the exploitation of children;</li>
<li>Promotes, encourages or engages in terrorism, violence against people, animals, or property;</li>
<li>Promotes, encourages or engages in any spam or other unsolicited bulk email, or computer or network hacking or cracking;</li>
<li>Infringes on the intellectual property rights of another User or any other person or entity;</li>
<li>Violates the privacy or publicity rights of another User or any other person or entity, or breaches any duty of confidentiality that you owe to another User or any other person or entity;</li>
<li>Interferes with the operation of this Site;</li>
<li>Contains or installs any viruses, worms, bugs, Trojan horses, Cryptocurrency Miners or other code, files or programs designed to, or capable of, using many resources, disrupting, damaging, or limiting the functionality of any software or hardware.</li>

</ul>

<b>
You will not
</b>
<ul>
<li>copy or distribute in any medium any part of this Site, except where expressly authorized by Company,</li>
<li>modify or alter any part of this Site or any of its related technologies,</li>
<li>access Companies Content (as defined below) or User Content through any technology or means other than through this Site itself.</li>
</ul>


<h2>Security</h2>
<p>
The security of your Personal Information is important to us, but remember that no
 method of transmission over the Internet, or method of electronic storage, is 100% 
 secure. While we strive to use commercially acceptable means to protect your Personal 
 Information, we cannot guarantee its absolute security.
</p>

<h2>Changes To This Privacy Policy</h2>
<p>
Derbun may update this Privacy Policy from time to time the Site.
 You are advised to review this Privacy Policy periodically for any changes.
</p>


<h2>Contact Us</h2>
<p>
If you have any questions about this Privacy Policy, please contact us.
<br>
support@Derbun.com
<br>
Derbun.com/help/contact-us

</p>
  </div>
    </div>
</body>
</html>