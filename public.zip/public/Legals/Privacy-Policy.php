<!DOCTYPE html>
<html>
<head>
    <title>Privacy Policy</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
 <style>
body{
    padding: 0;
    margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
background: #f1f1f1

}
img[alt="www.000webhost.com"]{
               display: none;
           } 
.nav{
    width: 100%;
    height: 50px;
    background: gold;
    display: flex;
}
.back img{
    width: 30px;
    margin: 9px 10px;
}
.title{
    font-size: 27px;
    margin-left: 15px;
    font-weight: 600;
    line-height: 50px
}
.main{
    width: 100%;
    margin-top: 40px;
}
.all{
    width:70%;
    margin:20px auto;
    background: white;
    padding:5px 15px
}
    </style>
</head>
<body>
    <div class="nav">
        <div onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>
        <div class="title">
          Privacy Policy
        </div>
    </div>

    <div class="main">
  <div class="all">
  <p>This Privacy Policy was last Updated on 17 May 2021.<br><br>
Throughout the site, the terms “we”, “us” and “our” refer to Derbun.
 This page informs you of our policies regarding the collection, 
 use and disclosure of Personal Information we receive from users of the Site.
 <br><br>
We use your Personal Information only for providing and improving the Site.
 By using the Site, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible at www.Derbun.com
</p>

<h2>Information Collection And Use</h2>
<p>While using our Site or purchasing something from us ,
 we may ask you to provide us your Personal Information to contact you or to verify you.
  Personal Information  may include your name, email address, postal address,
   phone number and your gender.<br><br>
We require this information to provide you better services, and in that process,
 contact you or deliver certain information via email, message, phone.
</p>

<h2>Log Data</h2>
<p>We don’t Collect “Log Data” That your browser Provides Such as your  
Internet Protocol (“IP”) address, browser type, browser version, the pages 
of our Site that you visit, the time and date of your visit, the time spent on 
those pages and other statistics. We might be collect this kind of Log Data in future.
</p>

<h2>Cookies</h2>
<p>Cookies are files with small amount of data, which may include an anonymous unique 
identifier. Cookies are sent to your browser from a web site and stored on your 
computer’s hard drive.<br><br>
Like many sites, we use “cookies” to collect information. 
You can instruct your browser to refuse all cookies or to indicate when a
 cookie is being sent. However, if you do not accept cookies, you may not be
  able to use some portions of our Site. Mainly cookies is used to store your login 
session and cart or checkout details.
</p>

<h2>Security</h2>
<p>
The security of your Personal Information is important to us, but remember that no
 method of transmission over the Internet, or method of electronic storage, is 100% 
 secure. While we strive to use commercially acceptable means to protect your Personal 
 Information, we cannot guarantee its absolute security.
</p>

<h2>Changes To This Privacy Policy</h2>
<p>
Derbun may update this Privacy Policy from time to time the Site.
 You are advised to review this Privacy Policy periodically for any changes.
</p>


<h2>Contact Us</h2>
<p>
If you have any questions about this Privacy Policy, please contact us.
<br>
support@Derbun.com
<br>
Derbun.com/help/contact-us

</p>
  </div>
    </div>
</body>
</html>