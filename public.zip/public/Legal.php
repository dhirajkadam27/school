<!DOCTYPE html>
<html>
<head>
    <title>Legal</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
 <style>
body{
    padding: 0;
    margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
background: #f1f1f1

}
img[alt="www.000webhost.com"]{
               display: none;
           } 
.nav{
    width: 100%;
    height: 50px;
    background: gold;
    display: flex;
}
.back img{
    width: 30px;
    margin: 9px 10px;
}
.title{
    font-size: 27px;
    margin-left: 15px;
    font-weight: 600;
    line-height: 50px
}
.main{
    width: 100%;
    position: fixed;
    top: 75px;
}
.all{
    width:70%;
    margin:5px auto
}
.pp{
    width: 100%;
    display: inline-flex;
    background: white;
    margin: 10px 0;
    border-radius: 10px;
    position: relative;
}
.pp p{
    font-size:20px;
    font-weight:500;
    margin-left:20px
}
.pp img{
    width: 50px;
    height: 50px;
    margin-top: 8px;
    position: absolute;
    right: 5px;
}
    </style>
</head>
<body>
    <div class="nav">
        <div onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>
        <div class="title">
           Legal
        </div>
    </div>

    <div class="main">
        <div class="all">
        <div id="lonoz2" onclick="window.location.href='/Legals/Privacy-Policy'" class="pp">
      <p>Privacy Policy</p><img src="/Assets/Icons/arrow.png">
        </div>
        <div id="lonoz2" onclick="window.location.href='/Legals/Terms'" class="pp">
      <p>Terms And Condition</p><img src="/Assets/Icons/arrow.png">
        </div>
        </div>
    </div>


    <script>
  $("#lonoz2").click(function(){
        document.getElementById("load1").style.display = "block";
  });

</script>


</body>
</html>