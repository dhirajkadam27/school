<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
if(isset($_SESSION['no'])){
  $se = $_SESSION['no'];
  $query = "SELECT * FROM notify WHERE user = '$se'";
  $data = mysqli_query($conn, $query);
  $total = mysqli_num_rows($data);
  $json = array();
    while($result = mysqli_fetch_assoc($data)){  
      if($result["seen"] == "Send") {
        $json[] = $result ;
      }
    }
    echo json_encode($json);

}

?>