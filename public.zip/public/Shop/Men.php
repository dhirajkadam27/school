<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
?>
<html>
<head>
  <title>Derbun | Online Shopping Site</title>
  <script src="/Assets/Js/JQuery.js"></script>
  <script src="/Assets/Js/search.js"></script>
  <link rel="manifest" href="/Assets/manifest.json">
  <link rel="apple-touch-icon" href="/Assets/Ico/hello-icon-152.png">
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel="icon" href="/Assets/Ico/favicon.ico" type="image/x-icon" />
  <meta name="theme-color" content="gold"/>

  <script>
 function crossm(){
    document.getElementById("allm").style.left = '-100%';
}

 function plusm(){
    document.getElementById("allm").style.left = '0';
}

function crossw(){
    document.getElementById("allw").style.left = '-100%';
}

 function plusw(){
    document.getElementById("allw").style.left = '0';
}

function crossk(){
    document.getElementById("allk").style.left = '-100%';
}


 function plusk(){
    document.getElementById("allk").style.left = '0';
}


</script>


<script>
window.onload = () => {
  'use strict';

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker
             .register('Asssets/Js/sw.js');
  }
}
</script>


  <style>
 body{
                margin: 0;
                padding: 0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

                background: #f1f1f1;
            }
	
            img[alt="www.000webhost.com"]{
               display: none;
           } 
            .loadbg1{
            width: 100%;
            height: 100vh;
            position: fixed;
            top:0;
            z-index:4
        }
        .loader1{
            box-shadow:1px 1px 10px 1px #a9a9a9;
            display: flex;
            position: absolute;
            top: 50%;
            left: 50%;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width: 45px;
            height: 45px;
            margin: 7px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }

        @media only screen and (min-width:320px) and (max-width: 480px){
            .nav{
                background:gold;
                width:100%;
                height:50px;
                position: fixed;
                top: 0;
                z-index:5;
                display:flex;
            }

            .slicon{
                position: initial;
                z-index: 5;
                width:20px;
                height:20px;
                margin: 15px 15px 0px 15px
            }

            .left{
		 width:80%;
		 height:100%;
		 position:fixed;
         top:0;
		 left:-90%;
         z-index: 7;
		 background:white;
         transition-property:left;
         transition-duration: 0.3s

		 }
		 .slide:hover .left{
            left:0;
		 }
		    
    .menu > ul{
        list-style:none;
        padding:0;
        margin:0;
        position:relative;
    }
    .menu li{
        display:flex
    }
    .menu li > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size:20px;
        pointer-events: none;
     }
    .menu li > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }

    .meals{
        display:flex;
        width: 100%;
    }
    .menu li div > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size:20px;
        pointer-events: none;
     }
    .menu li div > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }


   
    .vial img{
        margin-left: 130px;
    position: absolute;
    right: 18px;
    width: 32px;
    }

    .arro{
        display:none
    }
    .plus{
        width: 20px;
    margin-right: 7px;
    margin-top: 4px;
    }
    .menu ul > li:hover{
        background: rgb(221, 221, 221);
    }
    .all{
        background: white;
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100vh;
        display: block;
        z-index: 3;
        text-align: center;
        transition-property:left;
        transition-duration: 0.3s
    }

    .cross{
        width: 29px;
        transform: rotate(45deg);
        margin-top:-5px
    }
   
    .all li{
    padding: 10px 0;
    }
    .celo{
        display:block;
    }
    .self{
        display:block;
      
    }
    .self ul{
        padding:0;
        margin:10px 22px;
        font-size: 20px
    }
    .self a{
        text-decoration:none;
        color: black
    }
   
    .self a:hover{
        font-size:17px;
    }
    .til{
        font-size: 20px;
       font-weight: 500;
       line-height:50px;
    }
.sein{
    display:none;
    border-bottom:1px solid black;
}
.fullwhite{
    width: 100%;
    height: 100vh;
    background: white;
    top: 50px;
    position: fixed;
    left: 0;
}
.sein input{
    width: 90%;
    top: 0;
    position: fixed;
    right: 0;
    z-index: 5;
    height: 50px;
    border: none;
    outline: none;
    border-bottom: 1px solid #b1b1b1;
}

#que ul{
            width:100%;
      background: #fff;
      color: #000;
      text-align:left;
      padding:0;
             
    }
    #que a{
        color: black;
        text-decoration: none
    }
    #que li{
      padding: 10px 15px;
      cursor: pointer;
      color: black;
      list-style:none;
    }
    #que li:hover{
      background: #f0f0f0;
    }
.base{
    width: 10%;
    top: -1px;
    position: fixed;
    left: 0;
    z-index:5;
    height: 50px;
    background:white;
    border-bottom: 1px solid #b1b1b1;
         }
         .sese{
            position: fixed;
            right: 16px;
            top: 10px;
            z-index: 6;
            background: white;
         }
         .sese img{
            width: 25px;
         }
         .sese button{
             background:white;
             border:none
         }
         .sug{
            width: 100%;
    height: 100vh;
    background: white;
    top: 36px;
    position: fixed;
    left: 0;
    overflow-y: auto;
         }
         .base img{
    width: 22px;
    margin-top: 15px;
    margin-left: 6px;
         }
.search{
    display:none
}
.rity{
    position:absolute;
    right:0;
    display:flex
}

.sear img{
    width:25px;
    height:25px;
    margin-top: 12px;
    margin-right: 17px;
}
.cart{
    display: flex;
    position:relative;
    margin-right:7px
}
.cart img{
    width:30px;
    height:30px;
    margin-top:10px;
    margin-right:12px
}
.mobilog{
    margin-top: 13px;
    margin-right: 10px;
}
.mobilog a{
    text-decoration: none;
    color: black;
    font-weight: 600;
}
.mobilog img{
    width: 27px;
    height: 30px;
}
.noti{
             position:absolute;
             top:0;
             right:0;
            width:16px;
             font-size:12px;
             color: white;
             font-weight: bold;
             background: rgb(255, 0, 0);
             border:4px solid gold;
             padding:2px;
             border-radius:50%;
             text-align:center
}
.log{
    display:none
}

.act{
    display:none
}
.sliderbg{
    width:100%;
    height:100%;
    background: #0a0a0a70;
    position:fixed;
    top:0;
    left:0;
    z-index:4;
    visibility:hidden;
    transition: visibility 0.1s;
}
.sliderbg2{
    width:100%;
    height:50px;
    background: #0a0a0a70;
    position:fixed;
    top:0;
    left:0;
    z-index:4;
    visibility:hidden;
    transition: visibility 0.1s;
}
.feat{
    display:none
}

.main{
    position:absolute;
    top:52px;
    width:100%;
    background:white;
}

.hori{
    overflow: scroll;
    display: flex;
    width: 100%;
    margin-top: 13px;
    margin-bottom: 13px;
    justify-content: center;
}

.gol img {
    width: 80px;
    margin-left:10px
}

.men p{
    font-size: 25px;
    font-weight: 500;
    text-align: center;
}
.row1{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}
.row1 img{
    width: 45%;
}
.row2{
    max-width: 100%;
    display: flex;
    overflow: scroll;
    padding-left: 10px;
}
.row2 img{
    min-width: 40%;
}
.row3{
    width: 100%;
    display: flex;
    justify-content: space-evenly;
    margin: 15px 0;
}
.row3 img{
    width: 45%;
}

                footer{
            background-color: #f9f9f9;
    width: 100%;
    color: #5d5d5d;
    font-size: 18px;
}
          
         .foot{
            display: block;
    margin-left: 20px;
    padding-top: 10px;
         }
         .ter li{
           font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
           font-size: 14px;
         }
         
         
         .ter ul{
             list-style-type:none;
             padding: 0 10px;
         }
         .ter b{
            color: #797979;
            font-size: 18px;
    display: block;
    margin-bottom: 5px;
         }
         .ter a{
            text-decoration: none;
    color: #777777;
         }
         
         .foot a:hover{
             color: black
         }
         .goog{
        }
         .goog img{
            margin-top: 15px;
    width: 120px;
    margin-left: 30px;
         }
         .cood img{
            margin-top: 20px;
    width: 130px;
    margin-left: 20px;
         }
         .ter1{
            margin-top: 10px;
    margin-left: 10px;
         }
         .ter1 b{
            font-size: 15px;
         }
         .copy{
            width: 100%;
    text-align: center;
    margin-top: 20px;
    padding-bottom: 10px;
    padding-top: 8px;
    border-top: 1px solid #c5c5c5;
    font-size: 10px;
         }



     

.online{
    width: 100%;
    height: 100vh;
    position: fixed;
    z-index: 10;
    top: 0;
    display: none
}

.alert{
width: 92%;
    height: 50px;
    background: gold;
    border-radius: 5px;
    margin: 4%;
    position: absolute;
    bottom: 0;
    text-align: center;
    font-size: 19px;
    font-weight: 500;
    padding-top: 15px;
}
.mobifoot{
    width:100%;
    margin-top: 10px;
    padding-bottom: 10px;
}
.mofo{
    width: 50%;
    margin: 5px 25%;
    display: flex;
}
.foimg img{
    width:35px;
    padding-top: 1px;
}
.fosub{
    padding-left: 10px;
    font-size: 10px;
    font-weight: 500;
    color: #8c8c8c;
}





 }


        /* max size */
        @media only screen and (min-width:800px){

      		/*Nav Bar Css*/
              .nav{
                background:gold;
                width:100%;
                height:70px;
                position: fixed;
                z-index:4;
                display:flex;
            }

			    .til{
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight:bold;
            font-size:39px;
            color:black;
            margin-left:90px;
            line-height:70px;
         }
         .cart{
             right:21px;
             top:6px;
             position:fixed;
             padding:5px;
           
         }
        .mobinav{
            display:none
        }
         .cart img{
             width:40px;
             height:40px;
             margin-right:11px;
             margin-top:7px
         }
         .noti{
             width:20px;
             position:absolute;
             top:0;
             right:0;
             color: white;
             font-weight: bold;
             background: rgb(255, 0, 0);
             border:4px solid gold;
             padding:4px;
             border-radius:50%;
             text-align:center
         }
         .act{
            right:100px;
             top:16px;
             position:fixed;
             text-align:right;
         }
       .act img{
           width:45px;
           height:45px
       }
       .act:hover .crete{
           display:block
       }
       .crete{
           width:220px;
           height:258px;
           background:white;
           box-shadow: 0 1px 10px rgba(1,1,1,.25);
           display:none;
           margin-right:-60px;
           margin-top:17px;
           padding:10px 5px
       }
       .tobo{
           margin:0 15px;
           text-align:left
       }
       .tobo a{
           display:block;
           text-decoration:none
       }
       .weec{
        font-weight:bold;
       }
       .usna{
           border-bottom: 1px solid goldenrod;
           color:black;
           font-size:19px;
           padding-top: 3px;
           padding-bottom:7px
       }
       .crea a{
           display:block;
           font-size:17px;
           text-align:left;
           padding:8px 15px;
           text-decoration:none;
           color: black;
       }
       .crete button{
         width:180px;
         height:30px;
         outline:none;
         border:none;
         background:gold;
         color:black;
         border-radius:5px;
         margin:10px 0;
       }
       .logbt{
            display:block;
           text-align:center;
           width:100%;
       }
       .crea a:hover{
           font-weight:bold;
       }
         .search{
             position:fixed;
             top:15px;
             right:255px;
         }
         
         .search img{
             width:22px;
             height:22px;
			 margin-top:2px
         }
         .base{
             display:none
         }
         .search button{
            border-radius:0 5px 5px 0;
			border:none;
             padding: 7px 12px;
			 background:rgb(92, 92, 92);
			 color:white;
			 display:flex
         }
		 .search p{
		 margin:6px 4px;
		 }
         .sese{
             display:none
         }
         .sein{
             display:block;
             margin-top:14px;
             position:fixed;
             right:351px;
         }
         .sug{
            width:390px;
            height:275px;
            background:white;
			display:none
         }
         .sein input{
             width:390px;
             height:40px;
			 outline:none;
			 border-radius:5px 0 0 5px;
			 border:none;
			 font-size:15px;
			 padding-left:15px;
         }
         .fullwhite{
             display:none
         }
         #que ul{
            width:390px;
      background: #fff;
      color: #000;
      text-align:left;
      padding:0;
             
    }
    #que a{
        color: black;
        text-decoration: none
    }
    #que li{
      padding: 10px 15px;
      cursor: pointer;
      color: black;
      list-style:none;
    }
    #que li:hover{
      background: #f0f0f0;
    }
	    .log{
            right:120px;
             top:21px;
             position:fixed;
             font-size: 20px;
         }
         .mobilog{
             display:none
         }
         .log a{
             text-decoration:none;
             color:black;
             background:  rgb(255, 226, 64);
             padding:2px 10px;
             padding-bottom:5px;
             border-radius:7px;
             border:2.5px solid black
         }
         .sear{
            display:none
         }
		 /*Nav Bar Css End */
		 
		  /*Horizontal Options */
          .feat{
         display:none;
		 }
   
		  /*Horizontal Options End*/
		  
		   /*Vertical Menu Bar*/
		 .slide{
		 position:fixed;
		 padding:17px 28px 22px 24px;
		 }
         .slicon{
            width:30px;
            height:30px
         }
		 .left{
		 width:200px;
		 height:100%;
		 margin-top:23px;
		 position:fixed;
		 left:-200px;
		 background:white;
         transition-property:left;
         transition-duration: 0.3s

		 }
         .slide:hover .left{
            left:0;
            box-shadow: 5px 16px 20px 2px #0000006b;
		 }
		    
    .menu > ul{
        list-style:none;
        padding:0;
        margin:0;
        position:relative
    }
    .menu li{
        display:flex
    }
    .menu li > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size:17px;
     }
    .menu li > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }


    .meals{
        display:flex
    }
    .menu li div > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size:17px;
     }
    .menu li div > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }
    
    .plus{
        display:none
    }
    .arro{
        width:20px;
margin-top: 5px
    }

    .menu ul > li:hover{
        background: rgb(221, 221, 221);
    }
    .all{
        background: gold;
    position: absolute;
    left: 100%;
    display: none;
    z-index: 3;
    height: 80%;
    position: absolute;
    top: 10px;
    }
    .cross{
        display:none
    }
    .vial{
        display:none
    }
    .menu li:hover .all{
        display:block
    }
    .celo{
        display: block;
    }
    .self{
        display: inline-block;
        margin: 5px 2px;
    }
    .self ul{
        padding:0;
        margin: 5px 22px;
        white-space: nowrap;
    }
    .self a{
        text-decoration:none;
        color: black
    }
   
    .self a:hover{
        color: red;
        font-size:17px;
    }
/*Vertical Menu Bar End*/
.sliderbg{
    width:100%;
    height:100%;
    background: #0a0a0a70;
    position:fixed;
    top:0;
    left:0;
    z-index:3;
    visibility: hidden
}
.main{
    width:100%;
    background:white;
    position:absolute;
    top:74px;
}

.hori{
    display: flex;
    width: 100%;
    margin-top: 13px;
    flex-wrap: wrap;
    justify-content: center;
}

.gol img {
    width: 100px;
    margin-left:20px
}

.men p{
    font-size: 25px;
    font-weight: 500;
    text-align: center;
}
.row1{
    width: 100%;
    text-align: center;
}
.row1 img{
    width: 22%;
}
.row2{
    width: 100%;
    text-align: center;
}
.row2 img{
    width: 22%;
}
.row3{
    display: none
}
        footer{
    background-color: #f9f9f9;
    width: 100%;
    color: #5d5d5d;
}
          
          
         .foot{
             display:flex;
             justify-content: center;
         }
         .ter li{
           font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

         }
         
         
         .ter ul{
             list-style-type:none;
         }
          .ter b{
            color: #797979;
            font-size: 15px;
    display: block;
    margin-bottom: 5px;
         }         .ter a{
            text-decoration: none;
    color: #777777;
         }
         
         .foot a:hover{
             color: black
         }
         .goog{
            margin-left: 15px;
        }
         .goog img{
             margin-top:15px;
             width: 150px;
    margin-left: 11px;
         }
         .cood img{
            margin-top: 28px;
            width: 180px;
         }
         .ter1{
            margin-top: 20px;
            margin-left: 30px;
         }
         .copy{
            width: 100%;
    text-align: center;
    margin-top: 20px;
    padding-bottom: 10px;
    padding-top: 10px;
    border-top: 1px solid #c5c5c5;
         }




.mobifoot{
    display: none
}



    }

</style>
</head>
<body onload="load1()">

<div id="load1" class="loadbg1">

<div class="loader1">
     <img id="lonoz2" src="/Assets/Icons/loader.gif">
</div>

</div>

       <div id="navv" class="nav">
       <div id="ridss2" class="sliderbg2"></div>
	   <!--Vertical Slider Img-->
	    <div class="slide">
     <img id="lonoz2" class="slicon" src="/Assets/Icons/menu.png">
	<!--Vertical Slider Starts-->
	<div class="left">
	<!--Vertical Slider Menu Starts-->
    <div class="menu">
<ul>
<?php
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
if(isset($_SESSION['no'])){
    $num = $_SESSION['no'];
    $soy = "SELECT * FROM users where number = $num";
    $us = mysqli_query($conn, $soy);
    $net = mysqli_num_rows($us);
    $result = mysqli_fetch_assoc($us);
    if($net!=0){
            $name = $result['fn'];
echo "<li style='background:gold;'><a style='font-family: Verdana, Geneva, Tahoma, sans-serif;font-size:18px;padding: 15px 25px;' href=''>Hello,&nbsp;";
if(empty($name)){
echo "Customer";
}
if(!empty($name)){
    echo $name;
}
echo "</a></li>";
        
}
}
   ?>


<li><a href="/">Home</a></li>
<li><a href="/Shop/All">All Catagory</a></li>
<li><div class="meals" onclick="plusm()"><a id="lono1as" href="/Shop/Men">Men</a><span> <img id="lonoz2" class="plus"  src="/Assets/Icons/plus.png"> <img id="lonoz2" class="arro" src="/Assets/Icons/arrow.png"></span></div>
    <div id="allm" class="all">
        <div class="celo">
            <div class="self">
         <ul>
         <a class="vial"><li><b onclick="window.location.href='/Shop/Men'">View All</b> <img id="lonoz2" class="cross" onclick="crossm()" src="/Assets/Icons/plus.png"></li></a>
         <a href="/men-topwear"><li><b>TopWear</b></li></a>
         <a href="/men-tshirts"><li>T-shirts</li></a>
         <a href="/men-casual-shirts"><li>Casual Shirts</li></a>
         <a href="/men-formal-shirts"><li>Formal Shirts</li></a>
        </ul>
</div>
<div class="self">
<ul>
         <a href="/men-bottomwear"><li><b>BottomWear</b></li></a>
         <a href="/men-jeans"><li>Jeans</li></a>
         <a href="/men-shorts"><li>Shorts</li></a>
         <a href="/men-trousers"><li>Trousers</li></a>
        </ul>
</div>
<div class="self">
<ul>
         <a href="/men-ethnic-wear"><li><b>Ethnic Wear</b></li></a>
         <a href="/men-kurtas"><li>Kurtas</li></a>
         <a href="/men-ethnic-bottomwear"><li>Ethnic Bottomwear</li></a>
        </ul>
</div>

</div>
    </div>
    </li>

    <li   style="border-bottom: 1px solid #acacac;"><div class="meals" onclick="plusw()"><a id="lono1as" href="/Shop/Women">Women</a><span> <img id="lonoz2" class="plus"  src="/Assets/Icons/plus.png"> <img id="lonoz2" class="arro" src="/Assets/Icons/arrow.png"></span></div>
    <div id="allw" class="all">
        <div class="celo">
        <div class="self">
         <ul>
         <a class="vial"><li><b onclick="window.location.href='/Shop/Women'">View All</b> <img id="lonoz2" class="cross" onclick="crossw()"  src="/Assets/Icons/plus.png"></li></a>
         <a href="women-tops"><li><b>Tops</b></li></a>
         <a href="women-tshirts"><li>T-Shirts</li></a>
         <a href="women-trousers"><li>Trousers</li></a>
         <a href="women-shorts"><li>Shorts</li></a>
        </ul>
</div>

        <div class="self">
         <ul>
         <a href="/women-ethnic-wear"><li><b>Ethnic Wear</b></li></a>
         <a href="/sarees"><li>Sarees</li></a>
         <a href="/women-Kurtas"><li>Kurtas</li></a>
         <a href="/women-ethnic-bottomwear"><li>Ethnic Bottomwear</li></a>
        </ul>
</div>

</div>
    </li>


<li><a href="/Account">My Account</a></li>
<li><a href="/Notifications">My Notification</a></li>
<li><a href="/Accounts/Orders">My Orders</a></li>
<li style="border-bottom: 1px solid #acacac;"><a href="/Cart">My Cart</a></li>
<li><a href="/Help">Help</a></li>
<li><a href="/Legal">Legal</a></li>
</ul>
</div>

		</div>
        </div>

		<!-- Vertical silder ends-->
		
      <div class="til">
         Mens Fashion
        </div>
 


 <form action="/Search">
        <div id="sein" class="sein">
        <div onclick="closefullsearch()"  class="base"> <img id="lonoz2" src="/Assets/Icons/arrowl.png"></div>
        <div class="fullwhite"></div>
        <div class="sese"><button> <img id="lonoz2" src="/Assets/Icons/search b.png"></button></div>
        <input type="text" autocomplete="off" id="search" placeholder="Search the product" name="q">
        <div class="sug" id="que">
        <ul>
<li>Men Tshirts</li>
<li>Men Shirts</li>
<li>Mobiles</li>

        </ul>
        </div>
        </div>
        <div class="search">
        <button> <img id="lonoz2" src="/Assets/Icons/search.png"><p>Search</p></button>
        </div>
</form>
<script>
function fullsearch(){
    document.getElementById("sein").style.display = 'block';
    document.getElementById("search").value = '';
}

function closefullsearch(){
    document.getElementById("sein").style.display = 'none';
}

</script>
<div class="rity">
        <div class="sear"> <img id="lonoz2"  onclick="fullsearch()" src="/Assets/Icons/search b.png"></div>
        <div class="cart">
   <a href="/Cart" ><img src="/Assets/Icons/bag.png"></a>
   <?php 
   $count = 0;
   if(isset($_SESSION['cart'])){
   $count = count($_SESSION['cart']);
   }
   if($count > 0){
       echo  
   '<div class="noti">'.$count.'</div>';
   }
   ?>
        </div>
        <div class="mobilog">
        <?php
        if(isset($_SESSION['no'])){
            echo '<img onclick=window.location.href="/Account" src="/Assets/Icons/user g.png">';
        }
            else{  
 echo '<a href="/Login?ref='.$_SERVER['REQUEST_URI'].'">Login</a>';
        }
        ?>
</div>

  </div>


        <?php


$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
        if(isset($_SESSION['no'])){
            $num = $_SESSION['no'];
   $soy = "SELECT * FROM users where number = $num";
   $us = mysqli_query($conn, $soy);
   $net = mysqli_num_rows($us);
       while($result = mysqli_fetch_assoc($us)){
           $name = $result['fn'];
 }
                echo '<div  class="act">
            <img src="/Assets/Icons/user.png">
            <div class="crete"> 
            <div class="tobo">
            <a class="weec">Welcome</a>
            <a class="usna">'.$name.'</a>
            </div>
            <div class="crea">
            <a href="/Account">Profile</a>
            <a href="/Accounts/Orders">Orders</a>
            <a href="/Cart">Bag</a>
            <a href="">Contact Us</a>
            <div class="logbt">
            <button  onclick=window.location.href="/Logins/Logout?ref='.$_SERVER['REQUEST_URI'].'">Logout</button>
            </div>
            </div>
            </div>
            </div>
            ';
        }
        else{
            echo '<div  class="log">
            <a href="/Login?ref='.$_SERVER['REQUEST_URI'].'">Login</a>
            </div>';
        }
        ?>



        </div>
		<!--navbar Ends-->
		<!--frgfdg-->

        <div id="ridss" class="sliderbg"></div>
        
        <script>

$(".slide").hover(function(){
$(".left").css("left","0");
document.getElementById("ridss").style.visibility = 'visible';
    document.getElementById("ridss2").style.visibility = 'visible';
},function(){
    $(".left").css("left","-90%");
    document.getElementById("ridss").style.visibility = 'hidden';
    document.getElementById("ridss2").style.visibility = 'hidden';
});
function seaa(){
document.getElementById("sein").style.display = 'block';
}
</script>

   <!-- product list start -->
<div id="mainn" class="main">
       
 <!--category -->
 <div class="hori">
<div class="gol"><img onclick="window.location.href='/Shop/All'" src="/Assets/home/icon-all.jpg"></div>
<div class="gol"><img onclick="window.location.href='/Shop/Men'" src="/Assets/home/icon-men.jpg"></div>
<div class="gol"><img onclick="window.location.href='/Shop/Women'" src="/Assets/home/icon-women.jpg"></div>
<div class="gol"><img onclick="window.location.href='/Shop/Mobile'"  src="/Assets/home/icon-mobile.jpg"></div>
</div>
  <!-- category End-->

 



  <div class="men">
 <p>Men Fashion</p>
 <div class="row1">
<img onclick="window.location.href='/Men-Tshirts'" src="/Assets/home/home15.jpg">
<img onclick="window.location.href='/Men-Shirts'" src="/Assets/home/home16.jpg">
<img onclick="window.location.href='/Men-Kurtas'" src="/Assets/home/home17.jpg">
<img onclick="window.location.href='/Men-Trousers'" src="/Assets/home/home18.jpg">
</div>

<div class="row2">
<img onclick="window.location.href='/Shop/All'" src="/Assets/home/home2.jpg">
<img onclick="window.location.href='/Shop/Men'" src="/Assets/home/home3.jpg">
<img onclick="window.location.href='/Shop/All'" src="/Assets/home/home4.jpg">
<img onclick="window.location.href='/Shop/Men'" src="/Assets/home/home6.jpg">
</div>

<div class="row3">
<img onclick="window.location.href='/Men'" src="/Assets/home/men.png">
<img onclick="window.location.href='/Men-Tshirts'" src="/Assets/home/t-shirts.png">
</div>

 </div>   


<div class="mobifoot">
<div class="mofo">
<div class="foimg"> <img id="lonoz2" src="/Assets/Icons/payment.png"></div>
<div class="fosub">Safe And Secure Payment. 100% Original Products.</div>
</div>
</div>

           <footer>
                       <div class="foot">
                           <div class="ter">
                               <ul>
                                   <li><b>Help</b></li>
                                   <li><a href="/Help">Payments</a></li>
                                   <li><a href="/Help">Orders</a></li>
                                   <li><a href="/Help">Notifications</a></li>
                               </ul>      
                          </div>
                          
                          <div class="ter">
                               <ul>
                                   <li><b>Useful Links</b></li>
                                   <li><a href="/Legal">T&C</a></li>
                                   <li><a href="/Legal">Shipping</a></li>
                                   <li><a href="/Accounts/Orders">Order</a></li>
                                   <li><a href="/Legal">Privacy Policy</a></li>
                                   <li><a href="/Help">Help</a></li>
                                   <li><a href="/Legal">Contact Us</a></li>
                                   <li><a href="/Legal">About Us</a></li>
                               </ul>      
                          </div>  
           
                          <div class="ter">
                               <ul>
                                   <li><b>Follow Us</b></li>
                                   <li><a href="">Facebook</a></li>
                                   <li><a href="">Twitter</a></li>
                                   <li><a href="">Youtube</a></li>
                               </ul>       
                          </div>  
           
                          <div class="ter">
                               <ul>
                                   <li><b>Catageries</b></li>
                                   <li><a href="/men">Men</a></li>
                                   <li><a href="/women">Women</a></li>
                               </ul>       
                          </div> 
                          <div class="ter1">
                          <div class="goog">
                          <b>Secure Login With Google</b><br>
                           <img id="lonoz2" src="/Assets/Icons/google.png">
                          </div>
                          <div class="cood">
                           <img id="lonoz2" src="/Assets/Icons/codb.png">
                          </div>
                          </div>

                       </div>
                       <div class="copy">
                       © 2021 www.Derbun.com. All rights reserved.
                       </div>
            </footer> 

</div>




<script>
    var loadf = document.getElementById("load1");
function load1(){
loadf.style.display = "none";
}
    </script>

<!-- <script>
// When the user scrolls down 20px from the top of the document, slide down the navbar
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("mobinav").style.top = "0";
  } else {
    document.getElementById("mobinav").style.top = "-50px";
  }
}
</script> -->

<script>
  $("img").click(function(){
    if($(this).attr("id")== "lonoz2"){

    }
    else{
        document.getElementById("load1").style.display = "block";
    }
  });

  $("a").click(function(){
    if($(this).attr("id") == "lono1as"){

}
else{
    document.getElementById("load1").style.display = "block";
}
  });

  $("#search").click(function(){
    document.getElementById("que").style.display = "block";
  });

</script>

</body>
</html>
<script type="text/javascript">
  $(document).ready(function(){
      $("#search").on("keyup", function(){
        var city = $(this).val();
        if (city !=="") {
          $.ajax({
            url:"/Searching/Query",
            type:"POST",
            cache:false,
            data:{city:city},
            success:function(data){
              $("#que").html(data);
              $("#que").fadeIn();
            }  
          });
        }else{
          $("#que").html("");  
          $("#que").fadeOut();
        }
      });

      // click one particular city name it's fill in textbox
       $("#que").on("click","li", function(){
        var tho =  $(this).text().replace(" ", "-");
        window.location.href="/"+tho;
        $('#que').fadeOut("fast");
      });
  });
</script>


