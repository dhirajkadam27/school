<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

$samecart = false; 
$samecart1 = false; 
$samecart2 = false; 

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/config.php';
error_reporting(0);
$display1 = "none";
$displayall = "block";
$id = $_GET['id'];
if(isset($_GET['title'])){
    $all = $_GET['title'];
    $br = $_GET['title'];
    $br = str_ireplace(" ", "-", $br);
}
$resulturl['FK_P'] = "";
$resulturl['BK_P'] = "";
$resulturl['AZ_P'] = "";
include('Connection/seo.php');
$queryurl = "SELECT * FROM url WHERE id=".$id."";
$dataurl = mysqli_query($conn, $queryurl);
    $min = array();
    $resulturl = mysqli_fetch_assoc($dataurl);
    if(!empty($resulturl['FK_P'])){
        $min[] = $resulturl['FK_P'];
    }
    if(!empty($resulturl['AZ_P'])){
        $min[] = $resulturl['AZ_P'];
    }
    if(!empty($resulturl['BK_P'])){
        $min[] = $resulturl['BK_P'];   
    }
    sort($min);
    $mino = $min[0];

    if(isset($mino)){

    if($resulturl['FK_P'] == $mino){
        $min_data = "SELECT * FROM data where sites = 'FK' AND productid = $resulturl[ID]";
        $post = "FK";
        $loto = "f";
    }
    if($resulturl['AZ_P'] == $mino){
        $min_data = "SELECT * FROM data where sites = 'AZ' AND productid = $resulturl[ID]";
        $post = "AZ";
        $loto = "a";
    }
    if($resulturl['BK_P'] == $mino){
        $min_data = "SELECT * FROM data where sites = 'BK' AND productid = $resulturl[ID]";
        $post = "BK";
        $loto = "b";
    }

    $data = mysqli_query($conn, $min_data);
$total = mysqli_num_rows($data);
$resul = mysqli_fetch_assoc($data); 
$pona = $resul['name'];
$pode = $resul['descp'];
$resul = str_ireplace("^", "'", $resul);

$resul["dis"] = ceil($mino/$resul["original"]*100);

$about = str_ireplace("~", '"', $resul["about"]);

if(strpos($mino, "-")!==false){
    $dano = substr($mino, 0 , strpos($mino, "."));
}
else{
     $dano = $mino;
}

  }

    if(isset($min[1])){
        
    if($resulturl['FK_P'] == $min[1]){
        $min_data1 = "SELECT * FROM data where sites = 'FK' AND productid = $resulturl[ID]";
        $post1 = "FK";
        $loto1 = "f";
    }
    if($resulturl['AZ_P'] == $min[1]){
        $min_data1 = "SELECT * FROM data where sites = 'AZ' AND productid = $resulturl[ID]";
        $post1 = "AZ";
        $loto1 = "a";
    }
    if($resulturl['BK_P'] == $min[1]){
        $min_data1 = "SELECT * FROM data where sites = 'BK' AND productid = $resulturl[ID]";
        $post1 = "BK";
        $loto1 = "b";
    }

    $data1 = mysqli_query($conn, $min_data1);
$total1 = mysqli_num_rows($data1);
$resul1 = mysqli_fetch_assoc($data1);
$pona1 = $resul['name1'];
$pode1 = $resul['descp1']; 
$resul1 = str_ireplace("^", "'", $resul1);

$resul1["dis"] = ceil($min[1]/$resul1["original"]*100);

$about1 = str_ireplace("~", '"', $resul1["about"]);

if(strpos($min[1], "-")!==false){
    $dano1 = substr($min[1], 0 , strpos($min[1], "."));
}
else{
     $dano1 = $min[1];
}



}

if(isset($min[2])){
        
    if($resulturl['FK_P'] == $min[2]){
        $min_data2 = "SELECT * FROM data where sites = 'FK' AND productid = $resulturl[ID]";
        $post2 = "FK";
        $loto2 = "f";
    }
    if($resulturl['AZ_P'] == $min[2]){
        $min_data2 = "SELECT * FROM data where sites = 'AZ' AND productid = $resulturl[ID]";
        $post2 = "AZ";
        $loto2 = "a";
    }
    if($resulturl['BK_P'] == $min[2]){
        $min_data2 = "SELECT * FROM data where sites = 'BK' AND productid = $resulturl[ID]";
        $post2 = "BK";
        $loto2 = "b";
    }


    $data2 = mysqli_query($conn, $min_data2);
$total2 = mysqli_num_rows($data2);
$resul2 = mysqli_fetch_assoc($data2); 
$pona2 = $resul['name'];
$pode2 = $resul['descp'];
$resul2 = str_ireplace("^", "'", $resul2);

$resul2["dis"] = ceil($min[2]/$resul2["original"]*100);

$about2 = str_ireplace("~", '"', $resul2["about"]);

if(strpos($min[2], "-")!==false){
    $dano2 = substr($min[2], 0 , strpos($min[2], "."));
}
else{
     $dano2 = $min[2];
}

}

// if(empty($resul["ID"])){
//     $display1 = "block";
//     $displayall = "none";
//  }
//  if(empty($resul["productid"])){
//     $display1 = "block";
//     $displayall = "none";
//  }
//  if(empty($resul["name"])){
//     $display1 = "block";
//     $displayall = "none";
//  }
//  if(empty($resul["descp"])){
//     $display1 = "block";
//     $displayall = "none";
//  }
//  if(empty($mino)){
//     $display1 = "block";
//     $displayall = "none";
//  }
//  if(empty($resul["image1"])){
//     $display1 = "block";
//     $displayall = "none";
//  }
?>
<html>
<head>
  <script src="/Assets/Js/JQuery.js"></script>
  <script src="/Assets/Js/search.js"></script>
  <meta name='viewport' content='width=device-width, initial-scale=1'>


  <script>
  
 function crossm(){
    document.getElementById("allm").style.left = '-100%';
}


 function plusm(){
    document.getElementById("allm").style.left = '0';
}

function crossw(){
    document.getElementById("allw").style.left = '-100%';
}


 function plusw(){
    document.getElementById("allw").style.left = '0';
}

function crossk(){
    document.getElementById("allk").style.left = '-100%';
}


 function plusk(){
    document.getElementById("allk").style.left = '0';
}

</script>





  <style>
 body{
                margin: 0;
                padding: 0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

                background: #f1f1f1;
            }
            img[alt="www.000webhost.com"]{
               display: none;
           } 

            .loadbg1{
            width: 100%;
            height: 100vh;
            position: fixed;
            top:0;
            z-index:4
        }
        .loader1{
            box-shadow:1px 1px 10px 1px #a9a9a9;
            display: flex;
            position: absolute;
            top: 50%;
            left: 50%;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width: 45px;
            height: 45px;
            margin: 7px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }


        .prodetail img{
    display: none;
}
.prodetail button{
    display: none
}
.prodetail a{
    display: none
}


        @media only screen and (min-width:320px) and (max-width: 480px){
            .nav{
                background:gold;
                width:100%;
                height:50px;
                position: absolute;
                top: 0;
                z-index:5;
                display:flex;
            }

            .mobinav{
                background:gold;
                width:100%;
                height:50px;
                position: fixed;
                top: -50px;
                z-index:4;
                display:flex;
            }
         .bao img{
            width: 23px;
            margin-top: 13px;
            margin-left: 7px;
            margin-right: 10px;
         }
         .namo{
            width: 210px;
            line-height:50px;
            font-weight: 600;
            font-size: 19px;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
         }
         .roto{
             display:flex;
             position:absolute;
             right:0
         }
         .seao img{
            width: 26px;
           margin-top: 10px;
           margin-right: 17px;
         }
         .carto{
             position:relative;
             margin-right: 8px;
         }
         .carto img{
            width: 30px;
           margin-top: 9px;
           margin-right: 14px;
         }
         .slicon{
                position: initial;
                z-index: 5;
                width:20px;
                height:20px;
                margin: 15px 15px 0px 15px
            }

            .left{
		 width:80%;
		 height:100%;
		 position:fixed;
         top:0;
		 left:-90%;
         z-index:7;
		 background:white;
         transition-property:left;
         transition-duration: 0.3s

		 }
		    
    .menu > ul{
        list-style:none;
        padding:0;
        margin:0;
        position:relative;
        
    }
    .menu li{
        display:flex
    }
    .menu li > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size: 20px
     }
    .menu li > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }
    .meals{
        display:flex;
        width: 100%;
    }
    .menu li div > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size:20px;
        pointer-events: none;
     }
    .menu li div > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }
    .vial img{
        margin-left: 130px;
    position: absolute;
    right: 18px;
    width: 32px;
    }

    .arro{
        display:none
    }
    .plus{
        width: 20px;
    margin-right: 7px;
    margin-top: 4px;
    }
    .menu ul > li:hover{
        background: rgb(221, 221, 221);
    }
    .all{
        background: white;
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100vh;
        display: block;
        z-index: 3;
        text-align: center;
        transition-property:left;
        transition-duration: 0.3s
    }

 
    .cross{
        width: 37px;
        transform: rotate(45deg);
        margin-top:-5px
    }
    .cross:hover + .all{
        left: -100%;
    }
    .menu li:hover .all{
        left: 0;
    }
    .all li{
    padding: 10px 0;
    }
    .all li:hover{
        background: #ededed;
    }
    .celo{
        display:block;
    }
    .self{
        display:block;
      
    }
    .self ul{
        padding:0;
        margin:10px 22px;
        font-size: 20px
    }
    .self a{
        text-decoration:none;
        color: black
    }
   
    .self a:hover{
        color: red;
        font-size:17px;
    }
    .til{
        font-size: 25px;
    font-weight: 500;
    margin-top: -1px;
    }
    .til p{
        display: none
    }
    .til img{
        width: 115px;
    }
.sein{
    display:none;
    border-bottom:1px solid black;
}
.fullwhite{
    width: 100%;
    height: 100vh;
    background: white;
    top: 50px;
    position: fixed;
    left: 0;
}
.sein input{
    width: 90%;
    top: 0;
    position: fixed;
    right: 0;
    z-index: 5;
    height: 50px;
    border: none;
    outline: none;
    border-bottom: 1px solid #b1b1b1;
}

#que ul{
            width:100%;
      background: #fff;
      color: #000;
      text-align:left;
      padding:0;
             
    }
    #que a{
        color: black;
        text-decoration: none
    }
    #que li{
      padding: 10px 15px;
      cursor: pointer;
      color: black;
      list-style:none;
    }
    #que li:hover{
      background: #f0f0f0;
    }
.base{
    width: 10%;
    top: -1px;
    position: fixed;
    left: 0;
    z-index:5;
    height: 50px;
    background:white;
    border-bottom: 1px solid #b1b1b1;
         }
         .sese{
            position: fixed;
            right: 16px;
            top: 10px;
            z-index: 6;
            background: white;
         }
         .sese img{
            width: 25px;
         }
         .sese button{
             background:white;
             border:none
         }
         .sug{
            width: 100%;
    height: 100vh;
    background: white;
    top: 36px;
    position: fixed;
    left: 0;
    overflow-y: auto;
         }
         .base img{
    width: 22px;
    margin-top: 15px;
    margin-left: 6px;
         }
.search{
    display:none
}
.rity{
    position:absolute;
    right:0;
    display:flex
}

.sear img{
    width:25px;
    height:25px;
    margin-top: 12px;
    margin-right: 17px;
}
.cart{
    display: flex;
    position:relative;
    margin-right:7px
}
.cart img{
    width:30px;
    height:30px;
    margin-top:10px;
    margin-right:12px
}
.mobilog{
    margin-top: 13px;
    margin-right: 10px;
}
.mobilog a{
    text-decoration: none;
    color: black;
    font-weight: 600;
}
.mobilog img{
    width: 27px;
    height: 30px;
}
.noti{
             position:absolute;
             top:0;
             right:0;
            width:16px;
             font-size:12px;
             color: white;
             font-weight: bold;
             background: rgb(255, 0, 0);
             border:4px solid gold;
             padding:2px;
             border-radius:50%;
             text-align:center
}
.log{
    display:none
}

.act{
    display:none
}
.sliderbg{
    width:100%;
    height:100%;
    background: #0a0a0a70;
    position:fixed;
    top:0;
    left:0;
    z-index:4;
    visibility:hidden;
    transition: visibility 0.1s;
}
.sliderbg2{
    width:100%;
    height:50px;
    background: #0a0a0a70;
    position:fixed;
    top:0;
    left:0;
    z-index:4;
    visibility:hidden;
    transition: visibility 0.1s;
}

.main{
    width:100%;
    background:white;
    position:absolute;
    top:60px;
}
.bread{
    display: none
}
.part1{
    width:100%;
    display:block;
}
.proimg{
    width:100%;
}
.alignthis{
    width:100%
}
.bt{
    display:none
}

.mobibt{
    width:100%;
    display:flex;
    position:sticky;
    bottom:0;
    background: white;
}
.mobibt1{
    width:50%;
    height:50px;
    font-size:17px;
    font-weight:bold;
    border:none;
}
.mobibt2{
    width:50%;
    height:50px;
    font-size:17px;
    font-weight:bold;
    border:none;
}
.mobibt1{
    background:red;
    color:white
}
.mobibt2{
    background:gold;
    color:black
}






.prodet{
    width:100%;
    height:100%;
}
.pdes p{
    margin:0
}
.ptit{
    color: black;
    margin-left: 15px;
    font-weight: 500;
    margin-top: 20px;
}
.pdes{
    margin-left:15px;
    margin-top:5px;
  color: rgb(133, 133, 133);
}

.pricing{
    display:flex;
    margin-left:15px
}
.pro-price{
    font-weight: 500;
    font-size: 30px;
    margin-right: 10px;
}
.pro-dash{
    font-weight: bold;
    font-size: 13px;
    margin-right: 10px;
    color: rgb(133, 133, 133);
    margin-top: 19px;
}
.pro-dis{
    font-size: 10px;
    font-weight: bold;
    margin-right: 10px;
    color: orange;
    background: rgba(0, 0, 0, 0.056);
    border-radius: 5px;
    border: 1px solid orange;
    height: 11px;
    padding: 5px;
    margin-top: 14px;
}
        .sizes{
        margin-top: 15px;
        padding: 10px 15px;
        border-top: 8px solid #f1f1f1;
        border-bottom: 5px solid #f1f1f1;
}
.sel-size{
    width:100%;
    padding-top: 10px;
    display:flex;
    margin:5px
}

.javasizes button{
    padding: 10px 15px;
    border: 2px solid #c1c1c1;
    background: white;
    border-radius: 7px;
    margin: 0 5px;
}

.prodet p{
    margin:0
}
.javacolor{
    padding: 10px 15px;
    border-bottom: 5px solid #f1f1f1;
}
.javacolor button{
    padding: 10px 15px;
    border: 2px solid #c1c1c1;
    background: white;
    border-radius: 7px;
    margin: 6px;
}
.javastyle{
    padding: 10px 15px;
    border-bottom: 5px solid #f1f1f1;
}
.javastyle button{
    padding: 10px 15px;
    border: 2px solid #c1c1c1;
    background: white;
    border-radius: 7px;
    margin: 6px;
}
.deliver{
    margin:10px 0;
    border-bottom: 10px solid #f1f1f1;
    padding-bottom: 15px;
}
#box img{
    margin-bottom: -6px;
}
#cod img{
    margin-bottom: -6px;
}
#deli img{
    margin-bottom: -6px;
}
#free img{
    margin-bottom: -6px;
}
.deliver img{
    width: 20px;
    margin-right: 10px
}
.pin{
    border-radius: 5px;
    border: 1px solid #00000029;
    box-shadow: 0 1px 10px rgba(1,1,1,.08);
    padding: 10px;
    font-size: 16px;
    outline: 0;
    width: 250px;
    margin-left: 25px;
}
.pinbtn{
    border: none;
    padding: 10px;
    font-size: 16px;
    outline: 0;
    background:none;
    color: #ff3e6c;
    font-weight:bold;
    margin-left: 172px;
    margin-top: -38px;
}
.pin-is{
    color: #00b516;
    margin: 10px 25px;
}
.deliver-title{
    font-weight: 500;
    margin-bottom: 10px;
    margin-left: 25px;
    margin-top: 15px;
}
.deliver-des span{
    line-height: 35px;
    font-size: 13px;
    padding-left: 20px;
    display: block;
}
.proinfo{
    margin-top: 10px;
    border-top: 10px solid #f1f1f1;
    border-bottom: 10px solid #f1f1f1;
    padding-bottom: 10px;
}
.protitle{
    font-weight: 500;
    margin-top: 20px;
    margin-bottom: 15px;
    margin-left: 15px;
}

.prodetail{
    margin: 5px 15px;
    height: 88px;
    overflow: hidden;
    position: relative;
}
.readmor img{
    width: 25px;
    transform: rotate(90deg);
    margin-bottom: -3px;
    margin-left: 3px;
    display:flex;
}
.readmor button{
    font-weight: 600;
    font-size: 15px;
    border: none;
    background: none;
    color: #fc2727;
    display:flex;
}
.readmor {
    position: absolute;
    bottom: 0;
    width: 100%;
    background: white;
    padding-top: 10px;
    padding-bottom: 2px;
}
.readless img{
    width: 25px;
    transform: rotate(270deg);
    margin-bottom: -3px;
    margin-left: 3px;
    display:flex;
}
.readless button{
    font-weight: 600;
    font-size: 15px;
    border: none;
    background: none;
    color: #fc2727;
    margin-bottom:5px;
    display:flex;
}

.prodetail pre{
    white-space: unset;
   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
   display: inline;
    font-size:17px
}
.prodetail p{
    margin-bottom:10px
}
.prodetail strong{
    font-weight: 500;
    color: #7b7b7b;
}
.part2{
    width:100%;
    border-top: 10px solid #f1f1f1;
}
.related{
    font-size: 20px;
    font-weight: 500;
    margin-top: 12px;
    margin-left: 14px;
}

.rece{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    padding-top: 15px;
    border-bottom: 20px solid #f1f1f1;
}

.box{
    width:48%;
    background:white;
    border: 1px solid #f5f5f5
}
.box:hover{
    box-shadow: 1px 1px 10px 2px #dadada;
}
.img{
    width:100%;
    height: 200px;
    text-align:center;
    margin-bottom:1px
}

.img img{
    max-width: 100%;
    height: 200px;
    background: #e5edff
}

.name{
    width:90%;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    margin-left: 15px;
    font-weight: 700;
    color: #a2a2a2;
    margin-top: 5px;
    font-size:10px
}
.descp{
    width:90%;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    margin-left: 15px;
    font-size:12px
}
.value{
    display:flex
}
.price{
    margin-left: 15px;
    margin-right: 10px;
    margin-bottom: 9px;
    font-size: 16px;
    font-weight: 700;
}
.mrp{
    margin-right: 5px;
    font-size:10px;
    color: #a4a4a4;
    font-weight: 600;
    margin-top:5px
}
.dis{
    color: red;
    font-weight: 600;
    font-size:10px;
    margin-top:5px
}

.part3{
    width:100%;
}


.error-sec{
                width: 100%;
    height:90%;
    background: white;
    position: absolute;
    top: 50;
    z-index: 2;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}
.error-alerts1{
    font-size: 38px;
    font-weight: 700;
    color: red;
}
.error-alerts2{
    font-size: 38px;
    font-weight: 700;
    color: gold;
    margin-top: -54px;
    margin-left: 5px;
}
.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}


.mobifoot{
    width:100%;
    background: #f1f1f1;
    padding-top: 1px;
    padding-bottom: 5px;
}
.mofo{
    width: 50%;
    margin: 5px 25%;
    display: flex;
}
.foimg img{
    width:35px;
    padding-top: 1px;
}
.fosub{
    padding-left: 10px;
    font-size: 10px;
}
        footer{
            background-color: #f9f9f9;
    width: 100%;
    color: #5d5d5d;
    font-size: 18px;
}
          
         .foot{
            display: block;
    margin-left: 20px;
    padding-top: 10px;
         }
         .ter li{
           font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
           font-size: 14px;
         }
         
         
         .ter ul{
             list-style-type:none;
             padding: 0 10px;
         }
         .ter b{
            color: #797979;
            font-size: 18px;
    display: block;
    margin-bottom: 5px;
         }
         .ter a{
            text-decoration: none;
    color: #777777;
         }
         
         .foot a:hover{
             color: black
         }
         .goog{
        }
         .goog img{
            margin-top: 15px;
    width: 120px;
    margin-left: 30px;
         }
         .cood img{
            margin-top: 20px;
    width: 130px;
    margin-left: 20px;
         }
         .ter1{
            margin-top: 10px;
    margin-left: 10px;
         }
         .ter1 b{
            font-size: 15px;
         }
         .copy{
            width: 100%;
    text-align: center;
    margin-top: 20px;
    padding-bottom: 10px;
    padding-top: 8px;
    border-top: 1px solid #c5c5c5;
    font-size: 10px;
         }
         .deals{
    width: 100%;
    padding-bottom:10px
}
.tode{
    width: 90px;
    font-size: 25px;
    font-weight: bold;
    margin: 14px 10px;
    border-bottom: 4px solid #2196f3;
}

.lower{
    width: 90%;
    height: 100px;
    margin-bottom: 10px;
    border-radius: 10px;
    box-shadow: 1px 1px 10px 2px #e8e8e8;
    display: flex;
    margin-left: 5%;
}
.lowimg{
    width: 60%;
    margin-top: 30px;
    margin-left: 20px;
}
.lowimg img{
    width: 60%;
}
.lowprice{
    font-size: 30px;
    font-weight: bold;
    line-height: 100px;
}
.lower:first-child{
    background: #2196f342;
}
.loto{
    width: fit-content;
    background: #ffffff;
    padding: 8px;
    border-radius: 10px;
    margin-top: 10px;
    margin-left: 18px;
    box-shadow: 1px 1px 6px 1px #0000002e;
}
.loto img{
    width: 120px;
}
.thumbo{
    width: 100%;
    height: 400px;
    margin-top: 10px;
    text-align: center;
}
.thumbo img{
    max-width: 100%;
    height: 400px;
		}
		.smthumbo{
			display: flex;
            width: 100%;
            height: 80px;
            overflow: hidden;
		}
		.smthumbo img{
			max-width: 50px;
            height: 60px;
            margin: 10px;
		}



 }


        /* max size */
        @media only screen and (min-width:800px){

      		/*Nav Bar Css*/
              .nav{
                background:gold;
                width:100%;
                height:70px;
                position: fixed;
                z-index:4;
                display:flex;
            }

            .til{
                    font-family: Verdana, Geneva, Tahoma, sans-serif;
    font-weight: bold;
    font-size: 36px;
    color: black;
    margin-left: 90px;
    margin-top: -6px;
         }
         .til p{
             display: none
         }
         .til img{
            width: 175px;
         }
         .cart{
             right:21px;
             top:6px;
             position:fixed;
             padding:5px;
           
         }
        .mobinav{
            display:none
        }
         .cart img{
             width:40px;
             height:40px;
             margin-right:11px;
             margin-top:7px
         }
         .noti{
             width:20px;
             position:absolute;
             top:0;
             right:0;
             color: white;
             font-weight: bold;
             background: rgb(255, 0, 0);
             border:4px solid gold;
             padding:4px;
             border-radius:50%;
             text-align:center
         }
         .act{
            right:100px;
             top:16px;
             position:fixed;
             text-align:right;
         }
       .act img{
           width:45px;
           height:45px
       }
       .act:hover .crete{
           display:block
       }
       .crete{
           width:220px;
           height:258px;
           background:white;
           box-shadow: 0 1px 10px rgba(1,1,1,.25);
           display:none;
           margin-right:-60px;
           margin-top:17px;
           padding:10px 5px
       }
       .tobo{
           margin:0 15px;
           text-align:left
       }
       .tobo a{
           display:block;
           text-decoration:none
       }
       .weec{
        font-weight:bold;
       }
       .usna{
           border-bottom: 1px solid goldenrod;
           color:black;
           font-size:19px;
           padding-top: 3px;
           padding-bottom:7px
       }
       .crea a{
           display:block;
           font-size:17px;
           text-align:left;
           padding:8px 15px;
           text-decoration:none;
           color: black;
       }
       .crete button{
         width:180px;
         height:30px;
         outline:none;
         border:none;
         background:gold;
         color:black;
         border-radius:5px;
         margin:10px 0;
       }
       .logbt{
            display:block;
           text-align:center;
           width:100%;
       }
       .crea a:hover{
           font-weight:bold;
       }
         .search{
             position:fixed;
             top:15px;
             right:255px;
         }
         
         .search img{
             width:22px;
             height:22px;
			 margin-top:2px
         }
         .base{
             display:none
         }
         .search button{
            border-radius:0 5px 5px 0;
			border:none;
             padding: 7px 12px;
			 background:rgb(92, 92, 92);
			 color:white;
			 display:flex
         }
		 .search p{
		 margin:6px 4px;
		 }
         .sese{
             display:none
         }
         .sein{
             display:block;
             margin-top:14px;
             position:fixed;
             right:351px;
         }
         .sug{
            width:390px;
            height:275px;
            background:white;
			display:none
         }
         .sein input{
             width:390px;
             height:40px;
			 outline:none;
			 border-radius:5px 0 0 5px;
			 border:none;
			 font-size:15px;
			 padding-left:15px;
         }
         .fullwhite{
             display:none
         }
         #que ul{
            width:390px;
      background: #fff;
      color: #000;
      text-align:left;
      padding:0;
             
    }
    #que a{
        color: black;
        text-decoration: none
    }
    #que li{
      padding: 10px 15px;
      cursor: pointer;
      color: black;
      list-style:none;
    }
    #que li:hover{
      background: #f0f0f0;
    }
	    .log{
            right:120px;
             top:21px;
             position:fixed;
             font-size: 20px;
         }
         .mobilog{
             display:none
         }
         .log a{
             text-decoration:none;
             color:black;
             background:  rgb(255, 226, 64);
             padding:2px 10px;
             padding-bottom:5px;
             border-radius:7px;
             border:2.5px solid black
         }
         .sear{
            display:none
         }
		 /*Nav Bar Css End */
	
		  
		   /*Vertical Menu Bar*/
		 .slide{
		 position:fixed;
		 padding:17px 28px 22px 24px;
		 }
   
         .slicon{
            width:30px;
            height:30px
         }
		 .left{
		 width:200px;
		 height:100%;
		 margin-top:23px;
		 position:fixed;
		 left:-200px;
		 background:white;
         transition-property:left;
         transition-duration: 0.3s

		 }
		    
    .menu > ul{
        list-style:none;
        padding:0;
        margin:0;
        position:relative
    }
    .menu li{
        display:flex
    }
    .menu li > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size:17px;
     }
    .menu li > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }


    .meals{
        display:flex
    }
    .menu li div > a{
        flex-basis:80%;
        text-decoration:none;
        color:black;
        display:block;
        padding:10px 29px;
        font-size:17px;
     }
    .menu li div > span{
        font-size:15px;
        color:green;
        flex-basis:20%;
        position:absolute;
        right:0;
        margin-top:7px
    }
    
    .plus{
        display:none
    }
    .arro{
        width:20px;
margin-top:5px
    }

    .menu ul > li:hover{
        background: rgb(221, 221, 221);
    }
    .all{
        background: gold;
    position: absolute;
    left: 100%;
    display: none;
    z-index: 3;
    height: 80%;
    position: absolute;
    top: 10px;
    }
    .cross{
        display:none
    }
    .menu li:hover .all{
        display:block
    }
    .celo{
        display:block;
    }
    .self{
        display: inline-block;
        margin: 5px 2px;
    }
    .self ul{
        padding:0;
        margin: 5px 22px;
        white-space: nowrap;
    }
    .self a{
        text-decoration:none;
        color: black
    }
   
    .self a:hover{
        color: red;
        font-size:17px;
    }
/*Vertical Menu Bar End*/
.sliderbg{
    width:100%;
    height:100%;
    background: #0a0a0a70;
    position:fixed;
    top:0;
    left:0;
    z-index:3;
   visibility: hidden
}

.main{
    width:100%;
    background:white;
    position:absolute;
    top:70px;
}


.part1{
    width:100%;
    display:flex;
}
.proimg{
    width:40%;
}
.alignthis{
    position:sticky;
    top:100px
}

.mobibt{
    display:none
}
.bt{
    width:100%;
    height:60px;
    display:flex;
    justify-content:space-evenly
}
.bt1{
    width:45%;
    height:50px;
    margin-top:5px;
    font-size:17px;
    font-weight:bold;
    border:none;
    border-radius:5px 
}
.bt2{
    width:45%;
    height:50px;
    margin-top:5px;
    font-size:17px;
    font-weight:bold;
    border:none;
    border-radius:5px 
}
.bt1{
    background:red;
    color:white
}
.bt2{
    background:gold;
    color:black
}






.prodet{
    width:60%;
    height:100%;
    padding-left:10px;
    padding-bottom:10px
}
.pdes p{
    margin:0
}
.ptit{
    color:  black;
    margin-left:15px;
    margin-top:10px;
  

}
.pdes{
    margin-left:15px;
    margin-top:5px;
  color: rgb(133, 133, 133);
}

.pricing{
    display:flex;
    margin-left:15px;
}
.pro-price{
  
   font-weight:bold;
   font-size:45px;
   margin-right:10px;
}
.pro-dash{
  
   font-weight:bold;
   font-size:20px;
   margin-right:10px;
   color: rgb(133, 133, 133);
   margin-top:29px
}
.pro-dis{
  
   font-size:15px;
   font-weight:bold;
   margin-right:10px;
   color: orange;
   background: rgba(0, 0, 0, 0.056);
   border-radius:5px;
   border:1px solid orange;
   height: 20px;
   padding:4px;
   margin-top:27px
}
        .sizes{
    border-radius:5px;
  
  
}
.sel-size{
    width:100%;
    height:35px;
    padding:15px 0;
    display:flex;
    margin:5px
}

.javasizes button{
    padding: 10px 15px;
    border: 2px solid #c1c1c1;
    background: white;
    border-radius: 7px;
    margin: 0 5px;
}
.javacolor{
    margin-top: 15px;
}
.javacolor button{ 
    padding: 10px 15px;
    border: 2px solid #c1c1c1;
    background: white;
    border-radius: 7px;
    margin: 0 5px;
}
.javacolor p{
    padding-bottom: 20px;
}
.javastyle button{
    padding: 10px 15px;
    border: 2px solid #c1c1c1;
    background: white;
    border-radius: 7px;
    margin: 0 5px;
}
.javacolor button:first-child{
    background: gold;
}

.javastyle{
    margin-top: 15px;
}
.javastyle p{
    padding-bottom: 20px;
}

.prodet p{
    margin:0
}
.deliver{
    margin:10px 0;
}
.pin{
    border-radius: 5px;
    border: 1px solid #00000029;
    box-shadow: 0 1px 10px rgba(1,1,1,.08);
    padding: 10px;
    font-size: 16px;
    outline: 0;
    width: 250px;
}
.pinbtn{
    border: none;
    padding: 10px;
    font-size: 16px;
    outline: 0;
    background:none;
    color: #ff3e6c;
    font-weight:bold;
    margin-left:-75px
}
.pin-is{
    color: #00b516;
    margin: 10px 5px;
}
.deliver-title{
    font-weight:bold;
    margin-bottom:10px
}
.deliver-des span{
    line-height:35px;
    display:block;
    margin-top:5px
}
.deliver-des img{
    width:20px;
    margin-bottom: -7px;
    margin-right:10px
}
.proinfo{
    margin-top:10px;
   
}
.protitle{
    font-weight:bold;
    margin-top:25px;
    margin-bottom:5px
}
.prodetail{
    width: 80%;
}
.prodetail button{
   display: none
}
.readmor {
  display: none
}
.readless {
  display: none
}
.prodetail pre{
    white-space: unset;
   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

    font-size:17px
}
.prodetail p{
    margin-bottom:10px
}
.prodetail strong{
    font-weight: 500;
    color: #7b7b7b;
}
.part2{
    width:100%;
  
}
.related{
    width: 90%;
    font-size: 28px;
    font-weight: 600;
    margin-top: 12px;
    margin-left: 45px;
    border-bottom: 2px solid black;
}

.rece{
    width:100%;
    padding:10px 5px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}
.box{
    width:23%;
    background:white;
    margin:10px 5px;
}
.box:hover{
    box-shadow: 1px 1px 10px 2px #dadada;
}
.img{
    width:100%;
    height: 255px;
    text-align:center;
    margin-bottom:1px
}

.img img{
    max-width: 90%;
    height: 255px;
}

.name{
    width:90%;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    margin-left: 15px;
    font-weight: 700;
    color: #a2a2a2;
    margin-top: 5px;
}
.descp{
    width:90%;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    margin-left: 15px;
}
.value{
    display:flex
}
.price{
    margin-left: 15px;
    margin-right: 10px;
    margin-bottom: 9px;
}
.mrp{
    margin-right: 5px;
}
.dis{
    color: red;
    font-weight: 600;
}
.part3{
    width:100%;
}


.error-sec{
                width: 100%;
    height:90%;
    background: white;
    position: absolute;
    top: 50;
    z-index: 2;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}
.error-alerts1{
    font-size: 38px;
    font-weight: 700;
    color: red;
}
.error-alerts2{
    font-size: 38px;
    font-weight: 700;
    color: gold;
    margin-top: -54px;
    margin-left: 5px;
}
.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}


.mobifoot{
    display: none
}
footer{
    background-color: #f9f9f9;
    width: 100%;
    color: #5d5d5d;
}
          
          
         .foot{
             display:flex;
             justify-content: center;
         }
         .ter li{
           font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

         }
         
         
         .ter ul{
             list-style-type:none;
         }
          .ter b{
            color: #797979;
            font-size: 15px;
    display: block;
    margin-bottom: 5px;
         }         .ter a{
            text-decoration: none;
    color: #777777;
         }
         
         .foot a:hover{
             color: black
         }
         .goog{
            margin-left: 15px;
        }
         .goog img{
             margin-top:15px;
             width: 150px;
    margin-left: 11px;
         }
         .cood img{
            margin-top: 28px;
            width: 180px;
         }
         .ter1{
            margin-top: 20px;
            margin-left: 30px;
         }
         .copy{
            width: 100%;
    text-align: center;
    margin-top: 20px;
    padding-bottom: 10px;
    padding-top: 10px;
    border-top: 1px solid #c5c5c5;
         }
         .bread{
             color: #585858;
             margin-top: 10px;
          margin-left: 30px;
          }
         .bread a{
            text-decoration:none;
            color:#4189ff;
         }
         .bread img{
             width:15px;
             margin:0 5px;
             margin-bottom:-2px;
         }

         .deals{
    width: 100%;
    padding-bottom:10px
}
.tode{
    width: 90px;
    font-size: 25px;
    font-weight: bold;
    margin: 14px 10px;
    border-bottom: 4px solid #2196f3;
}

.lower{
    width: 60%;
    height: 100px;
    margin-bottom: 10px;
    border-radius: 10px;
    box-shadow: 1px 1px 10px 2px #e8e8e8;
    display: flex;
}
.lowimg{
    width: 60%;
    margin-top: 30px;
    margin-left: 20px;
}
.lowimg img{
    width: 60%;
}
.lowprice{
    font-size: 30px;
    font-weight: bold;
    line-height: 100px;
}
.lower:first-child{
    background: #2196f342;
}
.loto{
    width: fit-content;
    background: #ffffff;
    padding: 8px;
    border-radius: 10px;
    margin-top: 10px;
    margin-left: 18px;
    margin-bottom: 6px;
    box-shadow: 1px 1px 6px 1px #0000002e;
}
.loto img{
    width: 140px;
}

.thumbo{
    width: 400px;
    height: 400px;
    margin-top: 10px;
    text-align: center;
}
.thumbo img{
    max-width: 400px;
    height: 400px;
		}
		.smthumbo{
			display: flex;
            width: 400px;
            height: 80px;
            overflow: hidden;
		}
		.smthumbo img{
			max-width: 50px;
            height: 60px;
		}
        .boxy{
            max-width: 50px;
            height: 60px;
            margin: 10px;
            text-align: center;
        }

    }


#par1{
    display: none
}
#par2{
    display: none
}

.col, .row {
    width: 100%;
    display:flex
}
._3TOw5k ._2yIA0Y ._2cLjiM {
    font-size: 24px;
    padding: 32px 0 32px 24px;
    font-weight: 500;
}
._1v8OXw ._2H87wv, ._1v8OXw ._2vZqPX {
    padding-bottom: 24px;
}
._1v8OXw ._2H87wv {
    color: #878787;
    font-weight: 500;
    font-size: 14px;
}
.col-9-12 {
    width: 75%;
}
</style>
</head>
<body onload="load1()">

<div id="load1" class="loadbg1">

<div class="loader1">
    <img src="/Assets/Icons/loader.gif">
</div>

</div>


<div id="mobinav" class="mobinav">
<div class="bao"><img id="lonoz2" onclick="window.history.back()" src="/Assets/Icons/arrowl.png"></div>
<div id="titl" class="namo"><?php echo $resul['descp'] ?></div>

<div class="roto">
<div onclick="seaa()" class="seao"><img src="/Assets/Icons/search b.png"></div>
<div class="carto"><img onclick="window.location.href='/Cart'" src="/Assets/Icons/bag.png">
<?php 
   $count = 0;
   if(isset($_SESSION['cart'])){
   $count = count($_SESSION['cart']);
   }
   if($count == 0){
       echo
   '<div style="display:none" id="noti1" class="noti">'.$count.'</div>';
   }
   if($count > 0){
    echo
'<div style="display:block" id="noti1" class="noti">'.$count.'</div>';
}
   ?>
</div>
</div>
</div>







       <div class="nav">
       <div id="ridss2" class="sliderbg2"></div>
	   <!--Vertical Slider Img-->
	    <div class="slide">
    <img class="slicon" src="/Assets/Icons/menu.png">
	<!--Vertical Slider Starts-->
	<div class="left">
	<!--Vertical Slider Menu Starts-->
    <div class="menu">
<ul>
<?php
require('Connection/connect.php');
if(isset($_SESSION['no'])){
    $num = $_SESSION['no'];
    $soy = "SELECT * FROM users where number = $num";
    $us = mysqli_query($conn, $soy);
    $net = mysqli_num_rows($us);
    $result = mysqli_fetch_assoc($us);
    if($net!=0){
            $name = $result['fn'];
echo "<li style='background:gold;'><a style='font-family: Verdana, Geneva, Tahoma, sans-serif;font-size:18px;padding: 15px 25px;' href='/Account'>Hello,&nbsp;";
if(empty($name)){
echo "Customer";
}
if(!empty($name)){
    echo $name;
}
echo "</a></li>";
        
}
}
   ?>


<li><a href="/">Home</a></li>
<li><a href="/Shop/All">All Catagory</a></li>
<li><div class="meals" onclick="plusm()"><a id="lono1as" href="/Shop/Men">Men</a><span><img class="plus"  src="/Assets/Icons/plus.png"><img class="arro" src="/Assets/Icons/arrow.png"></span></div>
    <div id="allm" class="all">
        <div class="celo">
            <div class="self">
         <ul>
         <a class="vial"><li><b onclick="window.location.href='/Shop/Men'">View All</b><img class="cross" onclick="crossm()" src="/Assets/Icons/plus.png"></li></a>
         <a href="/men-topwear"><li><b>TopWear</b></li></a>
         <a href="/men-tshirts"><li>T-shirts</li></a>
         <a href="/men-casual-shirts"><li>Casual Shirts</li></a>
         <a href="/men-formal-shirts"><li>Formal Shirts</li></a>
        </ul>
</div>
<div class="self">
<ul>
         <a href="/men-bottomwear"><li><b>BottomWear</b></li></a>
         <a href="/men-jeans"><li>Jeans</li></a>
         <a href="/men-shorts"><li>Shorts</li></a>
         <a href="/men-trousers"><li>Trousers</li></a>
        </ul>
</div>
<div class="self">
<ul>
         <a href="/men-ethnic-wear"><li><b>Ethnic Wear</b></li></a>
         <a href="/men-kurtas"><li>Kurtas</li></a>
         <a href="/men-ethnic-bottomwear"><li>Ethnic Bottomwear</li></a>
        </ul>
</div>

</div>
    </div>
    </li>

    <li   style="border-bottom: 1px solid #acacac;"><div class="meals" onclick="plusw()"><a id="lono1as" href="/Shop/Women">Women</a><span><img class="plus"  src="/Assets/Icons/plus.png"><img class="arro" src="/Assets/Icons/arrow.png"></span></div>
    <div id="allw" class="all">
        <div class="celo">
        <div class="self">
         <ul>
         <a class="vial"><li><b onclick="window.location.href='/Shop/Women'">View All</b><img class="cross" onclick="crossw()"  src="/Assets/Icons/plus.png"></li></a>
         <a href="women-tops"><li><b>Tops</b></li></a>
         <a href="women-tshirts"><li>T-Shirts</li></a>
         <a href="women-trousers"><li>Trousers</li></a>
         <a href="women-shorts"><li>Shorts</li></a>
        </ul>
</div>

        <div class="self">
         <ul>
         <a href="/women-ethnic-wear"><li><b>Ethnic Wear</b></li></a>
         <a href="/sarees"><li>Sarees</li></a>
         <a href="/women-Kurtas"><li>Kurtas</li></a>
         <a href="/women-ethnic-bottomwear"><li>Ethnic Bottomwear</li></a>
        </ul>
</div>

</div>
    </li>


<li><a href="/Account">My Account</a></li>
<li><a href="/Notifications">My Notification</a></li>
<li><a href="/Accounts/Orders">My Orders</a></li>
<li style="border-bottom: 1px solid #acacac;"><a href="/Cart">My Cart</a></li>
<li><a href="/Help">Help</a></li>
<li><a href="/Legal">Legal</a></li>
</ul>
</div>

		</div>
        </div>

		<!-- Vertical silder ends-->
		
        <div class="til">
          <p>Derbun</p><img src="/Assets/Icons/Logo.png">
        </div>
 


 <form action="/Search">
        <div id="sein" class="sein">
        <div onclick="closefullsearch()"  class="base"><img src="/Assets/Icons/arrowl.png"></div>
        <div class="fullwhite"></div>
        <div class="sese"><button><img src="/Assets/Icons/search b.png"></button></div>
        <input type="text" autocomplete="off" id="search" placeholder="Search the product" name="q">
        <div class="sug" id="que">
        <ul>
<li>Men Tshirts</li>
<li>Men Shirts</li>
<li>Mobiles</li>

        </ul>
        </div>
        </div>
        <div class="search">
        <button><img src="/Assets/Icons/search.png"><p>Search</p></button>
        </div>
</form>
<script>
function fullsearch(){
    document.getElementById("sein").style.display = 'block';
}

function closefullsearch(){
    document.getElementById("sein").style.display = 'none';
}

</script>
<div class="rity">
        <div class="sear"><img  onclick="fullsearch()" src="/Assets/Icons/search b.png"></div>
        <div class="cart">
   <a href="/Cart" ><img id="lonoz2" src="/Assets/Icons/bag.png"></a>
   <?php 
   $count = 0;
   if(isset($_SESSION['cart'])){
   $count = count($_SESSION['cart']);
   }
   if($count == 0){
    echo
'<div style="display:none" id="noti2" class="noti">'.$count.'</div>';
}
if($count > 0){
 echo
'<div style="display:block" id="noti2" class="noti">'.$count.'</div>';
}
   ?>
        </div>
        <div class="mobilog">
        <?php
        if(isset($_SESSION['no'])){
            echo '<img id="lonoz2" onclick=window.location.href="/Account" src="/Assets/Icons/user g.png">';
        }
            else{  
 echo '<a href="/Login?ref='.$_SERVER['REQUEST_URI'].'">Login</a>';
        }
        ?>
</div>

  </div>


        <?php


$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/config.php';
        if(isset($_SESSION['no'])){
            $num = $_SESSION['no'];
   $soy = "SELECT * FROM users where number = $num";
   $us = mysqli_query($conn, $soy);
   $net = mysqli_num_rows($us);
       while($result = mysqli_fetch_assoc($us)){
           $name = $result['fn'];
 }
                echo '<div  class="act">
            <img id="lonoz2" src="/Assets/Icons/user.png">
            <div class="crete"> 
            <div class="tobo">
            <a class="weec">Welcome</a>
            <a class="usna">'.$name.'</a>
            </div>
            <div class="crea">
            <a href="/Account">Profile</a>
            <a href="/Accounts/Orders">Orders</a>
            <a href="/Cart">Bag</a>
            <a href="">Contact Us</a>
            <div class="logbt">
            <button  onclick=window.location.href="/Logins/Logout?ref='.$_SERVER['REQUEST_URI'].'">Logout</button>
            </div>
            </div>
            </div>
            </div>
            ';
        }
        else{
            echo '<div  class="log">
            <a href="/Login?ref='.$_SERVER['REQUEST_URI'].'">Login</a>
            </div>';
        }
        ?>



        </div>
		<!--navbar Ends-->

        <div id="ridss" class="sliderbg"></div>
        
        <script>

$(".slide").hover(function(){
$(".left").css("left","0");
document.getElementById("ridss").style.visibility = 'visible';
    document.getElementById("ridss2").style.visibility = 'visible';
},function(){
    $(".left").css("left","-90%");
    document.getElementById("ridss").style.visibility = 'hidden';
    document.getElementById("ridss2").style.visibility = 'hidden';
});
function seaa(){
document.getElementById("sein").style.display = 'block';
}
</script>


        <script>
    var loadf = document.getElementById("load1");
function load1(){
loadf.style.display = "none";
// update();
}

function update(){
    $.get("/brand/<?php echo $post; ?>.php",{
		url: "400(*AND*)20,30,32,34"
	}, function(data){
	var result = data.split("(*AND*)");
    var price = result[0];
    var old = <?php echo $mino; ?>;
function decres(){
    if(price == old){
        clearInterval(decre);
    }
    else{
        --old;
        document.getElementById('pro-price').innerHTML = "₹"+old;
    }
}
setInterval(decres, 10);
var sizes = result[1].split(",");
var size = "";
sizes.forEach(element => {
    size += '<input onchange="changes()" type="radio" name="size" id="'+element+'" value="'+element+'"><label for="'+element+'">'+element+'</label>';
});
document.getElementById('javasizes').innerHTML = size;
	});
}
    </script>


   <!-- product list start -->

<div class="main">
<script src="/Assets/Js/JQuery.js"></script>
<script>
$(document).ready(function(){
    $(".bread a").last().css("color", "gray");
    $(".bread a").last().attr("href", "javascript:void(0)");
});
</script>
<div id="brd" class="bread">
<?php echo $br; ?>
</div>
<div style="display:<?php echo $displayall ?>"  id="main">

<!-- par start -->
<div id="par" class="part1">
<div class="proimg">

<div class="alignthis">

<div id="thomb" class="thumbo">
<img id="mathumbo" src="<?php echo $resul["image1"]; ?>">
</div>

<div id="hoimg" class="smthumbo">
<?php
$imgo1 = "";
if(!empty($resul["image1"])){
  echo '<div id="1b" class="boxy">
  <img onclick="thumbo(1)" id="1" src="'.$resul["image1"].'">
  </div>';
    $imgo1++;
}
if(!empty($resul["image2"])){
    echo '<div id="2b" class="boxy">
    <img onclick="thumbo(2)" id="2" src="'.$resul["image2"].'">
    </div>';
    $imgo1++;
}
if(!empty($resul["image3"])){
    echo '<div id="3b" class="boxy">
    <img onclick="thumbo(3)" id="3" src="'.$resul["image3"].'">
    </div>';
    $imgo1++;
}
if(!empty($resul["image4"])){
    echo '<div id="4b" class="boxy">
    <img onclick="thumbo(4)" id="4" src="'.$resul["image4"].'">
    </div>';
    $imgo1++;
}
if(!empty($resul["image5"])){
    echo '<div id="5b" class="boxy">
    <img onclick="thumbo(5)" id="5" src="'.$resul["image5"].'">
    </div>';
    $imgo1++;
}
if(!empty($resul["image6"])){
    echo '<div id="6b" class="boxy">
    <img onclick="thumbo(6)" id="6" src="'.$resul["image6"].'">
    </div>';
    $imgo1++;
}

?>

</div>

     <div class="bt"> 

                  <?php 
                  if($samecart == false)
                  { echo "
                   
                    <button id='click' name='add' class='bt1'>Add To Bag</button>";
                }
                  else{
                   echo "<button class='bt1' onclick=window.location.href='/Cart'>Go To Bag</button>";
                  }
                  ?>
                <button name="buy" id="clickbuy" class="bt2">
                 Buy
                </button>
                </div>



     <script src="/Assets/Js/zoom-image.js"></script>
     <script src="/Assets/Js/zoom-main.js"></script>

</div>


</div>

<div id="go" class="prodet">
    <div id="ptit" class="ptit">
<p><?php echo $resul["name"] ?></p>
    </div>
    <div id="pdes" class="pdes">
<p><?php echo $resul["descp"] ?></p>
    </div>
    <div class="pricing">
    <div id="pro-price" class="pro-price">₹<?php echo $mino ?></div>
<?php
 if(!empty($resul["original"])){
       
    echo '<div class="pro-dash"><strike id="pro-dash">₹'.$resul["original"].'</strike></div>
     <div class="pro-dis" id="pro-dis">'.$resul["dis"].'% off</div>';
 }
 else{
    echo '<div class="pro-dash"><strike id="pro-dash"></strike></div>
    <div class="pro-dis" id="pro-dis"></div>';
 }
?>
    </div>
    <div class="loto"><img src="/brand/<?php echo $loto ; ?>.png"></div>
  
            <?php 
            
            if(!empty($resul["sizena"])) {
                echo '  <div id="s" class="sizes">
            <section class="target">Select Size</section>
            <div class="sel-size">
            <section>
               
                <div class="javasizes" id="javasizes">';
                $sizes = explode(",",$resul["sizena"]);
                foreach($sizes as $size){
                    $sizeo = str_replace(" ", "_",$size);
                    echo '<button onclick=size("'.$sizeo.'","'.$resul["productid"].'","'.$post.'",this)>'.$size.'</button>';
                }
                echo '      </div>
                </section>
                </div>
                </div>';
            }
            ?>
      

     
<?php 
            if(!empty($resul["cona"])) {
echo '       <div class="javacolor" id="javacolor">
<p>Select Color</p>';
                $colors = explode(",",$resul["cona"]);
                foreach($colors as $key => $color){
                    if($key == "0"){
                 $co = $color;
                    }
                    $coloro = str_replace(" ", "_",$color);
                    echo '<button onclick=color("'.$coloro.'","'.$resul["productid"].'","'.$post.'",this)>'.$color.'</button>';
                }
                echo '</div>';
            }
            ?>
            

     
<?php 
            if(!empty($resul["si1na"])) {
                echo '       <div class="javastyle" id="javastyle">
                <p>Select Style</p>';
                $styles = explode(",",$resul["si1na"]);
                foreach($styles as $keys => $style){
                    if($keys == "0"){
                        $sy = $style;
                           }
                           $styleo = str_replace(" ", "_",$style);
                    echo '<button onclick=style("'.$styleo.'","'.$resul["productid"].'","'.$post.'",this>'.$style.'</button>';
                }
                echo '</div>';
            }
            ?>
            

            <script>
            function size(si,url0,we,cl){
            document.getElementById('size').value = si;
            $("#javasizes").find("button").css("border", "2px solid #c1c1c1");
            cl.style.border = "2px solid gold";
            varidb(url0,si,we,"0","Size");
            }

            function color(co,ur0,eb,li){
            document.getElementById('color').value = co;
            $("#javacolor").find("button").css("border", "2px solid #c1c1c1");
            li.style.border = "2px solid gold";
            varidb(ur0,co,eb,"0","Color");
            }

            function style(st,u0,bs,ic){
            document.getElementById('style').value = st;
            $("#javastyle").find("button").css("border", "2px solid #c1c1c1");
            ic.style.border = "2px solid gold";
            varidb(u0,st,bs,"0","Style");
            }
            </script>
                <form id="addsize" method="post">
                    <input type="hidden" id="size" name="size" value="">
                    <input type="hidden" id="color" name="color" value="<?php echo $co ?>">
                    <input type="hidden" id="style" name="style" value="<?php echo $sy ?>">
                    <input type="hidden" id="id" name="id" value="<?php echo $resul["ID"] ?>">
                    <input type="hidden" name="img" value="<?php echo $resul["image1"] ?>">
                    <input type="hidden" id="name" name="name" value="<?php echo $pona ?>">
                    <input type="hidden" id="sub" name="sub" value="<?php echo $pode ?>">
                    <input type="hidden" id="mrp" name="mrp" value="<?php echo $resul["original"] ?>">
                    <input type="hidden" id="dis" name="dis" value="<?php echo $resul["dis"] ?>% OFF">
                    <input type="hidden" id="price" name="price" value="<?php echo $mino ?>">
</form>

<script>
    function sessionstores(){
        sessionStorage.setItem('site', '<?php echo $loto ?>');
     sessionStorage.setItem('buyid', '<?php echo $resul["productid"] ?>');
     sessionStorage.setItem('img', '<?php echo $resul["image1"] ?>');
     sessionStorage.setItem('name', "<?php echo $pona ?>");
     sessionStorage.setItem('sub', "<?php echo $pode ?>");
     sessionStorage.setItem('mrp', '<?php echo $resul["original"] ?>');
     sessionStorage.setItem('price', '<?php echo $mino ?>');
     sessionStorage.setItem('dis', '<?php echo $resul["dis"] ?>');
     sessionStorage.setItem('qty', '1');
     sessionStorage.setItem('sizes',   document.getElementById('size').value);
     sessionStorage.setItem('color',   document.getElementById('color').value);
     sessionStorage.setItem('style',   document.getElementById('style').value);
     sessionStorage.setItem('ref', '<?php echo $_SERVER['REQUEST_URI'] ?>');
    }
    </script>
        
        
            <script>
            function pin(){
                    document.getElementById('pin-ec').innerHTML = "Delivery Might Be Availability";
            }
            </script>
            <div class="deliver">
<div class="deliver-title">Delivery Option</div>
<div class="deliver-des">
<input onclick="checkpin()" placeholder="Check Pincode " class="pin" maxlength="6" type="number">
<button onclick="pin()" class="pinbtn">Check</button><br>
<div  class="pin-is" id="pin-ec"></div>
<span id="box"><img src="/Assets/Icons/box.png">100% Original Product</span>
<span id="cod"><img src="/Assets/Icons/cod.png">Cash On Delivery is Excepted</span>
<span id="deli"><img src="/Assets/Icons/delivery.png">Get Free Delivery Is Available On Order Above ₹555</span>
<span id="free"><img src="/Assets/Icons/free.png">Product Well Delivered Within 7-8 Days</span>
</div>
</div>


<div class="tode">Deals</div>
<div class="deals">
<?php

if(isset($post)){
    echo '<div style="border:3px  solid gold" onclick="lo1()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post.'.png">
        </div>
        <div class="lowprice">₹'.$dano.'</div>
        </div>';
}
if(isset($post1)){
    echo '<div onclick="lo2()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post1.'.png">
        </div>
        <div class="lowprice">₹'.$dano1.'</div>
        </div>';
}
if(isset($post2)){
    echo '<div onclick="lo3()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post2.'.png">
        </div>
        <div class="lowprice">₹'.$dano2.'</div>
        </div>';
}

?>


</div>

<div class="proinfo">
<div class="protitle">Product Description</div>
<div id="prodetail" class="prodetail"><?php echo $resul["del"]; ?><?php echo $about; ?><div onclick="less()" class="readless"><button id="btnless">Read less <img src="/Assets/Icons/more.png"></div><div onclick="more()" id="readmore" class="readmor"><button id="btnmore">Read More <img id="moreimg" src="/Assets/Icons/more.png"></div></div>
</div>
</div>

<script>
function more(){
    document.getElementById('prodetail').style.height = "auto";
    document.getElementById('readmore').style.display = "none";
}
function less(){
    document.getElementById('prodetail').style.height = "88px";
    document.getElementById('readmore').style.display = "block";
}
</script>


<div class="mobibt"> 

<?php 
if($samecart == false)
{ echo "
 
  <button id='mobiclick' onclick='mobiaddcart()' name='add' class='mobibt1'>Add To Bag</button>";
}
else{
 echo "<button class='mobibt1' onclick=window.location.href='/Cart'>Go To Bag</button>";
}
?>
<button name="buy" id="mobiclickbuy" class="mobibt2">
Buy
</button>
</div>

</div>
<!-- par ends -->


<!-- par1 start -->
<div id="par1" class="part1">
<div class="proimg">

<div class="alignthis">

<div id="thomb1" class="thumbo">
<img id="mathumbo1" src="<?php echo $resul1["image1"]; ?>">
</div>

<div id="hoimg1" class="smthumbo">
<?php
$imgo11 = "10";
if(!empty($resul1["image1"])){
  echo ' <div id="11b1" class="boxy">
  <img onclick="thumbo1(11)" id="11" src="'.$resul1["image1"].'">
  </div>';
    $imgo11++;
}
if(!empty($resul1["image2"])){
    echo '<div id="12b1" class="boxy">
    <img onclick="thumbo1(12)" id="12" src="'.$resul1["image2"].'">
    </div>';
    $imgo11++;
}
if(!empty($resul1["image3"])){
    echo '<div id="13b1" class="boxy">
    <img onclick="thumbo1(13)" id="13" src="'.$resul1["image3"].'">
    </div>';
    $imgo11++;
}
if(!empty($resul1["image4"])){
    echo '<div id="14b1" class="boxy">
    <img onclick="thumbo1(14)" id="14" src="'.$resul1["image4"].'">
    </div>';
    $imgo11++;
}
if(!empty($resul1["image5"])){
    echo '<div id="15b1" class="boxy">
    <img onclick="thumbo1(15)" id="15" src="'.$resul1["image5"].'">
    </div>';
    $imgo11++;
}
if(!empty($resul1["image6"])){
    echo '<div id="16b1" class="boxy">
    <img onclick="thumbo1(16)" id="16" src="'.$resul1["image6"].'">
    </div>';
    $imgo11++;
}

?>

</div>

     <div class="bt"> 

                  <?php 
                  if($samecart1 == false)
                  { echo "
                   
                    <button id='click1' name='add' class='bt1'>Add To Bag</button>";
                }
                  else{
                   echo "<button class='bt1' onclick=window.location.href='/Cart'>Go To Bag</button>";
                  }
                  ?>
                <button name="buy" id="clickbuy1" class="bt2">
                 Buy
                </button>
                </div>



     <script src="/Assets/Js/zoom-image.js"></script>
     <script src="/Assets/Js/zoom-main.js"></script>

</div>


</div>

<div id="go1" class="prodet">
    <div id="ptit1" class="ptit">
<p><?php echo $resul1["name"] ?></p>
    </div>
    <div id="pdes1" class="pdes">
<p><?php echo $resul1["descp"] ?></p>
    </div>
    <div class="pricing">
    <div id="pro-price1" class="pro-price">₹<?php echo $min[1] ?></div>
<?php
 if(!empty($resul1["original"])){
       
    echo '<div class="pro-dash"><strike id="pro-dash1">₹'.$resul1["original"].'</strike></div>
     <div class="pro-dis" id="pro-dis1">'.$resul1["dis"].'% off</div>';
 }
 else{
    echo '<div class="pro-dash"><strike id="pro-dash1"></strike></div>
    <div class="pro-dis" id="pro-dis1"></div>';
 }
?>
    </div>
    <div class="loto"><img src="/brand/<?php echo $loto1 ; ?>.png"></div>

 
            <?php 
            if(!empty($resul1["sizena"])) {
                echo '   <div id="s1" class="sizes">
                <section class = "target">Select Size</section>
                <div class="sel-size">
                <section>
                   
                    <div class="javasizes" id="javasizes1">';
                $sizes1 = explode(",",$resul1["sizena"]);
                foreach($sizes1 as $size1){
                    $size1o = str_replace(" ", "_",$size1);
                    echo '<button onclick=size1("'.$size1o.'","'.$resul1["productid"].'","'.$post1.'",this)>'.$size1.'</button>';
                 }
                 echo '     </div>
                 </section>
                 </div>
                 </div>';
            }
            ?>
       

    
<?php 
            if(!empty($resul1["cona"])) {
                echo '        <div class="javacolor" id="javacolor1">
                <p>Select Color</p>';
                $colors1 = explode(",",$resul1["cona"]);
                foreach($colors1 as $key1 => $color1){
                    if($key1 == "0"){
                        $co1 = $color1;
                           }
                        $color1o = str_replace(" ", "_",$color1);
                    echo '<button onclick=color1("'.$color1o.'","'.$resul1["productid"].'","'.$post1.'",this)>'.$color1.'</button>';
                }
                echo ' </div>';
            }
            ?>
           

     
<?php 
            if(!empty($resul1["si1na"])) {
                echo '       <div class="javastyle" id="javastyle1">
                <p>Select Style</p>';
                $styles1 = explode(",",$resul1["si1na"]);
                foreach($styles1 as $keys1 => $style1){
                    if($keys1 == "0"){
                        $sy1 = $style1;
                           }
                           $style1o = str_replace(" ", "_",$style1);
                    echo '<button onclick=style("'.$style1o.'","'.$resul1["productid"].'","'.$post1.'",this>'.$style1.'</button>';
                }
                echo '   </div>';
            }
            ?>
         

            <script>
            function size1(si1,url1,we1,cl1){
            document.getElementById('size1').value = si1;
            $("#javasizes1").find("button").css("border", "2px solid #c1c1c1");
            cl1.style.border = "2px solid gold";
            varidb(url1,si1,we1,"1","Size");
            }

            function color1(co1,ur1,eb1,li1){
            document.getElementById('color1').value = co1;
            $("#javacolor1").find("button").css("border", "2px solid #c1c1c1");
            li1.style.border = "2px solid gold";
            varidb(ur1,co1,eb1,"1","Color");
            }

            function style1(st1,u1,ss1,ic1){
            document.getElementById('style1').value = st1;
            $("#javastyle1").find("button").css("border", "2px solid #c1c1c1");
            ic1.style.border = "2px solid gold";
            varidb(u1,st1,ss1,"1","Style");
            }
            </script>

            <form id="addsize1" method="post">
                    <input type="hidden" id="size1" name="size" value="">
                    <input type="hidden" id="color1" name="color" value="<?php echo $co1 ?>">
                    <input type="hidden" id="style1" name="style" value="<?php echo $sy1 ?>">
                    <input type="hidden" id="id1" name="id" value="<?php echo $resul1["ID"] ?>">
                    <input type="hidden" name="img1" value="<?php echo $resul1["image1"] ?>">
                    <input type="hidden" id="name1" name="name" value="<?php echo $pona1 ?>">
                    <input type="hidden" id="sub1" name="sub" value="<?php echo $pode1 ?>">
                    <input type="hidden" id="mrp1" name="mrp" value="<?php echo $resul1["original"] ?>">
                    <input type="hidden" id="dis1" name="dis" value="<?php echo $resul1["dis"] ?>% OFF">
                    <input type="hidden" id="price1" name="price" value="<?php echo $min[1] ?>">
</form>

<script>
    function sessionstores1(){
        sessionStorage.setItem('site', '<?php echo $loto1 ?>');
     sessionStorage.setItem('buyid', '<?php echo $resul1["ID"] ?>');
     sessionStorage.setItem('img', '<?php echo $resul1["image1"] ?>');
     sessionStorage.setItem('name', "<?php echo $pona1 ?>");
     sessionStorage.setItem('sub', "<?php echo $pode1 ?>");
     sessionStorage.setItem('mrp', '<?php echo $resul1["original"] ?>');
     sessionStorage.setItem('price', '<?php echo $min[1] ?>');
     sessionStorage.setItem('dis', '<?php echo $resul1["dis"] ?>');
     sessionStorage.setItem('qty', '1');
     sessionStorage.setItem('sizes', document.getElementById('size1').value);
     sessionStorage.setItem('color', document.getElementById('color1').value);
     sessionStorage.setItem('style', document.getElementById('style1').value);
     sessionStorage.setItem('ref', '<?php echo $_SERVER['REQUEST_URI'] ?>');
    }
    </script>
      
      
            <div class="deliver">
<div class="deliver-title">Delivery Option</div>
<div class="deliver-des">
<input onclick="checkpin()" placeholder="Check Pincode " class="pin" maxlength="6" type="number">
<button onclick="pin1()" class="pinbtn">Check</button><br>
<div  class="pin-is" id="pin-ec1"></div>
<span id="box"><img src="/Assets/Icons/box.png">100% Original Product</span>
<span id="cod"><img src="/Assets/Icons/cod.png">Cash On Delivery is Excepted</span>
<span id="deli"><img src="/Assets/Icons/delivery.png">Get Free Delivery Is Available On Order Above ₹555</span>
<span id="free"><img src="/Assets/Icons/free.png">Product Well Delivered Within 7-8 Days</span>
</div>
</div>
<script>
            function pin1(){
                    document.getElementById('pin-ec1').innerHTML = "Delivery Might Be Availability";
            }
            </script>

<div class="tode">Deals</div>
<div class="deals">
<?php

if(isset($post)){
    echo '<div onclick="lo11()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post.'.png">
        </div>
        <div class="lowprice">₹'.$dano.'</div>
        </div>';
}
if(isset($post1)){
    echo '<div style="border:3px  solid gold" onclick="lo21()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post1.'.png">
        </div>
        <div class="lowprice">₹'.$dano1.'</div>
        </div>';
}
if(isset($post2)){
    echo '<div onclick="lo31()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post2.'.png">
        </div>
        <div class="lowprice">₹'.$dano2.'</div>
        </div>';
}

?>


</div>

<div class="proinfo">
<div class="protitle">Product Description</div>
<div id="prodetail1" class="prodetail"><?php echo $resul1["del"]; ?><?php echo $about1; ?><div onclick="less1()" class="readless"><button id="btnless1">Read less <img src="/Assets/Icons/more.png"></div><div onclick="more1()" id="readmore1" class="readmor"><button id="btnmore1">Read More <img id="moreimg1" src="/Assets/Icons/more.png"></div></div>
</div>
</div>

<script>
function more1(){
    document.getElementById('prodetail1').style.height = "auto";
    document.getElementById('readmore1').style.display = "none";
}
function less1(){
    document.getElementById('prodetail1').style.height = "88px";
    document.getElementById('readmore1').style.display = "block";
}
</script>


<div class="mobibt"> 

<?php 
if($samecart1 == false)
{ echo "
 
  <button id='mobiclick1' onclick='mobiaddcart()' name='add' class='mobibt1'>Add To Bag</button>";
}
else{
 echo "<button class='mobibt1' onclick=window.location.href='/Cart'>Go To Bag</button>";
}
?>
<button name="buy" id="mobiclickbuy1" class="mobibt2">
Buy
</button>
</div>

</div>

<!-- part1 end -->

<!-- par2 start -->
<div id="par2" class="part1">
<div class="proimg">

<div class="alignthis">

<div id="thomb2" class="thumbo">
<img id="mathumbo2" src="<?php echo $resul2["image1"]; ?>">
</div>

<div id="hoimg2" class="smthumbo">
<?php
$imgo12 = "20";
if(!empty($resul2["image1"])){
  echo '<div id="21b2" class="boxy">
  <img onclick="thumbo2(21)" id="21" src="'.$resul2["image1"].'">
  </div>';
    $imgo12++;
}
if(!empty($resul2["image2"])){
    echo '<div id="22b2" class="boxy">
    <img onclick="thumbo2(22)" id="22" src="'.$resul2["image2"].'">
    </div>';
    $imgo12++;
}
if(!empty($resul2["image3"])){
    echo '<div id="23b2" class="boxy">
    <img onclick="thumbo2(23)" id="23" src="'.$resul2["image3"].'">
    </div>';
    $imgo12++;
}
if(!empty($resul2["image4"])){
    echo '<div id="24b2" class="boxy">
    <img onclick="thumbo2(24)" id="24" src="'.$resul2["image4"].'">
    </div>';
    $imgo12++;
}
if(!empty($resul2["image5"])){
    echo '<div id="25b2" class="boxy">
    <img onclick="thumbo2(25)" id="25" src="'.$resul2["image5"].'">
    </div>';
    $imgo12++;
}
if(!empty($resul2["image6"])){
    echo '<div id="26b2" class="boxy">
    <img onclick="thumbo2(26)" id="26" src="'.$resul2["image6"].'">
    </div>';
    $imgo12++;
}

?>

</div>

     <div class="bt"> 

                  <?php 
                  if($samecart2 == false)
                  { echo "
                   
                    <button id='click2' name='add' class='bt1'>Add To Bag</button>";
                }
                  else{
                   echo "<button class='bt1' onclick=window.location.href='/Cart'>Go To Bag</button>";
                  }
                  ?>
                <button name="buy" id="clickbuy2" class="bt2">
                 Buy
                </button>
                </div>



     <script src="/Assets/Js/zoom-image.js"></script>
     <script src="/Assets/Js/zoom-main.js"></script>

</div>


</div>

<div id="go2" class="prodet">
    <div id="ptit2" class="ptit">
<p><?php echo $resul2["name"] ?></p>
    </div>
    <div id="pdes2" class="pdes">
<p><?php echo $resul2["descp"] ?></p>
    </div>
    <div class="pricing">
    <div id="pro-price2" class="pro-price">₹<?php echo $min[2] ?></div>
    <?php
    if(!empty($resul2["original"])){
       
       echo '<div class="pro-dash"><strike id="pro-dash2">₹'.$resul2["original"].'</strike></div>
        <div class="pro-dis" id="pro-dis2">'.$resul2["dis"].'% off</div>';
    }
    else{
        echo '<div class="pro-dash"><strike id="pro-dash2"></strike></div>
        <div class="pro-dis" id="pro-dis2"></div>';
    }
    ?>
    </div>
    <div class="loto"><img src="/brand/<?php echo $loto2 ; ?>.png"></div>

            <?php 
            if(!empty($resul2["sizena"])) {
                echo '<div id="s2" class="sizes">
                <section class="target">Select Size</section>
                <div class="sel-size">
                <section>
                   
                    <div class="javasizes" id="javasizes2">';
                    
                $sizes2 = explode(",",$resul2["sizena"]);
                foreach($sizes2 as $size2){
                    $size2o = str_replace(" ", "_",$size2);
                    echo '<button onclick=size2("'.$size2o.'","'.$resul2["productid"].'","'.$post2.'",this)>'.$size2.'</button>';
                }
                
        echo '</div>
        </section>
        </div>
        </div>';
            }
            ?>



<?php 
            if(!empty($resul2["cona"])) {
                echo '            <div class="javacolor" id="javacolor2">
                <p>Select Color</p>';
                $colors2 = explode(",",$resul2["cona"]);
                foreach($colors2 as $key2 => $color2){
                    if($key2 == "0"){
                        $co2 = $color2;
                    }
                    $color2o = str_replace(" ", "_",$color2);
                    echo '<button onclick=color2("'.$color2o.'","'.$resul2["productid"].'","'.$post2.'",this)>'.$color2.'</button>';
                }
                echo ' </div>';
            }
            ?>
           


<?php 
            if(!empty($resul2["si1na"])) {
                echo '            <div class="javastyle" id="javastyle2">
                <p>Select Style</p>';
                $styles2 = explode(",",$resul2["si1na"]);
                foreach($styles2 as $keys2 => $style2){
                    if($keys2 == "0"){
                        $sy2 = $style2;
                    }
                    $style2o = str_replace(" ", "_",$style2);
                    echo '<button onclick=style2("'.$style2o.'","'.$resul2["productid"].'","'.$post2.'",this>'.$style2.'</button>';
                }
                echo ' </div>';
            }
            ?>

            <script>
            function size2(si2,url2,we2,cl2){
            document.getElementById('size2').value = si2;
            $("#javasizes2").find("button").css("border", "2px solid #c1c1c1");
            cl2.style.border = "2px solid gold";
            varidb(url2,si2,we2,"2","Size");
            }

            function color2(co2,ur2,eb2,li2){
            document.getElementById('color2').value = co2;
            $("#javacolor2").find("button").css("border", "2px solid #c1c1c1");
            li2.style.border = "2px solid gold";
            varidb(ur2,co12,eb2,"2","Color");
            }

            function style2(st2,u2,bs2,ic2){
            document.getElementById('style2').value = st2;
            $("#javastyle2").find("button").css("border", "2px solid #c1c1c1");
            ic2.style.border = "2px solid gold";
            varidb(u2,st2,bs1,"2","Style");
            }
            </script>


            <form id="addsize2" method="post">
                   <input type="hidden" id="size2" name="size" value="">
                    <input type="hidden" id="color2" name="color" value="<?php echo $co2 ?>">
                    <input type="hidden" id="style2" name="style" value="<?php echo $sy2 ?>">
                    <input type="hidden" id="id2" name="id" value="<?php echo $resul2["ID"] ?>">
                    <input type="hidden" name="img2" value="<?php echo $resul2["image1"] ?>">
                    <input type="hidden" id="name2" name="name" value="<?php echo $resul2["name"] ?>">
                    <input type="hidden" id="sub2" name="sub" value="<?php echo $resul2["descp"] ?>">
                    <input type="hidden" id="mrp2" name="mrp" value="<?php echo $resul2["original"] ?>">
                    <input type="hidden" id="dis2" name="dis" value="<?php echo $resul2["dis"] ?>% OFF">
                    <input type="hidden" id="price2" name="price" value="<?php echo $min[2] ?>">
</form>

<script>
    function sessionstores2(){
        sessionStorage.setItem('site', '<?php echo $loto2 ?>');
        sessionStorage.setItem('buyid', '<?php echo $resul2["ID"] ?>');
     sessionStorage.setItem('img', '<?php echo $resul2["image1"] ?>');
     sessionStorage.setItem('name', "<?php echo $pona2 ?>");
     sessionStorage.setItem('sub', "<?php echo $pode2 ?>");
     sessionStorage.setItem('mrp', '<?php echo $resul2["original"] ?>');
     sessionStorage.setItem('price', '<?php echo $min[2] ?>');
     sessionStorage.setItem('dis', '<?php echo $resul2["dis"] ?>');
     sessionStorage.setItem('qty', '1');
     sessionStorage.setItem('sizes',   document.getElementById('size2').value);
     sessionStorage.setItem('color',   document.getElementById('color2').value);
     sessionStorage.setItem('style',   document.getElementById('style2').value);
     sessionStorage.setItem('ref', '<?php echo $_SERVER['REQUEST_URI'] ?>');
    }
    </script>
       

            <div class="deliver">
<div class="deliver-title">Delivery Option</div>
<div class="deliver-des">
<input onclick="checkpin()" placeholder="Check Pincode " class="pin" maxlength="6" type="number">
<button onclick="pin2()" class="pinbtn">Check</button><br>
<div  class="pin-is" id="pin-ec2"></div>
<span id="box"><img src="/Assets/Icons/box.png">100% Original Product</span>
<span id="cod"><img src="/Assets/Icons/cod.png">Cash On Delivery is Excepted</span>
<span id="deli"><img src="/Assets/Icons/delivery.png">Get Free Delivery Is Available On Order Above ₹555</span>
<span id="free"><img src="/Assets/Icons/free.png">Product Well Delivered Within 7-8 Days</span>
</div>
</div>

<script>
            function pin2(){
                    document.getElementById('pin-ec2').innerHTML = "Delivery Might Be Availability";
            }
            </script>

<div class="tode">Deals</div>
<div class="deals">
<?php

if(isset($post)){
    echo '<div onclick="lo12()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post.'.png">
        </div>
        <div class="lowprice">₹'.$dano.'</div>
        </div>';
}
if(isset($post1)){
    echo '<div onclick="lo22()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post1.'.png">
        </div>
        <div class="lowprice">₹'.$dano1.'</div>
        </div>';
}
if(isset($post2)){
    echo '<div style="border:3px  solid gold" onclick="lo32()" class="lower">
        <div class="lowimg">
        <img src="/brand/'.$post2.'.png">
        </div>
        <div class="lowprice">₹'.$dano2.'</div>
        </div>';
}

?>


</div>

<div class="proinfo">
<div class="protitle">Product Description</div>
<div id="prodetail2" class="prodetail"><?php echo $resul2["del"]; ?><?php echo $about2; ?><div onclick="less2()" class="readless"><button id="btnless2">Read less <img src="/Assets/Icons/more.png"></div><div onclick="more2()" id="readmore2" class="readmor"><button id="btnmore2">Read More <img id="moreimg2" src="/Assets/Icons/more.png"></div></div>
</div>
</div>

<script>
function more2(){
    document.getElementById('prodetail2').style.height = "auto";
    document.getElementById('readmore2').style.display = "none";
}
function less(){
    document.getElementById('prodetail2').style.height = "88px";
    document.getElementById('readmore2').style.display = "block";
}
</script>


<div class="mobibt"> 

<?php 
if($samecart2 == false)
{ echo "
 
  <button id='mobiclick2' onclick='mobiaddcart()' name='add' class='mobibt1'>Add To Bag</button>";
}
else{
 echo "<button class='mobibt1' onclick=window.location.href='/Cart'>Go To Bag</button>";
}
?>
<button name="buy" id="mobiclickbuy2" class="mobibt2">
Buy
</button>
</div>

</div>

<!-- par2 end -->


<script>
		var mainthumb = "1";
		function thumbo(img){
			document.getElementById('mathumbo').src = document.getElementById(img).src;
            $('#hoimg').children('div').css({"border": "none"});
         document.getElementById(img+"b").style.border = "2px solid gold";
			mainthumb = img;
		}

var imgval = <?php echo $imgo1;?>;
    var container = document.querySelector("#thomb");
    var label = document.querySelector("#label");

    container.addEventListener("touchstart", startTouch, false);
    container.addEventListener("touchmove", moveTouch, false);

    // Swipe Up / Down / Left / Right
    var initialX = null;
    var initialY = null;

    function startTouch(e) {
      initialX = e.touches[0].clientX;
      initialY = e.touches[0].clientY;
    };

    function moveTouch(e) {
      if (initialX === null) {
        return;
      }

      if (initialY === null) {
        return;
      }

      var currentX = e.touches[0].clientX;
      var currentY = e.touches[0].clientY;

      var diffX = initialX - currentX;
      var diffY = initialY - currentY;

      if (Math.abs(diffX) > Math.abs(diffY)) {
        // sliding horizontally
	        if (diffX > 0) {
	        	if(mainthumb <= imgval){
	        			        document.getElementById('mathumbo').src = document.getElementById(++mainthumb).src;
                                $('#hoimg').children('div').css({"border": "none"});
         document.getElementById(mainthumb+"b").style.border = "2px solid gold";
         console.log(mainthumb);
	        			    }
	        } 
	        else {
	        		if(mainthumb >= imgval){
                      
	        document.getElementById('mathumbo').src = document.getElementById(--mainthumb).src;
            $('#hoimg').children('div').css({"border": "none"});
         document.getElementById(mainthumb+"b").style.border = "2px solid gold";
         console.log(mainthumb);
	        		}
	        }  
      } 
      else {
      
      }

      initialX = null;
      initialY = null;
      
      e.preventDefault();
    };



    var mainthumb2 = "21";
		function thumbo2(img2){
			document.getElementById('mathumbo2').src = document.getElementById(img2).src;
            $('#hoimg2').children('div').css({"border": "none"});
         document.getElementById(img2+"b2").style.border = "2px solid gold";
			mainthumb2 = img2;
		}

var imgval2 = <?php echo $imgo12;?>;
    var container2 = document.querySelector("#thomb2");

    container2.addEventListener("touchstart", startTouch2, false);
    container2.addEventListener("touchmove", moveTouch2, false);

    // Swipe Up / Down / Left / Right
    var initialX2 = null;
    var initialY2 = null;

    function startTouch2(e2) {
      initialX2 = e2.touches[0].clientX;
      initialY2 = e2.touches[0].clientY;
    };

    function moveTouch2(e2) {
      if (initialX2 === null) {
        return;
      }

      if (initialY2 === null) {
        return;
      }

      var currentX2 = e2.touches[0].clientX;
      var currentY2 = e2.touches[0].clientY;

      var diffX2 = initialX2 - currentX2;
      var diffY2 = initialY2 - currentY2;

      if (Math.abs(diffX2) > Math.abs(diffY2)) {
        // sliding horizontally
	        if (diffX2 > 0) {
	        	if(mainthumb2 <= imgval2){
	        			        document.getElementById('mathumbo2').src = document.getElementById(++mainthumb2).src;
                                $('#hoimg2').children('div').css({"border": "none"});
         document.getElementById(mainthumb2+"b2").style.border = "2px solid gold";
	        			    }
	        } 
	        else {
	        		if(mainthumb2 => imgval2){
	        document.getElementById('mathumbo2').src = document.getElementById(--mainthumb2).src;
            $('#hoimg2').children('div').css({"border": "none"});
         document.getElementById(mainthumb2+"b2").style.border = "2px solid gold";
	        		}
	        }  
      } 
      else {
      
      }

      initialX2 = null;
      initialY2 = null;
      
      e2.preventDefault();
    };




    var mainthumb1 = "11";
		function thumbo1(img1){
			document.getElementById('mathumbo1').src = document.getElementById(img1).src;
         $('#hoimg1').children('div').css({"border": "none"});
         document.getElementById(img1+"b1").style.border = "2px solid gold";
			mainthumb1 = img1;
		}

var imgval1 = <?php echo $imgo11;?>;
    var container1 = document.querySelector("#thomb1");

    container1.addEventListener("touchstart", startTouch1, false);
    container1.addEventListener("touchmove", moveTouch1, false);

    // Swipe Up / Down / Left / Right
    var initialX1 = null;
    var initialY1 = null;

    function startTouch1(e1) {
      initialX1 = e1.touches[0].clientX;
      initialY1 = e1.touches[0].clientY;
    };

    function moveTouch1(e1) {
      if (initialX1 === null) {
        return;
      }

      if (initialY1 === null) {
        return;
      }

      var currentX1 = e1.touches[0].clientX;
      var currentY1 = e1.touches[0].clientY;

      var diffX1 = initialX1 - currentX1;
      var diffY1 = initialY1 - currentY1;

      if (Math.abs(diffX1) > Math.abs(diffY1)) {
        // sliding horizontally
	        if (diffX1 > 0) {
	        	if(mainthumb1 <= imgval1){
	        			        document.getElementById('mathumbo1').src = document.getElementById(++mainthumb1).src;
                                $('#hoimg1').children('div').css({"border": "none"});
         document.getElementById(mainthumb1+"b1").style.border = "2px solid gold";
	        			    }
	        } 
	        else {
	        		if(mainthumb1 => imgval1){
	        document.getElementById('mathumbo1').src = document.getElementById(--mainthumb1).src;
            $('#hoimg1').children('div').css({"border": "none"});
         document.getElementById(mainthumb1+"b1").style.border = "2px solid gold";
	        		}
	        }  
      } 
      else {
      
      }

      initialX1 = null;
      initialY1 = null;
      
      e1.preventDefault();
    };


	</script>


<script>
var width = document.body.offsetWidth;
if(width < 481){

            function lo1(){
            document.getElementById("par").style.display = "block";
            document.getElementById("par1").style.display = "none";
            document.getElementById("par2").style.display = "none";
        }

        function lo2(){
            document.getElementById("par1").style.display = "block";
            document.getElementById("par").style.display = "none";
            document.getElementById("par2").style.display = "none";
        }

        function lo3(){
            document.getElementById("par2").style.display = "block";
            document.getElementById("par1").style.display = "none";
            document.getElementById("par").style.display = "none";
        }

        function lo11(){
            document.getElementById("par").style.display = "block";
            document.getElementById("par1").style.display = "none";
            document.getElementById("par2").style.display = "none";
        }

        function lo21(){
            document.getElementById("par1").style.display = "block";
            document.getElementById("par").style.display = "none";
            document.getElementById("par2").style.display = "none";
        }

        function lo31(){
            document.getElementById("par2").style.display = "block";
            document.getElementById("par1").style.display = "none";
            document.getElementById("par").style.display = "none";
        }

        function lo12(){
            document.getElementById("par").style.display = "block";
            document.getElementById("par1").style.display = "none";
            document.getElementById("par2").style.display = "none";
        }

        function lo22(){
            document.getElementById("par1").style.display = "block";
            document.getElementById("par").style.display = "none";
            document.getElementById("par2").style.display = "none";
        }

        function lo32(){
            document.getElementById("par2").style.display = "block";
            document.getElementById("par1").style.display = "none";
            document.getElementById("par").style.display = "none";
        }

}


function lo1(){
    document.getElementById("par").style.display = "flex";
    document.getElementById("par1").style.display = "none";
    document.getElementById("par2").style.display = "none";
}

function lo2(){
    document.getElementById("par1").style.display = "flex";
    document.getElementById("par").style.display = "none";
    document.getElementById("par2").style.display = "none";
}

function lo3(){
    document.getElementById("par2").style.display = "flex";
    document.getElementById("par1").style.display = "none";
    document.getElementById("par").style.display = "none";
}

function lo11(){
    document.getElementById("par").style.display = "flex";
    document.getElementById("par1").style.display = "none";
    document.getElementById("par2").style.display = "none";
}

function lo21(){
    document.getElementById("par1").style.display = "flex";
    document.getElementById("par").style.display = "none";
    document.getElementById("par2").style.display = "none";
}

function lo31(){
    document.getElementById("par2").style.display = "flex";
    document.getElementById("par1").style.display = "none";
    document.getElementById("par").style.display = "none";
}

function lo12(){
    document.getElementById("par").style.display = "flex";
    document.getElementById("par1").style.display = "none";
    document.getElementById("par2").style.display = "none";
}

function lo22(){
    document.getElementById("par1").style.display = "flex";
    document.getElementById("par").style.display = "none";
    document.getElementById("par2").style.display = "none";
}

function lo32(){
    document.getElementById("par2").style.display = "flex";
    document.getElementById("par1").style.display = "none";
    document.getElementById("par").style.display = "none";
}
    </script>


<script type = "text/javascript" src= "/Assets/Js/Shake.js"></script>	
    <script>
$(document).ready(function(){
$("#click").click(function(){
     var size = document.getElementById('size').value;
	if(!size){
        window.location.href= "#go";
        document.getElementById("s").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s").style.padding="10px 25px";
        $(".sel-size").effect( "shake", {times:2}, 300 );
	 }
     if(size){
        document.getElementById("load1").style.display = "block";

     $.ajax({
           url: "/Carts/manage.php",
           type: "POST",
           data: $('#addsize').serialize(),
           success: function(data){
            document.getElementById("load1").style.display = "none";
            document.getElementById("noti2").style.display = "block";
            document.getElementById("noti2").innerHTML = "<?php echo $count+1; ?>";
          
           },
           error: function(nodata){
            document.getElementById("load1").style.display = "none";
             
             }

       });


     }
});

$("#clickbuy").click(function(){
     var sizes = document.getElementById('size').value;
	if(!sizes){
        window.location.href= "#go";
        document.getElementById("s").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s").style.padding="10px 25px";
        $(".sel-size").effect( "shake", {times:2}, 300 );
	 }
     if(sizes){
        sessionstores();
        window.location.replace('/pv/check');
     }
});


$("#mobiclick").click(function(){
     var size = document.getElementById('size').value;
	if(!size){
        window.location.href= "#go";
        document.getElementById("s").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s").style.padding="10px 25px";
        $(".sel-size").effect( "shake", {times:2}, 300 );
	 }
     if(size){
        document.getElementById("load1").style.display = "block";

     $.ajax({
           url: "/Carts/manage.php",
           type: "POST",
           data: $('#addsize').serialize(),
           success: function(data){
            document.getElementById("load1").style.display = "none";
            document.getElementById("noti2").style.display = "block";
            document.getElementById("noti2").innerHTML = "<?php echo $count+1; ?>";
            document.getElementById("noti1").innerHTML = "<?php echo $count+1; ?>";
            document.getElementById("noti1").style.display = "block";
       },
           error: function(nodata){
            document.getElementById("load1").style.display = "none";
      
        }

       });


     }
});

$("#mobiclickbuy").click(function(){
     var sizes = document.getElementById('size').value;
	if(!sizes){
        window.location.href= "#go";
        document.getElementById("s").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s").style.padding="10px 25px";
        $(".sel-size").effect( "shake", {times:2}, 300 );
	 }
     if(sizes){
        sessionstores();
        window.location.replace('/pv/check');
     }
});



});
function changes(){
    document.getElementById("s").style.backgroundColor="white";
   }



   $(document).ready(function(){
$("#click1").click(function(){
     var size1 = document.getElementById('size1').value;
	if(!size1){
        window.location.href= "#go1";
        document.getElementById("s1").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s1").style.padding="10px 25px";
        $(".sel-size1").effect( "shake", {times:2}, 300 );
	 }
     if(size1){
        document.getElementById("load1").style.display = "block";

     $.ajax({
           url: "/Carts/manage.php",
           type: "POST",
           data: $('#addsize1').serialize(),
           success: function(data1){
            document.getElementById("load1").style.display = "none";
            document.getElementById("noti2").style.display = "block";
            document.getElementById("noti2").innerHTML = "<?php echo $count+1; ?>";
          
           },
           error: function(nodata1){
            document.getElementById("load1").style.display = "none";
             
             }

       });


     }
});

$("#clickbuy1").click(function(){
     var sizes1 = document.getElementById('size1').value;
	if(!sizes1){
        window.location.href= "#go1";
        document.getElementById("s1").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s1").style.padding="10px 25px";
        $(".sel-size1").effect( "shake", {times:2}, 300 );
	 }
     if(sizes1){
        sessionstores1();
        window.location.replace('/pv/check');
     }
});


$("#mobiclick1").click(function(){
     var size1 = document.getElementById('size1').value;
	if(!size1){
        window.location.href= "#go1";
        document.getElementById("s1").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s1").style.padding="10px 25px";
        $(".sel-size1").effect( "shake", {times:2}, 300 );
	 }
     if(size1){
        document.getElementById("load1").style.display = "block";

     $.ajax({
           url: "/Carts/manage.php",
           type: "POST",
           data: $('#addsize1').serialize(),
           success: function(data1){
            document.getElementById("load1").style.display = "none";
            document.getElementById("noti2").style.display = "block";
            document.getElementById("noti2").innerHTML = "<?php echo $count+1; ?>";
            document.getElementById("noti1").innerHTML = "<?php echo $count+1; ?>";
            document.getElementById("noti1").style.display = "block";
       },
           error: function(nodata1){
            document.getElementById("load1").style.display = "none";
      
        }

       });


     }
});

$("#mobiclickbuy1").click(function(){
     var sizes1 = document.getElementById('size1').value;
	if(!sizes1){
        window.location.href= "#go1";
        document.getElementById("s1").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s1").style.padding="10px 25px";
        $(".sel-size1").effect( "shake", {times:2}, 300 );
	 }
     if(sizes1){
        sessionstores1();
        window.location.replace('/pv/check');
     }
});



});
function changes1(){
    document.getElementById("s1").style.backgroundColor="white";
   }



   $(document).ready(function(){
$("#click2").click(function(){
     var size2 = document.getElementById('size2').value;
	if(!size2){
        window.location.href= "#go2";
        document.getElementById("s2").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s2").style.padding="10px 25px";
        $(".sel-size2").effect( "shake", {times:2}, 300 );
	 }
     if(size2){
        document.getElementById("load1").style.display = "block";

     $.ajax({
           url: "/Carts/manage.php",
           type: "POST",
           data: $('#addsize2').serialize(),
           success: function(data2){
            document.getElementById("load1").style.display = "none";
            document.getElementById("noti2").style.display = "block";
            document.getElementById("noti2").innerHTML = "<?php echo $count+1; ?>";
          
           },
           error: function(nodata2){
            document.getElementById("load1").style.display = "none";
             
             }

       });


     }
});

$("#clickbuy2").click(function(){
     var sizes2 = document.getElementById('size2').value;
	if(!sizes2){
        window.location.href= "#go2";
        document.getElementById("s2").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s2").style.padding="10px 25px";
        $(".sel-size2").effect( "shake", {times:2}, 300 );
	 }
     if(sizes2){
        sessionstores2();
        window.location.replace('/pv/check');
     }
});


$("#mobiclick2").click(function(){
     var size2 = document.getElementById('size2').value;
	if(!size2){
        window.location.href= "#go2";
        document.getElementById("s2").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s2").style.padding="10px 25px";
        $(".sel-size2").effect( "shake", {times:2}, 300 );
	 }
     if(size2){
        document.getElementById("load1").style.display = "block";

     $.ajax({
           url: "/Carts/manage.php",
           type: "POST",
           data: $('#addsize2').serialize(),
           success: function(data2){
            document.getElementById("load1").style.display = "none";
            document.getElementById("noti2").style.display = "block";
            document.getElementById("noti2").innerHTML = "<?php echo $count+1; ?>";
            document.getElementById("noti1").innerHTML = "<?php echo $count+1; ?>";
            document.getElementById("noti1").style.display = "block";
       },
           error: function(nodata2){
            document.getElementById("load1").style.display = "none";
      
        }

       });


     }
});

$("#mobiclickbuy2").click(function(){
     var sizes2 = document.getElementById('size2').value;
	if(!sizes2){
        window.location.href= "#go2";
        document.getElementById("s2").style.backgroundColor="rgba(255, 0, 0, 0.165)";
        document.getElementById("s2").style.padding="10px 25px";
        $(".sel-size2").effect( "shake", {times:2}, 300 );
	 }
     if(sizes2){
        sessionstores2();
        window.location.replace('/pv/check');
     }
});



});
function changes2(){
    document.getElementById("s2").style.backgroundColor="white";
   }

</script>





<div class="part2">
<div class="related">Similar Products</div>

<div class="rece">

<?php
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/config.php';

$quer = "SELECT * FROM data where pri LIKE '$all' OR sec LIKE '$all' OR tri LIKE '$all' OR tags LIKE '$all' Limit 0,12";
$dat = mysqli_query($conn, $quer);
$tota = mysqli_num_rows($dat);
if($tota!=0){
while($resultt = mysqli_fetch_assoc($dat)){
    $resultt = str_ireplace("^", "'", $resultt);
    $pp = $resultt['original'];
    $pr = $resultt['price'];
    $dis = ceil(($pp - $pr)/$pp*100);

            echo '
            <div onclick=window.location.href="/P/'.$all.'/'.$resultt['ID'].'" class="box">

                 <div class="img">
                   <img src="'.$resultt['image1'].'">
                 </div>
                   <div class="name">
                     '.$nam.'
                   </div>
                      <div class="descp">
                          '.$resultt['descp'].'
                      </div>
                         <div class="value">
                            <div class="price">
                            ₹'.$pr.'
                            </div>
                               <div class="mrp">
                               ₹'.$pp.'
                               </div>
                                 <div class="dis">
                                    ('.$dis .'% OFF)
                                 </div>
                         </div>
            </div>';

}
}
?>

          


</div>

</div>


<div class="mobifoot">
<div class="mofo">
<div class="foimg"><img src="/Assets/Icons/payment.png"></div>
<div class="fosub">Safe And Secure Payment. 100% Original Products.</div>
</div>
</div>


<footer>
                       <div class="foot">
                           <div class="ter">
                               <ul>
                                   <li><b>Help</b></li>
                                   <li><a href="/Help">Payments</a></li>
                                   <li><a href="/Help">Orders</a></li>
                                   <li><a href="/Help">Notifications</a></li>
                               </ul>      
                          </div>
                          
                          <div class="ter">
                               <ul>
                                   <li><b>Useful Links</b></li>
                                   <li><a href="/Legal">T&C</a></li>
                                   <li><a href="/Legal">Shipping</a></li>
                                   <li><a href="/Accounts/Orders">Order</a></li>
                                   <li><a href="/Legal">Privacy Policy</a></li>
                                   <li><a href="/Help">Help</a></li>
                                   <li><a href="/Legal">Contact Us</a></li>
                                   <li><a href="/Legal">About Us</a></li>
                               </ul>      
                          </div>  
           
                          <div class="ter">
                               <ul>
                                   <li><b>Follow Us</b></li>
                                   <li><a href="">Facebook</a></li>
                                   <li><a href="">Twitter</a></li>
                                   <li><a href="">Youtube</a></li>
                               </ul>       
                          </div>  
           
                          <div class="ter">
                               <ul>
                                   <li><b>Catageries</b></li>
                                   <li><a href="/men">Men</a></li>
                                   <li><a href="/women">Women</a></li>
                               </ul>       
                          </div> 
                          <div class="ter1">
                          <div class="goog">
                          <b>Secure Login With Google</b><br>
                          <img src="/Assets/Icons/google.png">
                          </div>
                          <div class="cood">
                          <img src="/Assets/Icons/codb.png">
                          </div>
                          </div>

                       </div>
                       <div class="copy">
                       © 2021 www.Derbun.com. All rights reserved.
                       </div>
            </footer> 

</div>


<div style="display:<?php echo $display1 ?>" class="error-sec">
        <div class="error-img">
            <img src="/Assets/Icons/error 1.png">
            <div class="error-btn">
                <button>Back</div>
            </div>
       </div>
     
</div>

<script>
// When the user scrolls down 20px from the top of the document, slide down the navbar
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("mobinav").style.top = "0";
  } else {
    document.getElementById("mobinav").style.top = "-50px";
  }
}
$("#javacolor button").first().css("border", "2px solid gold");
$("#javacolor1 button").first().css("border", "2px solid gold");
$("#javacolor2 button").first().css("border", "2px solid gold");

$("#javastyle button").first().css("border", "2px solid gold");
$("#javastyle1 button").first().css("border", "2px solid gold");
$("#javastyle2 button").first().css("border", "2px solid gold");
</script>

<script>
function varidb(idv,nav,siv,no,tpo){
    loadf.style.display = "block";
    $.get("/varidb.php",{
		id: idv,
        name : nav,
        site : siv
	}, function(data){
        loadf.style.display = "none";
       var ar = data.split("~#~");
       if(siv == "BK"){

       }
     else{
        if(no == "0"){
        document.getElementById('ptit').innerHTML = ar[0];
    document.getElementById('pdes').innerHTML = ar[1];
    document.getElementById('titl').innerHTML = ar[1];
    if(tpo!=="Color"){
        document.getElementById('pro-price').innerHTML = "₹"+ar[2];
    document.getElementById('pro-dash').innerHTML = "₹"+ar[3];
    document.getElementById('pro-dis').innerHTML = Math.round(ar[3]/ar[2]*100)+"% OFF";
    }
    document.getElementById('prodetail').innerHTML = ar[4]+'</div><div onclick="less()" class="readless"><button id="btnless">Read less <img src="/Assets/Icons/more.png"></button></div><div onclick="more()" id="readmore" class="readmor"><button id="btnmore">Read More <img id="moreimg" src="/Assets/Icons/more.png"></button></div></div>';
       }
       if(no == "1"){
        document.getElementById('ptit1').innerHTML = ar[0];
    document.getElementById('pdes1').innerHTML = ar[1];
    document.getElementById('titl').innerHTML = ar[1];
    if(tpo!=="Color"){
    document.getElementById('pro-price1').innerHTML = "₹"+ar[2];
    document.getElementById('pro-dash1').innerHTML = "₹"+ar[3];
    document.getElementById('pro-dis1').innerHTML = Math.round(ar[3]/ar[2]*100)+"% OFF";
    }
    document.getElementById('prodetail1').innerHTML = ar[4]+'</div><div onclick="less1()" class="readless"><button id="btnless1">Read less <img src="/Assets/Icons/more.png"></button></div><div onclick="more1()" id="readmore1" class="readmor"><button id="btnmore1">Read More <img id="moreimg1" src="/Assets/Icons/more.png"></button></div></div>';
        }
        if(no == "2"){
            document.getElementById('ptit2').innerHTML = ar[0];
    document.getElementById('pdes2').innerHTML = ar[1];
    document.getElementById('titl').innerHTML = ar[1];
    if(tpo!=="Color"){
    document.getElementById('pro-price2').innerHTML = "₹"+ar[2];
    document.getElementById('pro-dash2').innerHTML = "₹"+ar[3];
    document.getElementById('pro-dis2').innerHTML = Math.round(ar[3]/ar[2]*100)+"% OFF";
    }
    document.getElementById('prodetail2').innerHTML = ar[4]+'</div><div onclick="less2()" class="readless"><button id="btnless2">Read less <img src="/Assets/Icons/more.png"></button></div><div onclick="more2()" id="readmore2" class="readmor"><button id="btnmore2">Read More <img id="moreimg2" src="/Assets/Icons/more.png"></button></div></div>';
        }
     }
;
	});
}

    </script>


<script>
  $("img").click(function(){
    if($(this).attr("id")== "lonoz2"){
        document.getElementById("load1").style.display = "block";
    }
    else{
       
    }
  });

  $("a").click(function(){
    if($(this).attr("id") == "lono1as"){

}
else{
    document.getElementById("load1").style.display = "block";
}
  });


  $("#search").click(function(){
    document.getElementById("que").style.display = "block";
  });


</script>



</body>
</html>
<script type="text/javascript">
  $(document).ready(function(){
      $("#search").on("keyup", function(){
        var city = $(this).val();
        if (city !=="") {
          $.ajax({
            url:"/Searching/Query",
            type:"POST",
            cache:false,
            data:{city:city},
            success:function(data){
              $("#que").html(data);
              $("#que").fadeIn();
            }  
          });
        }else{
          $("#que").html("");  
          $("#que").fadeOut();
        }
      });

      // click one particular city name it's fill in textbox
     $("#que").on("click","li", function(){
        var tho =  $(this).text().replace(" ", "-");
        window.location.href="/"+tho;
        $('#que').fadeOut("fast");
      });
  });
</script>