<?php
include("Carts/manage.php");
$display = "none";
$display1 = "none";
$displayall = "block";
$total = 0;
$mrp = 0;
$dis = 0;
$count =  count($_SESSION['cart']);
if($count == '0'){
    $display = "block";
}

if(isset($_POST['clean'])){
    unset($_SESSION['cart']);
    echo "<script> window.location.href='/' </script>";
}
if(isset($_SESSION['cart'])){
    foreach($_SESSION['cart'] as $keys => $values){
        if(!isset($values["name"])){
            $display1 = "block";
            $displayall = "none";
         }
         if(!isset($values["sub"])){
            $display1 = "block";
            $displayall = "none";
         }
         if(!isset($values["price"])){
            $display1 = "block";
            $displayall = "none";
         }
         if(!isset($values["mrp"])){
            $display1 = "block";
            $displayall = "none";
         }
         if(!isset($values["size"])){
            $display1 = "block";
            $displayall = "none";
         }
         if(!isset($values["id"])){
            $display1 = "block";
            $displayall = "none";
         }
         if(!isset($values["qty"])){
            $display1 = "block";
            $displayall = "none";
         }
         if(!isset($values["name"])){
            $display1 = "block";
            $displayall = "none";
         }
    }
}
?>
<html>
    <head>
       
    <meta name='viewport' content='width=device-width, initial-scale=1'>


  <style>
            body{
                margin:0;
                padding:0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

  }

  img[alt="www.000webhost.com"]{
               display: none;
           } 
  @media only screen and (min-width:320px) and (max-width: 480px){

    .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 6;
            }
            .back img{
                width: 30px;
                 height: 30px;
                 margin-top: 9px;
                 margin-right: 10px;
                 margin-left: 9px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height: 50px;
            }
            .mai{
                position:absolute;
                top:50px;
                width:100%;
            }

            .bread{
                display:none
            }

            .cou{
                padding-top: 16px;
    padding-left: 32px;
    font-size: 17px;
    padding-bottom: 10px;
    background: white;
            }
            .cou span{
                color:rgb(0, 177, 59);
            }


            .loadbg1{
            width: 100%;
            height: 100%;
            background-color: white;
            position: fixed;
            z-index:5;
            top:0
        }
.loader1{
            box-shadow: 1px 1px 5px 1px rgb(169 169 169);
            display: flex;
            position: fixed;
            top:50%;
            left: 50%;
            z-index: 10;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width:45px;
            height: 45px;
            margin:5px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }
        
        .part{
            display:block;
            width:100%
        }
.part1{
    width:100%;
}

.items{
                margin-bottom:15px;
                display:flex;
                background-color: white;
                padding-bottom: 10px;
            }
            .proimg img{
                width:150px;
                height:140px;
            }

            .protit{
                font-weight: 600;
                margin-top:8px;
                font-size: 15px;
            }
            .prosubtit{
                font-weight: 400;
                margin-top:2px;
                margin-bottom:8px;
                color: rgb(119, 119, 119);
            }
            .partdesc{
                margin-left:18px
            }
            .proimg img{
                width: 140px;
                height: 130px;
                margin-left: 10px;
                margin-top: 10px;
            }
            .prising{
                display:flex;
                margin-top:-5px
            }
            .propri{
                font-size: 30px;
                font-weight: 500;
                margin-top: -3px;
            }
            .promrp{
                margin-top: 17px;
                 margin-left: 7px;
                 font-size: 12px;
            }
            .prodis{
                margin-top: 17px;
                 margin-left: 7px;
                 font-size: 12px;
                 color: red;
            }

            .qtyfil{
                display: flex;
                margin-top: 40px;
                margin-left: -160px;
                padding-bottom: 5px;
            }
           
            .qtybtn{
display:flex;
margin-top: 10px;
}
.qtybtn button{
    background-color: rgba(255, 217, 0, 0.076);
    outline: none;
    margin: 0 5px;
    width: 35px;
    height: 35px;
    font-size: 20px;
    border: 1px solid rgb(167, 167, 167);
    border-radius: 50%;

}
.qtybtn button:hover{
    background:gold

}
.qtybtn input{
    width:50px;
    height: 30px;
    text-align:center
}

            .sizecho{
                color:rgb(104, 104, 104)
            }
            .remd button{
                border: 1px solid rgb(158, 158, 158);
                outline:none;
                width:100px;
                height: 30px;
                margin-left: 30px;
                border-radius: 2px;
                margin-bottom: 10px;
                background-color: transparent;
            }
            .remd button:hover{
                background-color:gold;
            }
            .remd{
                border-left: 1px solid rgb(172, 171, 171);
                margin-left: 19px;
            }

            .part2{
    width:100%;
}

            .order{
                width: 90%;
                background: white;
                position:relative;
                padding-top:15px;
                padding-left:5%;
                padding-right:5%;
            }
            .order span{
                position: absolute;
                right: 5%;
            }
           .order button {
                display:none
            }
            .ordersave{
                padding-bottom: 10px;
            }

            .mobibot{
                position: fixed;
                bottom: 0;
                left:0;
                width: 100%;
                display:flex;
                background:white
            }
            .mopri{
                width: 50%;
                font-size: 22px;
                font-weight: 600;
                text-align: center;
                padding-top: 15px;
            }
            .mobtn{
                width: 50%;
                padding-top: 8px;
                padding-bottom: 9px;
            }
            .mobtn button{
                display: block;
               width: 90%;
               height: 42px;
               border: none;
               background: gold;
               margin-left: 5%;
               border-radius: 5px;
               font-size: 15px;
              font-weight: 600;
            }
            
            .error-sec{
                width: 100%;
    height: 100%;
    background: white;
    position: fixed;
    top: 50;
    z-index: 4;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:80%;
height:300px;
}

.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}
.mobifoot2{
    display: none
}
.mobifoot{
    width:100%;
    margin-top: 20px;
    padding-bottom: 90px;
}
.mofo{
    width: 50%;
    margin: 5px 25%;
    display: flex;
}
.foimg img{
    width:35px;
    padding-top: 1px;
}
.fosub{
    padding-left: 10px;
    font-size: 10px;
    font-weight: 500;
    color: #8c8c8c;
}







  }






    /* max size */
    @media only screen and (min-width:800px){



            .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 6;
            }
            .back img{
                width: 30px;
                height: 30px;
                margin-top: 9px;
                margin-left: 9px;
                margin-right: 11px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height: 50px;
            }
            .mai{
                position:absolute;
                top:50px;
                width:100%;
            }
            .cou{
                margin-top: 16px;
              margin-left: 53px;
            }
            .cou span{
                color:rgb(0, 177, 59);
            }
            .bread{
                font-weight: 600;
    color: #767676;
    margin-top: 20px;
    margin-left: 53px;
}
.bread img{
  width:13px;
  height:13px
}
            .part{
                width:100%;
                display: flex;
                justify-content: center;
                margin-top: 10px;
            }
            .part1{
                width:62%;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                margin-right: 10px;
                border-radius: 10px;
                padding:10px 15px;
                margin-bottom: 40px;
            }
            .items{
                margin-bottom:15px;
                display:flex;
                background-color: rgba(228, 228, 228, 0.076);
                padding-bottom: 10px;
                border-bottom: 1px solid rgba(163, 161, 161, 0.378);
            }
            .protit{
                font-weight: 600;
                margin-top:8px
            }
            .prosubtit{
                font-weight: 400;
                margin-top:2px;
                margin-bottom:8px;
                color: rgb(119, 119, 119);
            }
            .partdesc{
                margin-left:18px
            }
            .proimg img{
                width:150px;
                height:140px;
            }
            .prising{
                display:flex;
                margin-top:-5px
            }
            .propri{
                font-size: 30px;
                font-weight: 500;
                margin-top: -3px;
            }
            .promrp{
                margin-top: 9px;
                margin-left:8px
            }
            .prodis{
                margin-top: 9px;
                margin-left:3px;
                color:red
            }
           
            .qtyfil{
                display: flex;
                margin-top: 40px;
                margin-left: -160px;
                padding-bottom: 5px;
            }
            .spinbtn{
                padding:1px 15px;

            }
            .sizecho{
                color:rgb(104, 104, 104)
            }
            .remd button{
                border: 1px solid rgb(158, 158, 158);
                outline:none;
                width:100px;
                height: 30px;
                margin-left: 30px;
                border-radius: 2px;
                margin-bottom: 10px;
                background-color: transparent;
            }
            .remd button:hover{
                background-color:gold;
            }
            .remd{
                border-left: 1px solid rgb(172, 171, 171);
                margin-left: 19px;
            }
            .part2{
                width:27%;
                height:250px;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
                position: relative;
                padding: 10px 0;
            }
            .order{
                position: absolute;
                left:5%;
                width: 90%;
            }
            .order span{
                position: absolute;
                right: 0;
            }
           .order button {
                width:90%; 
                height:40px; 
                font-weight: 600; 
                font-size: 15px;
                background-color: 
                gold;border:none;
                margin: 10px 15px;
                outline: none;
                margin-top: 2px;
            }
            .mobibot{
                display:none
            }
            .qtybtn{
display:flex;
margin-top: 10px;
}
.qtybtn button{
    background-color: rgba(255, 217, 0, 0.076);
    outline: none;
    margin: 0 5px;
    width:35px;
    height:35px;
    font-size: 20px;
    border: 1px solid rgb(167, 167, 167);
    border-radius: 50%;

}
.qtybtn button:hover{
    background:gold

}
.qtybtn input{
    width:50px;
    height: 30px;
    text-align:center;
    margin-top: 2px;
}

.error-sec{
                width: 100%;
    height: 100%;
    background: white;
    position: fixed;
    top: 50;
    z-index: 4;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}

.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}

.loadbg1{
            width: 100%;
            height: 100vh;
            background-color: white;
            position: fixed;
            z-index:5;
            top:0
        }
.loader1{
            box-shadow: 1px 1px 5px 1px rgb(169 169 169);
            display: flex;
            position: fixed;
            top:50%;
            left: 50%;
            z-index: 10;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width:45px;
            height: 45px;
            margin:5px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }
.mobifoot{
    display: none
}
.mobifoot2{
    width:100%;
    padding-bottom: 10px;
}
.mofo2{
    display: flex;
    justify-content: center;
}
.foimg2 img{
    width:35px;
    padding-top: 1px;
}
.fosub2{
    padding-left: 10px;
    font-size: 10px;
    font-weight: 500;
    color: #8c8c8c;
    margin-top: 5px;
}






    }      
        </style>
    </head>
<body onload="load1()">
    <div id="load1" class="loadbg1">

        <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
        </div>

</div>

        
        <div class="head">
            <div onclick="window.history.back()" class="back">
            <img id="lonoz2" src="/Assets/Icons/arrowl.png">
        </div>
        <div class="title">
           My Cart
        </div>
        </div>
 
        <div style="display: <?php echo $displayall ?>" class="mai">
        <div class="bread">Home <img src="/Assets/Icons/arrow.png"> Cart </div>
        <div class="cou">My Cart (<span><?php echo $count ?> items</span>)</div>
        <div class="part">
            <div class="part1">
<?php 
if(isset($_SESSION['cart'])){
 foreach($_SESSION['cart'] as $key => $value){
 $total = $total + $value['qty']*$value['price'];
 $mrp = $mrp + $value['qty']*$value['mrp'];
 $dis =  $dis + $value['qty']*$value['mrp'] - $value['qty']*$value['price'];
 if(!empty($value["size"])){
 $size = '<div class="sizecho">Size : '.$value["size"].'</div>';
 }
 else{
$size = "";
 }

 if(!empty($value["color"])){
    $color = '<div class="sizecho">Color : '.$value["color"].'</div>';
    }
    else{
   $color = "";
    }

    if(!empty($value["style"])){
        $style = '<div class="sizecho">Style : '.$value["style"].'</div>';
        }
        else{
       $style = "";
        }
           echo     '<div class="items">
                    <div class="partimg">
                    <div class="proimg"><img src="'.$value["img"].'"></div>
                </div>
                <div class="partdesc">
                    <div class="protit">'.$value["name"].'</div>
                    <div class="prosubtit">'.$value["sub"].'</div>
                    <div class="prising">
                    <div class="propri">₹'.$value["price"].'</div>
                    <div class="promrp"><strike>₹'.$value["mrp"].'</strike></div>
                    <div class="prodis">('.$value["dis"].')</div>
                </div>
                '.$size.'
                '.$color.'
                '.$style.'
                <div class="qtyfil">
                <div class="qtybtn">
                <form id="subbo">
                <input type="hidden" name="subby" value='.$value['id'].'>
                </form>
                <button id="sub">-</button>
                <input id="inpt" value='.$value['qty'].' type="text">
                <form id="addo">
                <input type="hidden" name="addy" value='.$value['id'].'>
                </form>
                <button id="add">+</button>
                </div>
                    <div class="remd">
                    <form id="remo">
                    <input type="hidden" name="remove" value='.$value['id'].'>
                    </form>
                    <button id="remov">Remove</button>
                </div>
  
            </div>
            </div>
                </div>';
 }
}
else{
   echo "";
}
?>
 <script src="/Assets/Js/JQuery.js"></script>
   <script>
    $("#add").click(function(){
        document.getElementById("load1").style.display = "block";
       $.ajax({
           url: "Carts/manage.php",
           type: "POST",
           data: $('#addo').serialize(),
           success: function(data){
            document.getElementById("load1").style.display = "none";
            document.getElementById("inpt").value = ++document.getElementById("inpt").value;
            $("#part2").load("Carts/cal.php");
           }
       });
    });

    $("#sub").click(function(){
        document.getElementById("load1").style.display = "block";
       $.ajax({
           url: "Carts/manage.php",
           type: "POST",
           data: $('#subbo').serialize(),
           success: function(data){
            document.getElementById("load1").style.display = "none";
            if(document.getElementById("inpt").value > "1"){
                document.getElementById("inpt").value = --document.getElementById("inpt").value;
                $("#part2").load("Carts/cal.php");
            }
          }
       });
    });

    $("#remov").click(function(){
        document.getElementById("load1").style.display = "block";
       $.ajax({
           url: "Carts/manage.php",
           type: "POST",
           data: $('#remo').serialize(),
           success: function(data){
            document.getElementById("load1").style.display = "none";
            document.getElementById("error-sec").style.display = "block";
            }
       });
    });


   </script>         

            
            </div>
            <div id="part2" class="part2">
                <div class="order">
                <div style="margin-bottom: 20px; color: rgb(123, 123, 123); font-weight: 600;" class="ordertit">Order Details</div>
                <div style="margin:10px 0" class="ordermrp">Items MRP<span>₹<?php echo $mrp ?></span></div>
                <div style="margin:10px 0" class="orderdis">Discount<span style="color:rgb(7, 162, 59)">-&nbsp;₹<?php echo $dis ?></span></div>
                <div style="margin:10px 0" class="ordership">Delivery Charges<span style="color:rgb(7, 162, 59)">Free</span></div>
                <div style="margin:15px 0;padding-top: 6px;border-top: 1px solid #ababab;" class="ordertotal">Total Amount<span>₹<?php echo $total ?></span></div>
                <button id="lonoz2" onclick="window.location.replace('Carts/Checkout')"> Continue</button>
                <div style="text-align:center;color: rgb(7, 162, 59);font-weight: 500;" class="ordersave">You Have Saved ₹<?php echo $dis ?></div>
                
                <div class="mobibot">
                    <div class="mopri">₹<?php echo $total ?></div>
                    <div onclick="window.location.replace('Carts/Checkout')" class="mobtn"><button id="lonoz2">Continue</button></div>
                </div>

           </div>
                
           <div class="mobifoot">
<div class="mofo">
<div class="foimg"><img src="/Assets/Icons/payment.png"></div>
<div class="fosub">Safe And Secure Payment. 100% Original Products.</div>
</div>
</div>
            </div>

        </div>
        <div class="mobifoot2">
<div class="mofo2">
<div class="foimg2"><img src="/Assets/Icons/payment.png"></div>
<div class="fosub2">Safe And Secure Payment. 100% Original Products.</div>
</div>
</div>
    </div>




    <div style="display: <?php echo $display ?>" id="error-sec" class="error-sec">
                  <div class="error-img">
                      <img src="/Assets/Icons/error 2.png">
                      <div class="error-btn">
                          <button onclick="window.location.href='/'">Shop Now</div>
                      </div>
                 </div>
               
 </div>
 <div style="display: <?php echo $display1 ?>"  class="error-sec">
                  <div class="error-img">
                      <img src="/Assets/Icons/error 1.png">
                      <div class="error-btn">
                      <form method="POST">
                      <input name="clean" type="hidden" value="all">
                          <button onclick="window.history.back()">Back</div>
                          </form>
                      </div>
                 </div>
               
 </div>

 <script>

function load1(){
    document.getElementById("load1").style.display = "none";
}

    </script>

<script>
  $("#lonoz2").click(function(){
        document.getElementById("load1").style.display = "block";

  });

</script>

    </body>
</html>