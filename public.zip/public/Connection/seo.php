<?php 

if($br == "men"){
$br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a>';
}
elseif($br == "mens"){
    $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a>';
    }
    elseif($br == "tshirts"){
    $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a><img src="/Assets/Icons/arrow.png"><a href="/Tshirts">Tshirts</a>';
    }
    elseif($br == "tshirt"){
        $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a><img src="/Assets/Icons/arrow.png"><a href="/Tshirts">Tshirts</a>';
        }
        elseif($br == "men-tshirts"){
        $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a><img src="/Assets/Icons/arrow.png"><a href="/Tshirts">Tshirts</a>';
        }
        elseif($br == "men-tshirt"){
            $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a><img src="/Assets/Icons/arrow.png"><a href="/Tshirts">Tshirts</a>';
            }
            elseif($br == "men-shirts"){
        $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a><img src="/Assets/Icons/arrow.png"><a href="/Tshirts">shirts</a>';
        }
        elseif($br == "men-shirt"){
            $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/Men">Men</a><img src="/Assets/Icons/arrow.png"><a href="/Tshirts">shirts</a>';
            }
            else{
                $br = '<a href="/">Home</a><img src="/Assets/Icons/arrow.png"><a href="/Shop">Shop</a><img src="/Assets/Icons/arrow.png"><a href="/'.$br.'">'.$br.'</a>';
            }
?>