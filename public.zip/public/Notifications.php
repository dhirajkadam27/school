<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';


if(!isset($_SESSION['no'])){
    header("Location: /Login?ref=$_SERVER[PHP_SELF]");
}
$no = $_SESSION['no'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Notification</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
 <style>
body{
    padding: 0;
    margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;


}
img[alt="www.000webhost.com"]{
               display: none;
           } 
.nav{
    width: 100%;
    height: 50px;
    background: gold;
    display: flex;
}
.back img{
    width: 30px;
    margin: 9px 10px;
}
.title{
    font-size: 27px;
    margin-left: 15px;
    font-weight: 600;
    line-height: 50px
}
.main{
    width: 100%;
    position: fixed;
    top: 75px;
}
.sec1{
    width: 10%;
    height: 100%;
}
.dot{
    width: 20px;
    height: 20px;
    background: gold;
    border-radius: 50%;
    margin-left: 7px;
    margin-top: 40px;
}
.sec2{
    width:90%
}
.msg{
    width: 100%;
    border-top: 0.1px solid #dedede;
    border-bottom: 0.1px solid #a7a3a3;
    padding-bottom:10px;
    display:flex;
}
.head{
    width: 100%;
    display: flex;
    position: relative;
    margin-top: 10px;
}
.tit{
    width: 230px;
    font-size: 22px;
    font-weight: 500;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}
.dati{
    position:absolute;
    right:15px;
    font-size: 13px;
    margin-top: 6px;
}
.cont{
    width: 100%;
    height: 46px;
    display: block;
    text-overflow: ellipsis;
    overflow: hidden;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    display: -webkit-box;
}
.show{
    font-size: 25px;
    font-weight: 500;
    text-align: center;
    margin-top: 50px;
}
    </style>
</head>
<body>
    <div class="nav">
        <div id="lonoz2" onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>
        <div class="title">
           Notifications
        </div>
    </div>

    <div class="main">
        

    <?php

$query = "SELECT * FROM notify Where user='$no'";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
$seen =     "";
if($total!=0){
    while($result = mysqli_fetch_assoc($data)){
        if ($result['seen'] == "Send") {
            $seen =     "visibility:visible";
            echo  '<div id="lonoz2" onclick=window.location.href="Notification?id='.$result['id'].'" class="msg">
                <div class="sec1"><div style="'.$seen.'" class="dot"></div></div>
                <div class="sec2">
                    <div class="head"><div class="tit">'.$result['title'].'</div><div class="dati">'.$result['datetime'].'</div></div>
                    <div class="cont">'.$result['msg'].'</div>
                </div>
            </div>';
        }
        else{
            $seen =     "visibility:hidden";
            echo  '<div id="lonoz2" onclick=window.location.href="Notification?id='.$result['id'].'" class="msg">
                <div class="sec1"><div style="'.$seen.'" class="dot"></div></div>
                <div class="sec2">
                    <div class="head"><div class="tit">'.$result['title'].'</div><div class="dati">'.$result['datetime'].'</div></div>
                    <div class="cont">'.$result['msg'].'</div>
                </div>
            </div>';
        }
          
        

    }
}
else{
    echo '<div class="show">No Notifications Yet!</div>';
}

?>
    </div>

    <script>
  $("#lonoz2").click(function(){
        document.getElementById("load1").style.display = "block";
  });

</script>

</body>
</html>