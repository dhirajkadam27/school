<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
session_unset();
session_destroy();  // Destroying All Sessions
if(!isset($_SESSION['no'])){
header("Location: /");
}
?>