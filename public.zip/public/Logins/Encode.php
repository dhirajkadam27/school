<?php
if (isset($_POST['yes'])){
    $yes = $_POST['yes'];
    $yes = $yes*22;
    $yes = base64_encode($yes);
    if (isset($_POST['ref'])){
        $ref = $_POST['ref'];
    }
}

if(isset($_SESSION['no'])){
    header("Location: /");
   }

?>
<html>
<!DOCTYPE html>
<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1'>

 <style>
        body{
            margin: 0;
            padding: 0;
           font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

        }
        img[alt="www.000webhost.com"]{
               display: none;
           } 
        .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 10;
            }
            .back img{
                width:30px;
                margin:10px;
                margin-right:20px
            }
            .title{
                font-size:25px;
                font-weight:bold;
                margin-top:7px
            }
.main{
    width:100%;
    height:100%;
    background-color: white;
    position: absolute;
    top: 0;
    z-index: 5;
}
.guide{

    position: absolute;
top: 50%;
left: 50%;
z-index: 6;
transform: translate(-50%, -50%);
-webkit-transform: translate(-50%, -50%);
-moz-transform: translate(-50%, -50%);
-o-transform: translate(-50%, -50%);

}
.img{
    width: 100%;

}
.img img{
    width: 50px;
    height: 50px;
    display: block;
    margin:5px auto
}
.text{
    font-size: 20px;
    margin-bottom: 24px;
}

.error-sec{
                width: 100%;
    height: 100%;
    background: #f1f1f1;
    position: fixed;
    top: 0;
    z-index: 6;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}
.error-alerts1{
    font-size: 38px;
    font-weight: 700;
    color: red;
}
.error-alerts2{
    font-size: 38px;
    font-weight: 700;
    color: gold;
    margin-top: -54px;
    margin-left: 5px;
}
.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}

    </style>
</head>
<body onload="loa()">
    <div class="head">
        <div onclick="window.history.back()" class="back">
        <img src="/Assets/Icons/arrowl.png">
    </div>
    <div class="title">
        Derbun
    </div>
    </div>

    <div class="main">

        <div class="guide">
<div class="text">Redirecting,Don't Refresh or Go Back</div>
<div class="img"><img src="/Assets/Icons/loader.gif" alt=""></div>
        </div>
    </div>

<form id="going" action="Decode" method="POST">
<input type="hidden" value="<?php echo $yes;?>" name="yesid">
    <input type="hidden" name="ref" value="<?php if(isset($ref)){ echo $ref; } ?>">

</form>

<script>

function loa(){
    document.getElementById('going').submit();

}

</script>
</body>
</html>

