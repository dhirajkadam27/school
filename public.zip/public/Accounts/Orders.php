<?php
	ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';

 if(!isset($_SESSION['no'])){
    header("Location: /Login?ref=$_SERVER[PHP_SELF]");
}

?>

<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Order</title>
 <style>
     
body{
                margin:0;
                padding:0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

                background: #f1f1f1;
  }

  img[alt="www.000webhost.com"]{
               display: none;
           } 
  @media only screen and (min-width:320px) and (max-width: 480px){
             
  .nav{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 5;
            }
            .back img{           
    width: 30px;
    height: 30px;
    margin: 10px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height:50px
            }

            .main{
                width: 100%;
                margin-top: 60px;
                margin-left: 2.5%;
            }
            .bread{
                display: none;
}

            .sec{
                background:white;
                width:95%;
                margin:8px 0;
                border-radius:8px;
                display:flex
            }
            .img{
                width:30%;
                height: 110px;
            }
            .img img{
                width: 75%;
                 height: 85%;
                 padding: 8px 13px;
            }
            .info{
                width:30%;
                height:100%;
                margin-top:15px
            }
            .name{
                font-size: 15px;
                 font-weight: 500;
                 color: black;
            }
            .dis{
                font-size: 11px;
    font-weight: 600;
    color: #969696;
}
           .size{
            font-size: 11px;
    font-weight: 600;
    color: #969696;
           }
            .pri{
                width:15%;
                height:100%;
            }
            .price{
                margin-top: 50px;
    text-align: center;
    font-size: 19px;
    font-weight: 700;
    color: black;
            }
            .status{
                width:25%;
                height:100%;
               
            }
            .all{
                display: block;
               margin-top: 35px;
               text-align: center;
            }
            .cir{
                width: 22px;
    height: 22px;
    background: #08c508;
    border-radius: 50%;
    margin: 1px auto;
            }

            .loadbg1{
            width: 100%;
            height: 100vh;
            background-color: white;
            position: fixed;
            z-index: 4;
            top: 0;
        }
.loader1{
            box-shadow: 1px 1px 5px 1px rgb(169 169 169);
            display: flex;
            position: absolute;
            top:50%;
            left: 50%;
            z-index: 10;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width:45px;
            height: 45px;
            margin:5px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }
        .show{
    font-size: 25px;
    font-weight: 500;
    text-align: center;
    margin-top: 120px;
}




  }

 /* max size */
 @media only screen and (min-width:800px){     
             .nav{
                           width:100%;
                           height:50px;
                           background:gold;
                           display:flex;
                           position:fixed;
                           top:0;
                           z-index: 5;
                       }
                       .back img{
                           width:30px;
                           height:30px;
                           margin: 10px
                       }
                       .title{
                           font-size:25px;
                           font-weight:bold;
                           line-height:50px
                       }
           
                       .main{
                           width:80%;
                           margin:10px auto;
                           margin-top:80px
                       }
                       .bread{
             margin-left: 5px;
               margin-bottom: 15px;
               font-weight: 600;
               color: #767676;
           }
           .bread img{
             width:13px;
             height:13px
           }
                       .sec{
                           background:white;
                           width:100%;
                           height:150px;
                           margin:8px 0;
                           border-radius:8px;
                           display:flex
                       }
                       .img{
                           width:18%;
                           height:100%;
                       }
                       .img img{
                           width:80%;
                           height:80%;
                           margin:15px
                       }
                       .info{
                           width:37%;
                           height:100%;
                           margin-top:15px
                       }
                       .name{
                           font-size:24px;
                           font-weight:600;
                           color: black
                       }
                       .dis{
                           font-size: 14px;
                          font-weight: 600;
                          color: #969696;
           }
                      .size{
                           font-size: 14px;
                          font-weight: 600;
                          color: #969696;
                      }
                       .pri{
                           width:20%;
                           height:100%;
                       }
                       .price{
                           margin-top:20px;
                           text-align:center;
                           font-size: 29px;
                          font-weight: 700;
                          color: black;
                       }
                       .status{
                           width:25%;
                           height:100%;
                          
                       }
                       .all{
                           display:flex;
                           margin:5px auto;
                           width:100px;
                           margin-top:35px
                       }
                       .cir{
                           width: 22px;
                           height: 22px;
                           background: #08c508;
                           border-radius: 50%;
                           margin-right:10px
                       }
           
                       .loadbg1{
                       width: 100%;
                       height: 100vh;
                       background-color: white;
                       position: fixed;
                       z-index: 4;
                       top: 0;
                   }
           .loader1{
                       box-shadow: 1px 1px 5px 1px rgb(169 169 169);
                       display: flex;
                       position: absolute;
                       top:50%;
                       left: 50%;
                       z-index: 10;
                       border-radius: 10px;
                       background: white;
                       transform: translate(-50%, -50%);
                       -webkit-transform: translate(-50%, -50%);
                       -moz-transform: translate(-50%, -50%);
                       -o-transform: translate(-50%, -50%);
                   }
                   .loader1 img{
                       width:45px;
                       height: 45px;
                       margin:5px;
                       border-radius: 50%;
                   }
                   .loader1 p{
                       font-weight: 600;
                       padding-left:20px ;
                   }
                   .show{
    font-size: 25px;
    font-weight: 500;
    text-align: center;
    margin-top: 50px;
}



           
             }
  </style>
</head>
<body onload="load1()">
    <div id="load1" class="loadbg1">

        <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
        </div>

</div>



<div class="nav">
            <div onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>

        <div class="title">
          Orders
        </div>
        </div>

        <div class="main">
        <div class="bread">Home <img src="/Assets/Icons/arrow.png"> Account <img src="/Assets/Icons/arrow.png"> Order</div>
        <?php
         $num = $_SESSION['no'];
            $query = "SELECT * FROM orders where userID =".$num."";
            $data = mysqli_query($conn, $query);
            $total = mysqli_num_rows($data);

            if($total!=0){
                while($result = mysqli_fetch_assoc($data)){

                    $patho = $_SERVER['DOCUMENT_ROOT'];
                    include $patho.'/Connection/config.php';
                    $quer = "SELECT * FROM data where ID =".$result['productId']."";
                    $dat = mysqli_query($conn, $quer);
                    $tota = mysqli_num_rows($dat);
                    $resul = mysqli_fetch_assoc($dat);
                    $name = $resul['name'];
                    $name = str_ireplace("^", "'", $name );
                    
           echo  '<div onclick=window.location.href="Order?orderid='.$result['orderId'].'" class="sec">
                <div class="img">
                    <img src="'.$resul['image1'].'">
                </div>
                <div class="info">
                    <div class="name">'.$name.'</div>
                    <div class="dis">'.$resul['descp'].'</div>
                    <div class="size">Size: '.$result['size'].'</div>
                </div>
                <div class="pri">
                    <div class="price">
                    '.$result['Price'].'
                    </div>
                </div>
                <div class="status">
                    <div class="all">
                    <div class="cir">

                    </div>
                    '.$result['track'].'
                    </div>
                </div>
            </div>';
                }
            }
            else{
                echo '<div class="show">No Orders Yet!</div>';
            }
?>

        </div>

        <script>

function load1(){
    document.getElementById("load1").style.display = "none";
}

    </script>
</body>
</html>