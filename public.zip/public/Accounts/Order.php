<?php
	ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}

if(!isset($_SESSION['no'])){
  header("Location: /Login?ref=$_SERVER[PHP_SELF]");
}

  date_default_timezone_set("Asia/Kolkata");
  $patho = $_SERVER['DOCUMENT_ROOT'];
  include $patho.'/Connection/connect.php';
 $display = "none";
 $orderid = $_GET['orderid'];
 $num = $_SESSION['no'];
 $order = "0";
 $placed = "100px";
 $shipped = "200px";
 $delivery = "300px";
 $width = "0";


  

?>

<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Order</title>
 <style>
body{
                margin:0;
                padding:0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

                background: #f1f1f1;
  }
  img[alt="www.000webhost.com"]{
               display: none;
           } 
  @media only screen and (min-width:320px) and (max-width: 480px){
  .nav{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 5;
            }
            .back img{
              width: 30px;
    height: 30px;
    margin: 10px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height:50px
            }
.main{
    width: 95%;
    margin: 61px auto;
}
.bread{
 display:none
}
.bread img{
  width:13px;
  height:13px
}
.part{
  width: 100%;
    background: white;
    margin-bottom: 10px;
    display:block;
}
.adds{
  padding-top: 20px;
    margin-left: 25px;
    margin-bottom: 13px;
    font-weight:600;
    font-size: 17px;
    color: black;
}
.adds div{
  border-bottom:2px solid #ffc500;
  width:50%;
  padding-bottom:4px
}
.addinfo{
  margin-top: 7px;
  margin-left: 25px;
  padding-bottom:20px
}
.adna{
  margin-bottom: 10px;
  font-weight:600;
  color: #282828;
}
.adad{
  width:40%;
}
.phone{
  margin-top: 15px;
}
.pho{
  font-weight:600;
  color: #282828;

}
  .part1{
    width: 100%;
    border-bottom: 1px solid #c6c6c6;
    display:block;
    background: white;
  }
  .ordeid{
    margin-left: 15px;
    padding-top: 15px;
  }
.sub{
  display: flex
}
  .img{
    width: 45%;
    height: 150px;
    overflow: hidden;
  }
  .img img{
    width: 80%;
    height: 80%;
    margin: 10%;
  }
  .pro{
    width:75%;
    display:block
  }
.info{
  margin-top: 15px;
    width: 100%;
    display: block;
    font-size: 15px;
}
.info1{
  width:100%;
  display:block
}
.info2{
  width: 100%;
    display: block;
}
.name{
  font-size: 15px;
    font-weight: 500;
}
.price{
  margin-top: 9px;
  font-size: 25px;
    font-weight: 600;
}
.qty{
  margin-top: 9px;
}
.size{
  margin-top: 5px;
}
.part2{
    width: 100%;
    height:400px;
    background: white;
  }
  .lines{
    width: 5px;
    height: 300px;
    background: #b3b3b3;
    margin-top: -7px;
  }
  .line{
    width: 5px;
    height: 0;
    background: gold;
    transition: height 1s;
    margin-top: -7px;
    margin-left: -5px;
  }
  .Ordered{
    height: 0;
  }
  .Placed{
    height: 99px;
  }
  .Shipped{
    height: 199px;
  }
  .Delivered{
    height: 299px;
  }
  .date{
    height: 19px
  }
   .all{
        margin-left:  40px;
        display: flex;
        padding-top: 45px;
  }
  .cr{
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 6px solid #b3b3b3;
    background: #ffffff;
  }
  .circle{
    height: 300px;
    display: block;
    width: 25px;
    margin-left: -13px;
    margin-top: -16px;
  }
  #cr2, #cr3, #cr4{
    margin: 77px 0;
  }
  .cir{
    margin-top: -16px;
    margin-left: 15px;
  }
  #c2{
    margin: 50px 0;
  }
  #c3{
    margin: 50px 0;
  }
  #c4{
    margin: 50px 0;
  }
  .type{
    font-size: 20px;
    font-weight: 500;
  }

    .error-sec{
                width: 100%;
    height: 100%;
    background: white;
    position: fixed;
    top: 50;
    z-index: 4;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}
.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}

.loader1{
            box-shadow: 1px 1px 5px 1px rgb(169 169 169);
            display: flex;
            position: absolute;
            top:50%;
            left: 50%;
            z-index: 10;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width:45px;
            height: 45px;
            margin:5px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }
  }


  /* max size */
  @media only screen and (min-width:800px){     
      

  .nav{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 5;
            }
            .back img{
              width: 30px;
    height: 30px;
    margin: 10px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height:50px
            }
.main{
    width: 89%;
    margin-top: 80px;
    margin: 80px auto;
}
.bread{
  margin-left: 5px;
    margin-bottom: 15px;
    font-weight: 600;
    color: #767676;
}
.bread img{
  width:13px;
  height:13px
}
.part{
  width: 100%;
    background: white;
    margin-bottom: 10px;
    display:block;
}
.adds{
  padding-top: 20px;
    margin-left: 25px;
    margin-bottom: 13px;
    font-weight:600;
    font-size: 17px;
    color: black;
}
.adds div{
  border-bottom:2px solid #ffc500;
  width:25%;
  padding-bottom:4px
}
.addinfo{
  margin-top: 7px;
  margin-left: 25px;
  padding-bottom:20px
}
.adna{
  margin-bottom: 10px;
  font-weight:600;
  color: #282828;
}
.adad{
  width:40%;
}
.phone{
  margin-top: 15px;
}
.pho{
  font-weight:600;
  color: #282828;

}
  .part1{
    width: 100%;
    border-bottom: 1px solid #c6c6c6;
    display:block;
    background: white;
  }
.sub{
  display: flex
}
  .img{
    width:20%;
    height: 130px;
    overflow:hidden;
    margin-bottom:10px
  }
  .img img{
    width:60%;
    height:130px;
    margin:8px;
    margin-left:35px
  }
  .pro{
    width:80%;
    display:block
  }
  .date{
    height: 20px
  }
.info{
  margin-top:5px;
  width:100%;
  display:block
}
.ordeid{
  margin-left: 39px;
    padding-top: 15px;
    font-size: 20px;
    margin-bottom: 5px;
}
.name{
  margin-top:10px;
  font-size: 20px;
}
.price{
  margin-top: 10px;
  font-size: 20px;
  font-weight: 600
}
.qty{
  margin-top:10px
}
.size{
  margin-top:10px
}

  .part2{
    width: 100%;
    height:400px;
    background: white;
  }
  .lines{
    width: 5px;
    height: 300px;
    background: #b3b3b3;
    margin-top: -7px;
  }
  .line{
    width: 5px;
    height: 0;
    background: gold;
    transition: height 1s;
    margin-top: -7px;
    margin-left: -5px;
  }
  .Ordered{
    height: 0;
  }
  .Placed{
    height: 99px;
  }
  .Shipped{
    height: 199px;
  }
  .Delivered{
    height: 299px;
  }
   .all{
        margin-left:  100px;
        display: flex;
        padding-top: 45px;
  }
  .cr{
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 6px solid #b3b3b3;
    background: #ffffff;
  }
  .circle{
    height: 300px;
    display: block;
    width: 25px;
    margin-left: -13px;
    margin-top: -16px;
  }
  #cr2, #cr3, #cr4{
    margin: 77px 0;
  }
  .cir{
    margin-top: -16px;
    margin-left: 15px;
  }
  #c2{
    margin: 50px 0;
  }
  #c3{
    margin: 50px 0;
  }
  #c4{
    margin: 50px 0;
  }
  .type{
    font-size: 20px;
    font-weight: 500;
  }
    .error-sec{
                width: 100%;
    height: 100%;
    background: white;
    position: fixed;
    top: 50;
    z-index: 4;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}
.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}

.loader1{
            box-shadow: 1px 1px 5px 1px rgb(169 169 169);
            display: flex;
            position: absolute;
            top:50%;
            left: 50%;
            z-index: 10;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width:45px;
            height: 45px;
            margin:5px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }
  }



  </style>
</head>
<body onload="load1()">

    <div id="load1" class="loadbg1">

        <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
        </div>

</div>


<div class="nav">

            <div onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>

        <div class="title">
            Order
        </div>
        </div>
<div class="main">
  <div class="bread">Home <img src="/Assets/Icons/arrow.png"> Account <img src="/Assets/Icons/arrow.png"> Order <img src="/Assets/Icons/arrow.png"> <?php echo  $orderid ?></div>

  <div id="all" class="part">
    <div class="adds"><div>Delivery Address</div></div>
          <div class="addinfo">
          <?php
         
         $quer = "SELECT * FROM address where no =".$num."";
         $dat = mysqli_query($conn, $quer);
         $tota = mysqli_num_rows($dat);
         $resul = mysqli_fetch_assoc($dat);
         if($tota = "0"){
          $display = "block";
        }
        if(empty($resul['name'])){
          $display = "block";
        }
        if(empty($resul['address'])){
          $display = "block";
        }
        if(empty($resul['no'])){
          $display = "block";
        }
             echo '<div class="adna">'.$resul['name'].'</div>
                 <div class="adad">'.$resul['address'].'</div>
                    <div class="phone">
                       <div class="pho">Mobile No.</div>
                       <div class="no">'.$resul['no'].', '.$resul['no2'].'</div>
                    </div>';
                    ?>

          </div>
  </div>
          <div class="part1">
          <div class="ordeid">Order ID: <?php echo $orderid; ?></div>
          <div class="sub">
          <div id="img" class="img">

          </div>
          <div class="pro">
          <?php
          
          $patho = $_SERVER['DOCUMENT_ROOT'];
          include $patho.'/Connection/connect.php';

$query = 'SELECT * FROM orders where orderId="'.$orderid.'"';
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);
     $id = $result['productId'];
        $name = $result['product'];
        $name = str_ireplace("^", "'", $name );
        $track = $result['track'];

        if($totat = "0"){
          $display = "block";
        }
        if(empty($result['orderId'])){
          $display = "block";
        }
        if(empty($result['product'])){
          $display = "block";
        }
        if(empty($result['Price'])){
          $display = "block";
        }
        if(empty($result['qty'])){
          $display = "block";
        }
         if(empty($result['size'])){
          $display = "block";
        }
        if(empty($result['track'])){
          $display = "block";
        }
                 echo '
              <div class="info">       
                   <div class="info1">
                                <div class="name">
                                '. $name.'
                                </div>
                           <div class="price">
                           ₹'.$result['Price'].'
                           </div>
                    </div>
                      <div class="info2">
                                      <div class="qty">
                                       QTY : '.$result['qty'].'
                                      </div>
                                 <div class="size">
                                 Size :  '.$result['size'].'
                                 </div>
                                 <div id="echo"></div>
                      </div>
              </div>';

              if($track == "Ordered"){
                $width =  $order;
              }
              if($track == "Placed"){
                $width =  $placed;
              }
              if($track == "Shipped"){
                $width =  $shipped;
              }
              if($track == "Delivered"){
                $width =  $delivery;
              }
                
?>
          </div>
          </div>
          
          </div>
      <div class="part2">
           <div class="all">
           <div class="lines"></div>
           <div  id="height" class="line"></div>   
                    <div class="circle">
                            <div id="cr1" class="cr"></div>
                            <div id="cr2" class="cr"></div>
                            <div id="cr3" class="cr"></div>
                            <div id="cr4" class="cr"></div>
                    </div>
                            
                    <div class="cir">
                                <div id="c1" class="c"><div class="type">Ordered</div><div class="date"><?php if(isset($result["date1"])){ echo $result["date1"] ; } ?></div></div>
                                <div id="c2" class="c"><div class="type">Placed</div><div class="date"><?php if(isset($result["date2"])){ echo $result["date2"] ; } ?></div></div>
                                <div id="c3" class="c"><div class="type">Shipped</div><div class="date"><?php if(isset($result["date3"])){ echo $result["date3"] ; } ?></div></div>
                                <div id="c4" class="c"><div class="type">Delivered</div><div class="date"><?php if(isset($result["date4"])){ echo $result["date4"] ;} ?></div></div>
                           </div>

                         
                         <div  id="Ordered" class="Ordered"></div>
                         <div  id="Placed" class="Placed"></div>
                         <div  id="Shipped" class="Shipped"></div>
                         <div  id="Delivered" class="Delivered"></div>
                    
           </div>
      </div> 
</div>
<script src="/Assets/Js/JQuery.js"></script>
	<script> 
		elem = $("#height")[0]; 

		let resizeObserver = new ResizeObserver(() => { 
      txt = $("#height").height();
      Ordered = $("#Ordered").height();
      Placed = $("#Placed").height();
      Shipped = $("#Shipped").height();
      Delivered = $("#Delivered").height();
      if(txt ==  Ordered){
        document.getElementById("cr1").style.border = "6px solid gold";
        document.getElementById("cr1").style.background = "gold";
        document.getElementById("c1").style.color = "red";
      }
       if(txt > Placed){
        document.getElementById("cr2").style.border = "6px solid gold";
        document.getElementById("cr2").style.background = "gold";
        document.getElementById("c2").style.color = "red";
      }
      if(txt > Shipped){
        document.getElementById("cr3").style.border = "6px solid gold";
        document.getElementById("cr3").style.background = "gold";
        document.getElementById("c3").style.color = "red";
      }
     if(txt >  Delivered){
      document.getElementById("cr4").style.border = "6px solid gold";
        document.getElementById("cr4").style.background = "gold";
        document.getElementById("c4").style.color = "red";
      }
      
			console.log(txt); 
		}); 



    resizeObserver.observe(elem); 
		
</script> 


<?php
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/config.php';
$query = 'SELECT * FROM data where id="'.$id.'"';
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
$resultt = mysqli_fetch_assoc($data);

?>
<script>
function load1(){
    document.getElementById("height").style.height = "<?php echo $width ?>";
    document.getElementById("load1").style.display = "none"; 
}

document.getElementById("img").innerHTML= '<img src="<?php echo $resultt["image1"] ?>">';
</script>

<div style="display: <?php echo $display ?>" class="error-sec">
                  <div class="error-img">
                      <img src="/Assets/Icons/error 1.png">
                      <div class="error-btn">
                          <button>Back</button>
                      </div>
                 </div>
</body>
</html>
