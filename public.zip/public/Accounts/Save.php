<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
   $no = $_SESSION['no'];
   $nam = $_POST['fname'];
   $la = $_POST['lname'];
   $no1 = $_POST['email'];
   $land = $_POST['gender'];
   

    $sql = "UPDATE `users` SET `number`='$no',`fn`='$nam',`ln`='$la',`email`='$no1',`gender`='$land' WHERE number='$no'";
   
   if(mysqli_query($conn, $sql)){
       header("Location: /Account");
   }
   else{
    header("Location: /Accounts/Edit");
   }
?>
