<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
   $no = $_SESSION['no'];
   $nam = $_POST['name'];
   $pin = $_POST['pin'];
   $city = $_POST['city'];
   $adds = $_POST['address'];
   $locat = $_POST['location'];
   $state = $_POST['state'];
   $land = $_POST['landmark'];
   $no2 = $_POST['no2'];

   $sql = "INSERT INTO `address`(`no`, `name`, `pincode`, `city`, `address`, `location`, `state`, `landmark`, `no2`) VALUES ('$no', '$nam', '$pin', '$city', '$adds', '$locat', '$state', '$land', '$no2')";
   if(mysqli_query($conn, $sql)){
       header("Location: /Accounts/Address");
   }
   else{
    header("Location: /Accounts/Addresses/Edit");
   }
?>
