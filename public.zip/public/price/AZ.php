<?php
$url = "https://www.amazon.in/Allen-Solly-Mens-8907587727592_AMKP317G04248_Large_Sea-Green/dp/B06Y2FQT1M";

$ch = curl_init();
$useragent="Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1";
curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$res = curl_exec($ch);

curl_close($ch);

$dom = new DomDocument();
@ $dom->loadHTML($res);
$price = $dom->getElementById('priceblock_ourprice')->textContent;
$xpath = new DOMXpath($dom);
$sizes = $xpath->query("//*[contains(@class, 'dropdownAvailable')]");

$i = "0";
$size = array();
foreach ($sizes as $key) {
    $size[] = $sizes->item($i)->textContent;
    $i++;
}
$siall = implode(",",$size);
echo $price."(*AND*)".$siall;
?>