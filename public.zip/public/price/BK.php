<?php
$url = "https://www.bewakoof.com/p/anandham-half-sleeve-t-shirt";

$ch = curl_init();
$useragent="Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1";
curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$res = curl_exec($ch);

curl_close($ch);

$dom = new DomDocument();
@ $dom->loadHTML($res);

$price = $dom->getElementById('testNetProdPrice')->textContent;
$xpath = new DOMXpath($dom);
$sizes = $xpath->query("//*[contains(@class, 'eachSize   ')]");
$remove = $xpath->query("//*[contains(@class, 'eachSize   disableSize')]");
$i = "0";
$l = "0";
$size = array();
$remo = array();
foreach ($sizes as $key) {
    $size[] = $sizes->item($i)->textContent;
    $i++;
}
foreach ($remove as $remos) {
  $remo[] = $remove->item($l)->textContent;
  $l++;
}

$allsizes = array_diff($size,$remo);
$siall = implode(",",$allsizes);
echo $price."(*AND*)".$siall;
?>