<?php
$url = "https://www.flipkart.com/scatchite-printed-men-round-neck-blue-t-shirt/p/itm53e78b2519d37";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$res = curl_exec($ch);

curl_close($ch);

$dom = new DomDocument();
@ $dom->loadHTML($res);
$xpath = new DOMXpath($dom);
$price = $xpath->query("//*[contains(@class, '_30jeq3')]");

$sizes = $xpath->query("//*[contains(@class, '_1fGeJ5 _2UVyXR _31hAvz')]");

$i = "0";
$size =array();
foreach ($sizes as $key) {
    $size[] = $sizes->item($i)->textContent;
    $i++;
}
foreach ($price as $seall) {
    $mrp = $price->item(0)->textContent;
}
$siall = implode(",",$size);
echo $mrp."(*AND*)".$siall;
?>