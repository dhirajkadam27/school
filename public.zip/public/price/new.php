<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $name = "aa";

 $sites = array();
$brands = array();
$titles = array();
$prices = array();
$discounts = array();
$mrps = array();

$conn = new mysqli($servername, $username, $password, $name);

if($conn->connect_error){
	echo"Unable To Connect The server";
}
else{
	echo "";
}


$query = "SELECT * FROM nt";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
    while($result = mysqli_fetch_assoc($data)){

    if(!empty($result['fk'])){
    $sites['FK'] = $result['fk'];
    }
    if(!empty($result['am'])){
    $sites['AM'] = $result['am'];
    }
    if(!empty($result['bk'])){
    $sites['BK'] = $result['bk'];
    }

    foreach($sites as $site){
        $type = array_search($site, $sites);

        if($type == "FK"){
            $con = curl_init($site);
            curl_setopt($con, CURLOPT_RETURNTRANSFER, 1);
            $RUN = curl_exec($con);
            $AZ = preg_replace('/\s\s+/', ' ', $RUN);
        preg_match('#"price":(.*?),#is', $AZ, $thirds);

        echo "<br>";
        echo $thirds[1];
        echo "<br>";

        }

        if($type == "AM"){
            $con = curl_init($site);
            curl_setopt($con, CURLOPT_RETURNTRANSFER, 1);
            $RUN = curl_exec($con);
            $AZ = preg_replace('/\s\s+/', ' ', $RUN);
        preg_match('#<span class="price"[^>]*>(.*?)</span[^>]*>#is', $AZ, $thirds);
        echo "<br>";
echo $thirds[1];
echo "<br>";
        }

        if($type == "BK"){
            $con = curl_init($site);
            $useragent="Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1";
             curl_setopt($con, CURLOPT_USERAGENT, $useragent);
            curl_setopt($con, CURLOPT_RETURNTRANSFER, 1);
            $RUN = curl_exec($con);
            $AZ = preg_replace('/\s\s+/', ' ', $RUN);
preg_match('#"price":\s(.*?),#is', $AZ, $thirds);

echo "<br>";
echo $thirds[1];
echo "<br>";

        }

        curl_close($con);
    }

    }
    

?>