<?php
include("manage.php");

$total = 0;
$mrp = 0;
$dis = 0;

if(isset($_SESSION['cart'])){
    foreach($_SESSION['cart'] as $key => $value){
    $total = $total + $value['qty']*$value['price'];
    $mrp = $mrp + $value['qty']*$value['mrp'];
    $dis =  $dis + $value['qty']*$value['mrp'] - $value['qty']*$value['price'];

    }

}

?>
<div class="order">
                <div style="margin-bottom: 20px; color: rgb(123, 123, 123); font-weight: 600;" class="ordertit">Order Details</div>
                <div style="margin:10px 0" class="ordermrp">Items MRP<span>₹<?php echo $mrp ?></span></div>
                <div style="margin:10px 0" class="orderdis">Discount<span style="color:rgb(7, 162, 59)">-&nbsp;₹<?php echo $dis ?></span></div>
                <div style="margin:10px 0" class="ordership">Delivery Charges<span style="color:rgb(7, 162, 59)">Free</span></div>
                <div style="margin:15px 0;padding-top: 6px;border-top: 1px solid #ababab;" class="ordertotal">Total Amount<span>₹<?php echo $total ?></span></div>
                <button onclick="window.location.replace('Carts/Checkout')"> Continue</button>
                <div style="text-align:center;color: rgb(7, 162, 59);font-weight: 500;" class="ordersave">You Have Saved ₹<?php echo $dis ?></div>
                
                <div class="mobibot">
                    <div class="mopri">₹<?php echo $total ?></div>
                    <div onclick="window.location.replace('Carts/Checkout')" class="mobtn"><button>Continue</button></div>
                </div>

