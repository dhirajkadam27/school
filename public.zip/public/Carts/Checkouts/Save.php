<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
   $no = $_SESSION['no'];
   $nam = $_POST['name'];
   $pin = $_POST['pin'];
   $city = $_POST['city'];
   $adds = $_POST['address'];
   $locat = $_POST['location'];
   $state = $_POST['state'];
   $land = $_POST['landmark'];
   $no2 = $_POST['no2'];

   $sql = "INSERT INTO `address`(`no`, `name`, `pincode`, `city`, `address`, `location`, `state`, `landmark`, `no2`) VALUES ('$no', '$nam', '$pin', '$city', '$adds', '$locat', '$state', '$land', '$no2')";
   if(mysqli_query($conn, $sql)){
   }
   else{
       echo "not";
   }

   $state = "SELECT * FROM users WHERE number = $no";
   $data = mysqli_query($conn, $state);
   $total = mysqli_num_rows($data);
   $result = mysqli_fetch_assoc($data); 
   if (isset($result["number"])) {
     if (empty($result["fn"])) {
   
   
      $nam = preg_replace('/\s+/', ' ', $nam);
      $words =  str_word_count($nam);
      $nam = explode(' ',trim($nam));
      
      if($words == 3){
      $fn = $nam[0];
      $ln = $nam[2];
      }
      if($words == 2){
        $fn = $nam[0];
        $ln = $nam[1];
        }
        if($words == 1){
          $fn = $nam[0];
          $ln = " ";
          }
   
      $query = "UPDATE `users` SET `fn`='$fn',`ln`='$ln' WHERE number = $no";
      if(mysqli_query($conn, $query)){
     }
     else{
         echo "not";
     }
   
   }
   }
?>