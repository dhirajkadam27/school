<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
$img = "loader.gif";
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
$num = $_SESSION['no'];
$soy = "SELECT * FROM users where number = $num";
$us = mysqli_query($conn, $soy);
$net = mysqli_num_rows($us);
$resultno = mysqli_fetch_assoc($us);
if($net!=0){
        $name = $resultno['fn'];
}
$subdis = 0;
$sr = 0;
$ze = 0;
$set = 0;


$msg = "";
$msg2 = "";
$img = "";


 foreach($_SESSION['cart'] as $key => $value){

    date_default_timezone_set("Asia/Kolkata");
$date1 = date("d/m/Y h:iA");
$date2 = "";
$date3 = "";
$date4 = "";


    $sr = $sr + 1;
    $num = $_SESSION['no'];
   $proid = $value['id'];
   $pro = $value['sub'];
   $price =   $value['price'];
   $mrp =  $value['mrp'];
   $qty=  $value['qty'];
   $size =  $value['size'];
   $track=  "Ordered";
   $pro = str_ireplace("'", "^", $pro);

   $nu = substr($num ,8,10);
   $f = substr($name ,0,2);
   $f= strtoupper($f);
   $or =  date("jmYhis");

   $orderid = $f.$or.$nu.$ze.$sr ;


   $subdis = $subdis + $value['qty']*$value['mrp'] - $value['qty']*$value['price'];

   $sql = "INSERT INTO `orders`(`orderId`, `userId`, `productId`, `product`, `mrp`, `Price`, `qty`, `size`, `track`, `date1`, `date2`, `date3`, `date4`) VALUES ('$orderid','$num','$proid','$pro','$mrp','$price','$qty','$size','$track', '$date1', '$date2', '$date3','$date4')";
   if(mysqli_query($conn, $sql)){
    $set++;
   }

 }
    $ss = count($_SESSION['cart']);
    if($ss ==  $set){
        unset($_SESSION['cart']);
        $msg = "Done";
        $msg2 = "Your Order Has Been Placed Successfully.";
        $img = "done.png";
    }
    else{
        $msg = "Failed";
        $msg2 = "Could Not Placed The Order.";
        $img = "failed.jpg";
    }



?>
<!DOCTYPE html>
<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1'>

    <title>Order Placed</title>
    
  <style>
             body{
                margin:0;
                padding:0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

  }

  img[alt="www.000webhost.com"]{
               display: none;
           } 
  @media only screen and (min-width:320px) and (max-width: 480px){
  .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 2;
                display:flex;
            }
            .back img{
                width: 30px;
               height: 30px;
               margin-left: 15px;
               margin-top: 8px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height:50px;
                margin-left:19px
            }

            .main{
                text-align: center;
                margin-top: 50px;
                
            }
           .info{
            margin: 5px auto;
            margin-top: -345px;
           }
           .info img{
               width:150px;
               height: 150px;
               transition: all 0.5s;
           }
           .info p{
               font-size: 49px;
               font-weight: 700;
               margin:0;
           }
           .info h5{
           color: #848484;
           margin: 0;
           }
           
           .info button{
               padding:8px 39px ;
               background-color: gold;
               border: none;
               font-size: 25px;
               border-radius: 5px;
               margin-top: 15px;
           }
#imgg{
    width: 100%;
    height: 50vh;
    margin-top: 110px;
}

  }



  /* max size */
  @media only screen and (min-width:800px){

  .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 2;
                display:flex;
            }
            .back img{
                width: 30px;
              margin: 10px;
              margin-right: 25px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height:50px
            }
            .main{
                text-align: center;
                margin-top: 50px;
                position: relative;
            }
           .info{
               position: absolute;
               top:30%;
               left:40%
           }
           .info img{
               width:150px;
               height: 150px;
               transition: all 0.5s;
           }
           .info p{
               font-size: 49px;
               font-weight: 700;
               margin:0;
           }
           .info h5{
           color: #848484;
           margin: 0;
           }
           
           .info button{
               padding:8px 39px ;
               background-color: gold;
               border: none;
               font-size: 25px;
               border-radius: 5px;
               margin-top: 15px;
           }


  }
    </style>
</head>
<body onload="loa()">
<script>
        function loa(){
            document.getElementById("im").style.transform = "rotate(1080deg)";
        }
    </script>

<div class="head">
        <div onclick="window.history.back()" class="back">
        <img src="/Assets/Icons/arrowl.png">
    </div>

    <div class="title">
        Order Placed
    </div>
    </div>


    <div class="main">
        <div class="gif">
            <img id="imgg" src="/Assets/Icons/done.gif">
            <div class="info">
                <img id="im"  src="/Assets/Icons/<?php echo $img ;?>" alt="">
            <p><?php echo $msg ;?></p>
            <h5 style="margin-top: 15px;"><?php echo $msg2 ;?></h5>
            <h5 style="color:#FF8E04;margin-top: 5px;">You Have Saved ₹<?php echo  $subdis ;?></h5>
            </div>
        </div>
    </div>


</body>
</html>