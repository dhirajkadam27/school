<?php
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
$no = $_SESSION['no'];
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
$query = "SELECT * FROM address WHERE no = $no";
$data = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($data); 
$total = mysqli_num_rows($data);
if($total!=0){
  $view1 = "flex";
  $view2 = "block";
  $view = "none";
}

echo '

<div class="name"><b>'.$result["name"].'</b></div>
<div class="mno">Mobile No : '.$result["no"].'</div>
<div class="mno">'.$result["address"].'</div>
<div class="mno">'.$result["state"].'- <b>'.$result["pincode"].'</b></div>
<div class="loadbg">

<div class="loader">
    <img src="/Assets/Icons/Loader.gif">
    <p>Loading</p>
</div>

</div>
';

            
              ?>