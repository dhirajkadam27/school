<?php
include("manage.php");
$no = $_SESSION['no'];
if(!isset($no)){
    header("Location: /Login?ref=$_SERVER[PHP_SELF]");
}


date_default_timezone_set("Asia/Kolkata");
$display = "none";
$view = "none";
$view1 = "none";
$counting = count($_SESSION['cart']);

if($counting == '0'){
    $display = "block";
}
error_reporting(0);
$no = $_SESSION['no'];
$patho = $_SERVER['DOCUMENT_ROOT'];
include $patho.'/Connection/connect.php';
$query = "SELECT * FROM address WHERE no = $no";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data); 
if (!empty($result["name"])){
    $view = "flex";
    $id ="adr";
    $var = "yes";
}
elseif (empty($result["name"])) {
    $view1 = "flex";
    $id1 ="adr";
    $id ="adr1";
    $var = "no";

}

$subtotal = "0";
$subdis = "0";
?>
<html>
    <head>
 
    <meta name='viewport' content='width=device-width, initial-scale=1'>

  <style>
            body{
                margin:0;
                padding:0;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;


  }

  img[alt="www.000webhost.com"]{
               display: none;
           } 
        .loader1{
            box-shadow: 1px 1px 5px 1px rgb(169 169 169);
            display: flex;
            position: absolute;
            top:50%;
            left: 50%;
            z-index: 10;
            border-radius: 10px;
            background: white;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader1 img{
            width:45px;
            height: 45px;
            margin:5px;
            border-radius: 50%;
        }
        .loader1 p{
            font-weight: 600;
            padding-left:20px ;
        }


        .loadbg{
            width: 100%;
            height: 100%;
            background-color: white;
            position: absolute;
            top: 0;
            left: 0;
            display:none
        }
        .loader{
            width:150px;
            box-shadow: 1px 1px 5px 1px rgb(201, 201, 201);
            display: flex;
            position: absolute;
            top:50%;
            left: 50%;
            transform: translate(-50%, -50%);
            -webkit-transform: translate(-50%, -50%);
            -moz-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
        }
        .loader img{
            width:45px;
            height: 45px;
            margin-top: 5px;
            margin-left: 5px;
        }
        .loader p{
            font-weight: 600;
            padding-left:20px ;
        }



        @media only screen and (min-width:320px) and (max-width: 480px){
            .head{
                display:none
            }
            .delihead{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
               border-radius: 5px;
               margin-bottom: 15px;
               position: fixed;
               z-index:3;
               top:0
            }
            .delihead p{
                font-size: 22px;
                margin-top: 9px;
                margin-left: 23px;
                font-weight: 600;
            }
            .arr{
                display: none;
         }
         .arr img{
                display: block;
         }
            .delihead img{
                width: 30px;
               height: 30px;
               margin-top: 9px;
               margin-left: 15px;
            }
            .deliv{
                width: 90%;
                display: none;
                border-bottom: 1px solid #b0b0b0;
                padding: 10px 17px;
                background: white;
                margin-top: 18px;
            }
            #edd{
            width: 150px;
             height: 50px;
             border: none;
             background: gold;
             font-size: 15px;
             font-weight: 600;
             margin-top: 23px;
             margin-left: 188px;
            }
            .chan1{
                display: none
            }
            .chan2{
                display: none
            }
            #delih3{
                display: none
            }

            #edad{
                display: none
            }
            #delih2{
                visibility: hidden
            }

            #delih3{
                display: none
            }
            #delih3{
                display: none
            }

            .bread{ 
                display: none
            }

            .mai{
                position:absolute;
                top:50px;
                width:100%;
            }

            .part{
                width:100%;
            }

            .part1{
                width:100%;
            }
            .prod{
            }
            .items{
                width: 100%;
            }
          .content{
             display:block
          }
        .data{
            width:100%;
              margin-bottom:10px;
              display:flex;
            background: white;
          padding-bottom: 10px;

        }
        .itembtn{
            display:none
        }
.mocon{
    width: 100%;
    position: fixed;
    bottom: 0;
    z-index: 1;
    display: flex;
    background: white;
}
.mopri{
    width: 50%;
    font-size: 22px;
    font-weight: 600;
    text-align: center;
    padding-top: 15px;
}
.mobtn {
    width: 50%;
    padding-top: 8px;
    padding-bottom: 9px;
}
.mobtn button{
    display: block;
    width: 90%;
    height: 42px;
    border: none;
    background: gold;
    margin-left: 5%;
    border-radius: 5px;
    font-size: 15px;
    font-weight: 600;
}
#cont4{
    display: none
}
.itembtn button{
    display:none
}
.img{
    width: 40%;
}
.img img{
    width: 130px;
    height: 130px;
    margin: 8px 15px;
}
.info{
    width: 55%;
    padding-top: 10px;
    padding-left: 20px;
}
.pricing{
    display:flex
}
.name p{
   margin:0;
   font-size:15px;
   font-weight:600
}
.sub p{
   margin:0;
   color:#717171;
   font-size:14px;
}
.price p{
   margin:0;
   font-size:30px;
   font-weight:600
}

.mrp p{
    margin-top: 17px;
    margin-left: 7px;
    font-size: 12px;
}
.dis p{  
      margin-top: 17px;
    margin-left: 7px;
    font-size: 12px;
    color: red;
}
.size p{
   margin:0
}
.probtn{
    display: flex;
    margin-top: 41px;
    margin-left: -157px;
}
.qtybtn{
display:flex;
margin-top: 10px;
}
.qtybtn button{
    background-color: rgba(255, 217, 0, 0.076);
    outline: none;
    margin: 0 5px;
    padding: 3px 12px;
    font-size: 20px;
    border: 1px solid rgb(167, 167, 167);
    border-radius: 50%;

}
.qtybtn input{
    width:50px;
    height: 30px;
    text-align:center
}
.remove{
    border-left: 1px solid rgb(172, 171, 171);
    margin-left:20px;
    height: 50px;
}
.remove button{
    border: 1px solid rgb(158, 158, 158);
    outline: none;
    width: 100px;
    height: 30px;
    margin-left: 50px;
    
    margin-top: 10px;

    border-radius: 2px;
    background-color: transparent;
}
.remove button:hover{
    background:gold
}
.qtybtn button:hover{
    background:gold

}

       .inpadd{
           display: none;
           text-align: center;
       }

       .inpadd input {
    width: 80%;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
}

.inpadd textarea {
    width: 80%;
    height: 130px;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
}

.btnsa button {
    width: 90%;
    padding: 13px 10px;
    font-size: 20px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    margin: 10px 5%;
    margin-top: 15px;
}
       
       .pay{
           display: none;
    margin-top: 20px;
       }
       
       .inpa{
           display: none;
           text-align: center;
       }

       .inpa input {
    width: 80%;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
}

.inpa textarea {
    width: 80%;
    height: 130px;
    padding: 16px 15px;
    outline-color: gold;
    border: 1px solid #9a9a9a;
    border-radius: 5px;
    margin-top: 20px;
    font-size: 15px;
}

.btns button {
    width: 90%;
    padding: 13px 10px;
    font-size: 20px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    margin: 10px 5%;
    margin-top: 15px;
}

.cont2{
    padding: 9px 19px;
    width: 90%;
    height: 50px;
    position: fixed;
    bottom: 10px;
    left: 0;
    margin-left: 18px;
    border: none;
    background: gold;
    font-size: 21px;
    font-weight: 600;

}

.names{
    font-size: 20px;
}

.mno{
    font-size: 19px;
    margin-top: 10px;
}

.addss{
    font-size: 19px;
    margin-top: 10px;
}

.pins{
    font-size: 19px;
    margin-top: 10px;
}

.chan2{
    visibility: hidden
}

.paym{
                width: 100%;
                text-align: center;
                display: none;
                font-size: 25px;
                font-weight: 600;
                margin-bottom: 25px;
            }
            .paym img{
                width: 30px;
                margin-bottom: -7px;
            }
            .paym label{
                margin-left: 10px;
            }

.paym button{
                    width: 90%;
    height: 50px;
    position: fixed;
    bottom: 10px;
    left: 0;
    margin-left: 18px;
    border: none;
    background: gold;
    font-size: 21px;
    font-weight: 600;
            }

            .part2{
                display: block;
                background: white
            }
            .order{
                width: 90%;
    padding: 10px 5%;
            }
            .order div{
                font-size: 20px;
                position: relative
            }
            
            .order span{
                font-size: 20px;
                position: absolute;
                right: 0
            }

            .order button{
                display: none
            }



.error-sec{
                width: 100%;
    height: 100%;
    background: white;
    position: absolute;
    top: 50;
    z-index: 4;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:80%;
height:300px;
}

.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}
.mobifoot{
    width:100%;
    margin-top: 20px;
    padding-bottom: 90px;
}
.mofo{
    width: 50%;
    margin: 5px 25%;
    display: flex;
}
.foimg img{
    width:35px;
    padding-top: 1px;
}
.fosub{
    padding-left: 10px;
    font-size: 10px;
    font-weight: 500;
    color: #8c8c8c;
}





        }

       /* max size */
       @media only screen and (min-width:800px){

            .head{
                width:100%;
                height:50px;
                background:gold;
                display:flex;
                position:fixed;
                top:0;
                z-index: 5;
            }
            .back img{
                width:30px;
               margin: 10px;
               margin-right: 20px;
            }
            .title{
                font-size:25px;
                font-weight:bold;
                line-height: 50px
            }
            .mai{
                position:absolute;
                top:50px;
                width:100%;
            }
           

            .bread{
  margin-left: 5px;
    margin-bottom: 15px;
    font-weight: 600;
    color: #767676;
}
.bread img{
  width:13px;
  height:13px
}
            .part{
                width:100%;
                display: flex;
                justify-content: center;
                margin-top: 18px;
            }
            .part1{
                width:64%;
                margin-right: 19px;
                padding:0 0;
                margin-bottom: 40px;
            }
            .prod{
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
            }
            .items{
                margin-bottom:15px;
                display:flex;
                padding-bottom: 10px;
                padding-left: 15px;
                position: relative;
                display:block
            }
          .content{
             display:block
          }
        .data{
            width:98%;
            height:230px;
              margin-bottom:10px;
              display:flex;
              border-bottom: 2px solid rgb(230 230 230);
          padding-bottom: 10px;

        }
.itembtn{
    width:100%;
    height:40px;
    position:relative
}
#cont6{
    display: none;
    padding: 9px 19px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    position: absolute;
    right: 26px;
}
.mocon{
    display:none
}
.img{
    width:30%;
    height:100%;
}
.img img{
    width:160px;
    height:160px;
    margin: 8px 15px
}
.info{
    width:70%;
    height:95%;
    padding-top:10px;
}
.pricing{
    display:flex
}
.name p{
   margin:0;
   font-size:20px;
   font-weight:600
}
.sub p{
   margin:0;
   color:#717171;
   font-size:19px;
}
.price p{
   margin:0;
   font-size:30px;
   font-weight:600
}
.mrp p{
   margin:0 5px;
   margin-top:12px
}
.dis p{
   margin:0 5px;
   margin-top:12px;
   color: red
}
.size p{
   margin:0
}
.probtn{
    display:flex;
    margin-top: 57px;
    margin-left:-190px
}
.qtybtn{
display:flex;
margin-top: 10px;
}
.qtybtn button{
    background-color: rgba(255, 217, 0, 0.076);
    outline: none;
    margin: 0 5px;
    padding: 3px 12px;
    font-size: 20px;
    border: 1px solid rgb(167, 167, 167);
    border-radius: 50%;

}
.qtybtn input{
    width:50px;
    height: 30px;
    text-align:center
}
.remove{
    border-left: 1px solid rgb(172, 171, 171);
    margin-left:20px;
    height: 50px;
}
.remove button{
    border: 1px solid rgb(158, 158, 158);
    outline: none;
    width: 100px;
    height: 30px;
    margin-left: 50px;
    
    margin-top: 10px;

    border-radius: 2px;
    background-color: transparent;
}
.remove button:hover{
    background:gold
}
.qtybtn button:hover{
    background:gold

}
            .adds{
                width:100%;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 7px;
                position: relative;
            }
            .delihead{
                width:100%;
                height:40px;
                background:gold;
                display:flex;
               border-radius: 5px;
               margin-bottom: 15px;
               position: relative;
               z-index:3
            }
            .delihead img{
                display: none
            }
            .delihead p{
                font-size:22px;
                margin-top:4px;
                margin-left:5px
            }
            .arr p{
             background-color: white;
             padding: 1px 5px;
             font-size: 18px;
             border-radius: 5px;
             margin:6px 5px ;
             margin-left: 15px;
         }
            .delihead img{
                width: 30px;
                margin: 6px 10px;
            }
            .deliv{
                width:100%;
                height:150px;
                margin: 10px 19px;
                display: none;
               
            }
            .editadd{
                width:100%;
                background:#00adff08;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
            }
            .editadd button{
                padding:8px 10px;
                font-weight:bold;
                background:#ff7600;
                border:none;
                outline:none;
                color:white;
                margin:15px 15px;
                margin-top:-5px;
                /* display: none; */
            }
            .spinbtn{
                width:60px
            }
            .deliv button{
                padding:8px 10px;
                font-weight:bold;
                background:#ff7600;
                border:none;
                outline:none;
                color:white;
                margin:15px 0;
            }
            .inpadd{
                text-align:center;
                display: none;
            }
            .inpadd input{
                width:47%;
                height:30px;
                margin:15px 5px;
                outline-color:gold;
            }
           
            .inpadd textarea{
                width:95%;
                height:80px;
                resize:none;
                margin:15px 0;
                outline-color:gold
            }
            .inpa{
                text-align:center;
                display:none
            }
            .inpa input{
                width:47%;
                height:30px;
                margin:15px 5px;
                outline-color:gold;
            }
           
            .inpa textarea{
                width:95%;
                height:80px;
                resize:none;
                margin:15px 0;
                outline-color:gold
            }
            .pay{
                width:100%;
                background:#00adff08;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
            }
            .paym{
                width:90%;
                padding: 15px 20px;
                display: none;
                margin-top: -15px;
                font-size: 25px;
                font-weight: 600;
                padding-bottom: 30px;
            }
            .paym img{
                margin-bottom: -20px;
            }
            .paym label{
                margin-left: 9px;
            }
            .paym button{
                display: none
            }
            .cont1{
                padding: 9px 19px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    position: absolute;
    right: 26px;
            }
            #edad{
                display: none;
            }
            #edad img{
                display: block;
            }
            .cont2{
                padding: 9px 19px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    position: absolute;
    right: 26px;

            }
            .chan1{
                background-color: rgb(255 118 0 / 52%);
    height: 30px;
    position: absolute;
    right: 29px;
    top: 5px;
    border: 2px solid #fff8f1;
    color: #ffffff;
    font-weight: 600;
    border-radius: 7px;
    outline: none;
    display: none;
            }
            .chan2{
                background-color: rgb(255 118 0 / 52%);
    height: 30px;
    position: absolute;
    right: 29px;
    top: 5px;
    border: 2px solid #fff8f1;
    color: #ffffff;
    font-weight: 600;
    border-radius: 7px;
    outline: none;
    display: none;
            }
            .btnsa{
                text-align: left;
            }
            .btns{
                text-align: left;
            }
            .btns button{
                padding: 8px 10px;
    font-weight: bold;
    background: #ff7600;
    border: none;
    outline: none;
    color: white;
    margin: 15px 15px;
    margin-top: -5px;
            }
            .part2{
                width:27%;
                height:250px;
                background-color: rgb(255, 255, 255);
                box-shadow: 0 1px 10px rgba(1,1,1,.15);
                border-radius: 10px;
                position: relative;
                padding: 10px 0;
            }
            .order{
                position: absolute;
                left:5%;
                width: 90%;
            }
            .order span{
                position: absolute;
                right: 0;

            }
           .order button {
                width:90%; 
                height:40px; 
                font-weight: 600; 
                font-size: 15px;
                background-color: 
                gold;border:none;
                margin: 10px 15px;
                outline: none;
                margin-top: 20px;
                display: none;
            }
            .error-sec{
                width: 100%;
    height: 100%;
    background: white;
    position: absolute;
    top: 50;
    z-index: 4;
}
.error-img{
    width:100%;
    text-align:center;
    margin-top:100px
}
.error-img img{
width:40%;
height:300px;
}

.error-btn{
  width:100%;
  text-align:center;
  margin-top:20px;
  margin-bottom:20px;
}
.error-btn button{
    padding:10px 20px;
    font-size:19px;
    border:none;
    background:gold
}
.mobifoot{
    display: none
}











}
        </style>
    </head>
    <body onload="load1()">
    <div id="load1" class="loadbg1">

        <div class="loader1">
            <img src="/Assets/Icons/loader.gif">
        </div>

</div>

        <div class="head">
            <div id="lonoz2" onclick="window.history.back()" class="back">
            <img src="/Assets/Icons/arrowl.png">
        </div>
        <div class="title">
            Derbun
        </div>
        </div>


        <div class="mai" id="body">
        <div class="part">
            <div id="partt" class="part1">

            <div class="bread">Home <img src="/Assets/Icons/arrow.png"> Cart <img src="/Assets/Icons/arrow.png"> Checkout </div>

                <div class="prod">
                    <div id="delih1" class="delihead"><div onclick="deda()" class="arr"><p>1</p></div><img onclick="window.history.back()" src="/Assets/Icons/arrowl.png"><p>Order Summary</p><button id="chan1" onclick="chan1()" class="chan1">Change</button></div>   
                    <div id="items" class="items">
                    
                    <div class="content">
<?php
              foreach($_SESSION['cart'] as $key => $value){

                $subtotal = $subtotal + $value['qty']*$value['mrp'];
                $grandtotal = $grandtotal + $value['qty']*$value['price'];
                
                $subdis = $subdis + $value['qty']*$value['mrp'] - $value['qty']*$value['price'];
                 echo '<div class="data">
                        <div class="img">
                              <img src="'.$value["img"].'">
                        </div>
                              <div class="info">
                                  <div class="name">
                                  <p>'.$value['name'].'</p>
                                  </div>
                                  <div class="sub">
                                  <p>'.$value['sub'].'</p>
                                  </div>
                                          <div class="pricing">
                                            <div class="price">
                                            <p>₹'.$value['price'].'</p>
                                            </div>
                                            <div class="mrp">
                                            <p><strike>₹'.$value['mrp'].'</strike></p>
                                            </div>
                                            <div class="dis">
                                            <p>('.$value['dis'].')</p>
                                            </div>
                                          </div>
                                   <div class="size">
                                   <p>Size: M</p>
                                   </div>
                                   <div class="probtn">
                                   <div class="qtybtn">
                                   <form method="post">
                                   <input type="hidden" name="subby" value='.$value['id'].'>
                                   <button name="sub">-</button>
                                   </form>
                                   <input value='.$value['qty'].' type="text">
                                   <form method="post">
                                   <input type="hidden" name="addy" value='.$value['id'].'>
                                   <button name="add">+</button>
                                   </form>
                                   </div>
                                   <div class="remove">
                                   <form method="post">
                                   <input type="hidden" name="id" value='.$value['id'].'>
                                   <button name="remove">Remove</button>
                                   </form>
                                   </div>
                                   </div>
                              </div>
                 </div>';
                 
              }
?>


                    </div>

<div class="mocon">
<div class="mopri">₹<?php echo $grandtotal ?></div>
 <div class="mobtn"><button onclick="cont1()" id="cont1" class="cont1">Contiune</button><button id="cont4" onclick="cont4()" class="cont4">Contiune</button></div>
</div>
            <div class="itembtn">
            <button onclick="cont1()" id="cont7" class="cont1">Contiune</button>
            <button onclick="cont4()" id="cont6" class="cont4">Contiune</button>
            </div>
                </div>
            </div>

           
                
                    
               <div id="adds" class="adds">
                <div style="display:<?php echo $view ?>" id="delih2" class="delihead"><div onclick="deda()" class="arr"><p>2</p></div><img onclick="deliads()" src="/Assets/Icons/arrowl.png"><p>Delivery Address</p><button id="chan2" onclick="chan2()"  class="chan2">Change</button></div>
                <div id="<?php echo  $id ?>" class="deliv">
                    <div class="ade">
  <?php
 echo '<div class="names"><b>'.$result["name"].'</b></div>
  <div class="mno">Mobile No : '.$result["no"].'</div>
  <div class="addss">'.$result["address"].'</div>
  <div class="pins">'.$result["state"].'- <b>'.$result["pincode"].'</b></div>';
              
                ?>
 
                </div>
                <button id="edd" onclick="edit()" >Edit Address</button>
                <button onclick="cont2()" class="cont2" style="padding: 9px 19px;">Deliver Here</button>
                </div>
                </div>

                  <div id="edadd" class="editadd">
                <div id="edad" class="delihead"><div onclick="edi()" class="arr"></div><img onclick="edba()" src="/Assets/Icons/arrowl.png"><p>Edit Address</p></div>
               <div id="aa" class="inpadd">
               <form id="upda" class="adsform" method="post">
               <input type="text" name="name" value="<?php echo $result["name"]  ?>" placeholder="Name">
               <input type="tel" name="no1" value="<?php echo $no  ?>" disabled placeholder="10 Digit Mobile Number">
               <input type="tel" name="pin" value="<?php echo $result["pincode"]  ?>" placeholder="Pincode">
               <input type="text" value="<?php echo $result["city"]  ?>" name="city" placeholder="City">
               <textarea name="address"  placeholder="Address"><?php echo $result["address"]  ?></textarea>
               <input type="text" value="<?php echo $result["location"]  ?>" name="location" placeholder="City/District/Town">
               <input type="text" value="<?php echo $result["state"]  ?>" name="state" placeholder="State">
               <input type="text" value="<?php echo $result["landmark"]  ?>" name="landmark" placeholder="LandMark">
               <input type="text" value="<?php echo $result["no2"]  ?>" name="no2" placeholder="Alternate Mobile No.">
               </form>
               <div class="respone"></div>
               <div class="btnsa">
               <button onclick="cont3()"  class="adsave">Update</button>
               </div>
               </div>
                </div>
                   

                   
      


               <div id="adds" class="adds">
                <div style="display:<?php echo $view1 ?>" id="addflex" class="delihead"><div onclick="deda()" class="arr"><p>2</p></div><img onclick="edbas()" src="/Assets/Icons/arrowl.png"><p>Add Delivery Address</p></div>
               <div   id="<?php echo $id1 ?>" class="inpa">
               <form id="savads"  class="adsform">
               <input type="text" name="name" value="<?php echo $result["name"]  ?>"  placeholder="Name">
               <input type="tel" name="no1" value="<?php echo $no  ?>" disabled placeholder="10 Digit Mobile Number">
               <input type="tel" name="pin" value="<?php echo $result["pincode"]  ?>" placeholder="Pincode">
               <input type="text"  name="city" value="<?php echo $result["city"]  ?>" placeholder="City">
               <textarea name="address"  placeholder="Address"><?php echo $result["address"]  ?></textarea>
               <input type="text" value="<?php echo $result["location"]  ?>" name="location" placeholder="City/District/Town">
               <input type="text" value="<?php echo $result["state"]  ?>" name="state" placeholder="State">
               <input type="text" value="<?php echo $result["landmark"]  ?>" name="landmark" placeholder="LandMark">
               <input type="text" value="<?php echo $result["no2"]  ?>" name="no2" placeholder="Alternate Mobile No.">
               </form>
               <div class="show"></div>
               <div class="btns">
               <button onclick="okay()" class="adrsave">Save Address</button>
               </div>
               </div>
                </div>
                <!-- <form id="myform">
                <input type="hidden" name="proids" value="'.$proid.'">
                <input type="hidden" name="name" value="'.$name.'">
                <input type="hidden" name="sub" value="'.$sub.'">
                <input type="hidden" name="price" value="'.$price.'">
                <input type="hidden" name="mrp" value="'.$mrp.'">
                <input type="hidden" name="size" value="'.$dis.'">
                <input type="hidden" name="dis" value="'.$sizes.'">
                </form> -->


                <script src="/Assets/Js/JQuery.js"></script>

                <script>
$(document).ready(function(){
    $(".adsave").click(function(){
        $.ajax({
           url: "Checkouts/Update",
           type: "POST",
           data: $('#upda').serialize(),
           success: function(){
            $(".ade").load('Display/');
           }
       });
    });
});
</script>

                <script>
$(document).ready(function(){
    $(".adrsave").click(function(){
       $.ajax({
           url: "Checkouts/Save",
           type: "POST",
           data: $('#savads').serialize(),
           success: function(data){
            document.getElementById("adr").style.display = "none";
            document.getElementById("addflex").style.display = "none";
            document.getElementById("adr1").style.display = "block";
            document.getElementById("delih2").style.display = "flex";
            $(".ade").load('Checkouts/Display');
           }
       });
    });
});
</script>
<script>
$(document).ready(function(){
    $(".cont2").click(function(){
        $(".ade").load('Checkouts/Display');
        $(".loadbg").show();
    });
});
</script>
<script>
$(document).ready(function(){
    $(".adsave").click(function(){
        $(".ade").load('Checkouts/Display');
        $(".loadbg").show();
});
});
</script>

           <script>

var values = "<?php echo $var ; ?>" ;

if (window.matchMedia("(max-width: 480px)").matches) {

    

    if (values == "yes") {
    
        function deliads(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "block";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("part").style.display = "block";

                   
                    }

                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.body.style.background = "white";
                       document.getElementById("part").style.display = "none";
                   
                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "block";
                    }

                    function chan2(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }
                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }

                    function payba(){
                        document.getElementById("delih3").style.display = "none";
                        document.getElementById("pay").style.display = "none";
                        document.getElementById("delih2").style.display = "flex";
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("part").style.display = "none";
                    }

                    function cont2(){
                        document.getElementById("delih3").style.display = "flex";
                        document.getElementById("pay").style.display = "flex";
                        document.getElementById("delih2").style.display = "none";
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("part").style.display = "block";
                    }
                    function edba(){
                       document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("paym").style.display = "block";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                    }

    }



    if (values == "no") {
        
    document.getElementById("addflex").style.display = "none";


        function deliads(){
                       document.getElementById("adr1").style.display = "none";
                       document.getElementById("items").style.display = "block";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("part").style.display = "block";
                       document.getElementById("cont4").style.display = "block";
                       document.getElementById("cont1").style.display = "none";
                
                    }

                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("addflex").style.display = "flex";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.body.style.background = "white";
                       document.getElementById("part").style.display = "none";
                   
                    }
                    function cont4(){
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.body.style.background = "white";
                       document.getElementById("part").style.display = "none";
                   
                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "block";
                    }

                    function chan2(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }
                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }

                    function payba(){
                        document.getElementById("delih3").style.display = "none";
                        document.getElementById("pay").style.display = "none";
                        document.getElementById("delih2").style.display = "flex";
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("part").style.display = "none";
                    }

                    function cont2(){
                        document.getElementById("delih3").style.display = "flex";
                        document.getElementById("pay").style.display = "flex";
                        document.getElementById("delih2").style.display = "none";
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr1").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("part").style.display = "block";
                    }
                    function edba(){
                       document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("paym").style.display = "block";
                    }
                    function edbas(){
                        document.getElementById("addflex").style.display = "none";
                        document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "block";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("part").style.display = "block";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr1").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                    }


}


}



if (window.matchMedia("(min-width: 480px)").matches) {


    if (values == "yes") {

        function deliads(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "block";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("part").style.display = "block";

                   
                    }

                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.body.style.background = "white";
                   
                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "block";
                       
                    }

                    function chan2(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";

                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }
                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }

                    function payba(){
                        document.getElementById("delih3").style.display = "none";
                        document.getElementById("pay").style.display = "none";
                        document.getElementById("delih2").style.display = "flex";
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("part").style.display = "none";
                    }

                    function cont2(){
                        document.getElementById("delih3").style.display = "flex";
                        document.getElementById("pay").style.display = "block";
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("part").style.display = "block";
                    }
                    function edba(){
                       document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                    }
                    
    }

    if (values == "no") {
        function deliads(){
                       document.getElementById("adr1").style.display = "none";
                       document.getElementById("items").style.display = "block";
                       document.getElementById("chan1").style.display = "none";
                       document.getElementById("delih2").style.visibility = "hidden";
                       document.getElementById("part").style.display = "block";
                    }

                    function cont1(){
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.body.style.background = "white";
                   
                    }
                    function cont4(){
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("chan1").style.display = "block";
                       document.getElementById("delih2").style.visibility = "visible";
                       document.body.style.background = "white";
                   
                    }
                    function chan1(){
                       document.getElementById("adr").style.display = "none";
                       document.getElementById("items").style.display = "block";
                       document.getElementById("cont6").style.display = "block";
                       document.getElementById("cont7").style.display = "none";
                    }

                    function chan2(){
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                    }
                    function edi(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }
                    function cont3(){
                        document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                       document.getElementById("loadbg").style.display = "flex";
                    }

                    function payba(){
                        document.getElementById("delih3").style.display = "none";
                        document.getElementById("pay").style.display = "none";
                        document.getElementById("delih2").style.display = "flex";
                       document.getElementById("paym").style.display = "none";
                       document.getElementById("adr").style.display = "block";
                       document.getElementById("chan2").style.display = "none";
                       document.getElementById("buybtn").style.display = "none";
                       document.getElementById("part").style.display = "none";
                    }

                    function cont2(){
                        document.getElementById("delih3").style.display = "flex";
                        document.getElementById("pay").style.display = "block";
                       document.getElementById("paym").style.display = "block";
                       document.getElementById("adr1").style.display = "none";
                       document.getElementById("chan2").style.display = "block";
                       document.getElementById("buybtn").style.display = "block";
                       document.getElementById("orsa").style.cssText = "text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;";
                       document.getElementById("part").style.display = "block";
                    }
                    function edba(){
                       document.getElementById("aa").style.display = "none";
                       document.getElementById("edad").style.display = "none";
                       document.getElementById("adr1").style.display = "block";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "flex";
                       document.getElementById("delih2").style.display = "flex";
                       document.getElementById("delih3").style.display = "flex";
                    }
                    function edit(){
                       document.getElementById("aa").style.display = "block";
                       document.getElementById("edad").style.display = "flex";
                       document.getElementById("adr1").style.display = "none";
                       document.getElementById("items").style.display = "none";
                       document.getElementById("delih1").style.display = "none";
                       document.getElementById("delih2").style.display = "none";
                       document.getElementById("delih3").style.display = "none";
                       document.getElementById("paym").style.display = "none";
                    }

    }
                   



}

function place(){
                       window.location.replace('Checkouts/Confirm');
                    }

                    function doneplace(){
                        window.location.replace('Checkouts/Confirm');
                    }
                </script>



<div id="pay" class="pay">
    <div id="delih3" class="delihead"><div onclick="deda()" class="arr"><p>3</p></div><img onclick="payba()" src="/Assets/Icons/arrowl.png"><p>Payment</p></div>
    <div id="paym" class="paym">
    <img src="/Assets/Icons/tick.png"><label>Cash On Delivery</label>
        <button onclick="doneplace()" > Proceed </button>
    </div>
    </div>
            
            </div>
            <div id="part" class="part2">
                <div class="order">
                <div style="margin-bottom: 20px; color: rgb(123, 123, 123); font-weight: 600;" class="ordertit">Order Details</div>
                <div style="margin:10px 0" class="ordermrp">Items MRP<span>₹<?php echo  $subtotal  ?></span></div>
                <div style="margin:10px 0" class="orderdis">Discount<span style="color:rgb(7, 162, 59)"> -&nbsp;₹<?php echo  $subdis ?></span></div>
                <div style="margin:10px 0" class="ordership">Delivery Charges<span style="color:rgb(7, 162, 59)">Free</span></div>
                <div style="margin:15px 0;padding-top: 6px;border-top: 1px solid #ababab;" class="ordertotal">Total Amount<span>₹<?php echo  $grandtotal ?></span></div>
                <button id="buybtn" onclick="place()">Procced</button>
                <!-- <div style="text-align:center;margin-top:-8px;color: rgb(7, 162, 59);font-weight: 500;" class="ordersave">You Have Saved 5454</div> -->
                <div style="text-align:center;margin-top: 33px;color: rgb(255 118 0);font-weight: 500;font-size: 25px;" id="orsa" class="ordersave">You Have Saved ₹<?php echo  $subdis ?></div>
               </div>
                
               <div class="mobifoot">
<div class="mofo">
<div class="foimg"><img src="/Assets/Icons/payment.png"></div>
<div class="fosub">Safe And Secure Payment. 100% Original Products.</div>
</div>
</div>

            </div>

        </div>
    </div>

    <script>
    var loadf = document.getElementById("load1");
function load1(){
loadf.style.display = "none";
}

    </script>
        
        <div style="display: <?php echo $display ?>" class="error-sec">
                  <div class="error-img">
                      <img src="/Assets/Icons/error 2.png">
                      <div class="error-btn">
                          <button>Shop Now</button>
                      </div>
                 </div>
               
 </div>

 <script>
  $("#lonoz2").click(function(){
        document.getElementById("load1").style.display = "block";
  });

</script>


    </body>
</html>