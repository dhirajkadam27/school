<?php
// error_reporting(0);
ini_set('session.cookie_lifetime', 5184000);
ini_set('session.gc_maxlifetime', 5184000);
if(isset($_COOKIE[session_name()])){
    session_start();
}
else{
    session_start();
}
 $samecart = false;

 if(isset($_POST['id']) && isset($_POST['sub']) && isset($_POST['price']) && isset($_POST['size'])){
		if(isset($_SESSION['cart'])){
			$check = array_column($_SESSION['cart'], 'id');
			if(in_array($_POST['id'], $check)){
				$samecart = true;
			}
			else{
			$count = count($_SESSION['cart']);
			$_SESSION['cart'][$count] = array('id'=>$_POST['id'],'name'=>$_POST['name'],'sub'=>$_POST['sub'],'price'=>$_POST['price'],'mrp'=>$_POST['mrp'],'qty'=>'1', 'dis'=>$_POST['dis'],'size'=>$_POST['size'],'color'=>$_POST['color'],'style'=>$_POST['style'],'img'=>$_POST['img']);
			}
		}
		else{
			$_SESSION['cart'][0]= array('id'=>$_POST['id'],'name'=>$_POST['name'],'sub'=>$_POST['sub'],'price'=>$_POST['price'],'mrp'=>$_POST['mrp'], 'qty'=>'1','dis'=>$_POST['dis'],'size'=>$_POST['size'],'color'=>$_POST['color'],'style'=>$_POST['style'],'img'=>$_POST['img']);
		}
	}


	if(isset($_POST['remove'])){
		
		foreach($_SESSION['cart'] as $key => $value){
			if($value['id'] == $_POST['remove']){
		unset($_SESSION['cart'][$key]);
		   $_SESSION['cart']= array_values($_SESSION['cart']);
			}
		}
	}
	

	
	if(isset($_POST['addy'])){
		
		foreach($_SESSION['cart'] as $key => $value){
			if($value['id'] == $_POST['addy']){
		$_SESSION['cart'][$key]['qty'] = ++$_SESSION['cart'][$key]['qty'];
		}
	}
	
}


if(isset($_POST['subby'])){
		
	foreach($_SESSION['cart'] as $key => $value){
		if($value['id'] == $_POST['subby']){
			if($value['qty'] > "1"){
	$_SESSION['cart'][$key]['qty'] = --$_SESSION['cart'][$key]['qty'];
			}
	}
}

}

?>