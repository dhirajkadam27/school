var cacheName = 'Derbun';
var filesToCache = [
  '/Home.html',
  '/Offline/Icons/',
];

/* Start the service worker and cache all of the app's content */
self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return cache.addAll(filesToCache);
    })
  );
});

/* Serve cached content when offline */
self.addEventListener('fetch', function(e) {
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});



self.addEventListener('install', function(event) {
  self.skipWaiting();
});

     self.addEventListener('sync', function(event) {
       
  fetch('read.php').then(function(res){
    
    console.log(res);
    return res.json();
}).then(function(result){
    console.log(result);
    for (let x in result) {
        self.registration.showNotification(`${result[x].title}`,{
          body : `${result[x].msg}`,
          icon : "/Offline/Icons/512.png"
          });
    }
    
});
  
     });