
<!DOCTYPE html>
<html>
<head>

<!--This Website is created by DHIRAJ KADAM on 5/10/2020.-->
<!--Contact details: [Mobile No. 7757897339/7410743968]; [E-mail id: dhirajkadam.official@gmail.com]-->
<!--This site is copyrighted.©️ All rights are ®️reserved (contact us for more information)-->
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTkNdkQWbd72kWkeAxBQQuiuYc1TPwRtBKwRQ&usqp=CAU" type="image/wepb" sizes="32x32">


<!--Desktop Version-->
<meta name="viewport" content="width=1024">
<!--Desktop Version-->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
 <!--Desktop Version-->
 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
 
 <script src="/path/to/js/jquery.autoscroll.js"></script>
 <!--Desktop Version-->
<title>AKJC Atpadi</title>
<!--Desktop Version-->
<style>
body{
     margin:0;
     padding:0;
}
/*header logo*/
header{
       display:flex;
       background: white
}
/*College Name*/
#texts{
      margin-left:20px;
      margin-top:12px;
}
header h3{
   color: #de0d0d; 
   font-size: 19px;
   font-weight: bold;
   font-family: 'Montserrat', sans-serif;
}
header p{
   color: black; 
   font-size: 17px;
   font-family: 'Roboto', sans-serif;
}
/* College contact*/
#Contact{
                margin-left:140px;
                text-align: center;
                margin-top:15px
                
}
/* College Image Slider */
{box-sizing: border-box;}
.mySlides {display: none;
    }
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
 max-width: 100%;
 position: relative;
 margin: auto;
}

/* Caption text */

/* Number text (1/3 etc) */
.numbertext {
 color: #f2f2f2;
 font-size: 12px;
 padding: 8px 12px;
 position: absolute;
 top: 0;
}

/* The dots/bullets/indicators */

/* Fading animation */
.fade {
 -webkit-animation-name: fade;
 -webkit-animation-duration: 1.5s;
 animation-name: fade;
 animation-duration: 1.5s;
}

@-webkit-keyframes fade {
 from {opacity: .4} 
 to {opacity: 1}
}

@keyframes fade {
 from {opacity: .4} 
 to {opacity: 1}
}
/*navigation bar*/
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #bababa;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-family: 'Noto Sans JP', sans-serif;
  font-weight: bold;
  font-size:12px
}

li a:hover{
           color: white;
           background: #4ca64c
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #bababa;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #4ca64c;}

.dropdown:hover .dropdown-content {
  display: block;
}
/*college info*/
.horizontal {
             background:#F7F7F7;
             width:100%;
             height:200px;
             margin-top:-17px;
             padding:0
}
.info{
      display:flex;
     
}
.icon span{
           font-size:40px;
           font-family: 'Roboto', sans-serif;
           margin-bottom:-30px
}
.icon h6{
         font-size:15px
}
.icon span, h6{
              display: block;
              margin-left:145px;
              text-align: center;
              font-family: 'Roboto', sans-serif;
               
}
.icon img{
          width:60px;
          height:60px;
          opacity:0.4;
          margin-left:145px;
          Margin-top:25px;
          margin-bottom:20px
}

.feature {
          width:100%;
          height:500px;
          background:#f6f6f6
}

.feature p{
            text-align: center;
            font-family: 'Roboto', sans-serif;
            font-size:50px;
            padding:20px 0 0 0

}

footer{
       background: black;
       height:400px;
       width:100%;
}

.type {
       display:flex;
       font-size:12px;
}
.type b{
        margin-left:90px;
        
}
.type p{
        margin-left:90px;
        margin-top:-8px
}
.sub-type{
margin-top:70px
}

footer b {
          color: white;
          font-family: 'Noto Sans JP', sans-serif;  
          
}

footer p{
         color:#bababa;
         font-family: 'Roboto', sans-serif;
}
.developer {
            margin-top:-1px;
            padding:20px 0;
            color: black;
            background: #bababa;
            font-size:15px;
            font-weight:bold;
            text-align: center;
            font-family: 'Roboto', sans-serif;
            
}

/*scrollbar*/
.scrollbar{
           display:flex;
} 

.check{
       display:flex;
       margin-top:20px
}
.button1 {
         background:#32CD32;
         width:50px;
         height:30px; 
         line-height:30px;
         color: white;
         margin-left:55px;
         padding:5px 10px;
         text-align: center;
         font-family: 'Roboto', sans-serif;
         font-weight:bolder
}

.button2 {
         background:#32CD32;
         width:50px;
         height:30px; 
         line-height:30px;
         color: white;
         margin-left:386px;
         padding:5px 10px;
         text-align: center;
         font-family: 'Roboto', sans-serif;
         font-weight:bold
}

.png img{
         width:130px;
         height:130px;
         opacity:0.3
}
.lab{
     display:flex;
     margin-top:-5px
}
.lab b{
       font-family: 'Montserrat', sans-serif;
       font-size:13px;
       margin-left:7px
}

.png1 img{
         width:130px;
         height:130px;
         margin-left:100px;
         opacity:0.3
}
.lab1{
     display:flex;
     margin-top:80px
}
.lab1 b{
       font-family: 'Montserrat', sans-serif;
       font-size:13px;
       margin-left:7px
}

.tagline{
         text-align: center;
         margin-top:100px;
         font-family: 'Tangerine', cursive;
         height:300px;
         width:100%;
         font-size:55px;
         border-width:1px;
         border-style: solid;
         padding-top:30px;
         border-color:green;
         font-weight:bold
}

.bio{
     width:100%;
     height:400px
}

.data{
     width:900px;
     height:300px;
     border-style: solid;
     border-width:1px; 
     margin:90px auto;
     text-align: center
}
.data p{
         font-family: 'Montserrat', sans-serif;
         font-size: 25px
}
.data b{
        font-size:20px;
         font-family: 'Roboto', sans-serif;
}

.read{
      width:180px;
      height:70px;
      line-height:70px;
      background:red;
      margin-left:690px;
      color: white;
       font-family: 'Montserrat', sans-serif;
      border-width:0;
      margin-top:-10px;
      font-size:20px
}
.lin{
     width:90%;
     margin:0 auto;
     padding: 0 10px;
}
.button3 {
         background:#32CD32;
         width:90px;
         height:40px; 
         line-height:40px;
         color: white;
         padding:5px 10px;
         text-align: center;
         font-family: 'Roboto', sans-serif;
         font-weight:bold;
         Margin-top:-80px;
         font-size:35px;
         margin-bottom:30px
}

</style>
</head>
<body>
<!--Font style-->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Tangerine:wght@700&display=swap" rel="stylesheet">
<!-- font style end-->
<header>
<!-- College logo-->
<div id="img">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTkNdkQWbd72kWkeAxBQQuiuYc1TPwRtBKwRQ&usqp=CAU" style="margin:10px; height:110px"> 
</div>
<!-- college Logo end-->

<!--College details-->
<div id="texts">
<p style="margin-bottom:-14px" >Atpadi Education Society</p>
<h3>Abasaheb Khebudkar Junior College Of Science</h3>
<p style="margin-top:-12px">Affiliated to Shivaji University, kolhapur</p>
</div>
<!--College details end-->

<!--Contact info-->
<div id="Contact">
<p style="font-size:13px; font-family: 'Montserrat', sans-serif; font-weight: bolder; color:green; margin-top:25px">Contact Us</p>
<div style="display:flex" class="phone">
<img style="width:12px; height:12px; margin-top:-4px; margin-left:40px; " src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRAxXGn00tcP6pFL_qE7wRnJVkmc2kuT5SOng&usqp=CAU">
<p style="margin-top:-4px; margin-left:0px; font-family: 'Montserrat', sans-serif; font-size:10px">(02343)220248</p>
</div>
<p style="margin-top:-5.5px; font-family: 'Montserrat', sans-serif; font-size:10px">sbvakjrcollegeatpadi@gmail.com</p>
</div>
<!--contact info end-->
</header>
<!--NAV BAR -->
<ul>
  <li><a href="Home.php"  style="background:#4ca64c; color: white" >HOME</a></li>
  <li class="dropdown">
  <a href="javascript:void(0)" class="dropbtn">ABOUT<i style="margin-left:5px" class="fas fa-angle-down"></i></a>
  <div class="dropdown-content">
  <a href="College.html">COLLEGE</a>
  <a href="Atpadi Education Society.html">ATPADI EDUCATION SOCIETY</a>
   <a href="Founder.html">FOUNDER BABASAHEB DESHMUKH</a>
    <a href="Chairman.html">CHAIRMAN BAPUSAHEB DESHMUKH</a>
  </div>
  
  <li class="dropdown">
  <a href="javascript:void(0)" class="dropbtn">ADMINISTRATION<i style="margin-left:5px" class="fas fa-angle-down"></i></a>
  <div class="dropdown-content">
  <a href="Teaching Staff.php">TEACHING STAFF</a>
  <a href="Non-Teaching Staff.php">NON-TEACHING STAFF</a>
  <a href="College Management.php">COLLEGE MANAGEMENT</a>
  <a href="Alumni.php">ALUMNI</a>
  </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">COURSES<i style="margin-left:5px" class="fas fa-angle-down"></i></a>
    <div class="dropdown-content">
      <a href="11th.html">11th</a>
      <a href="12th.html">12th</a>
      <a href="MH-CET.html">MH-CET</a>
      <a href="NEET.html">NEET</a>
      <a href="JEE.html">JEE</a>
    </div>
  </li>
  <li><a href="Facilities.html">FACILITIES</a></li>
  <li><a href="Students.html">STUDENTS</a></li>
   <li style="margin-left:220px; margin-top:2px; "><a style="color:#de0d0d; font-family: 'Montserrat', sans-serif; font-size:14px" href="Online Admission.html">ONLINE ADMISSION</a></li>
  
</ul>

<!--NAV BAR end-->


<!--IMG slider-->
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 4</div>
  <img height="350px" src="https://lh3.googleusercontent.com/p/AF1QipMvnzyPr2Q0lcclQCRg3Bg9xe8R4sVPRNpmy45M=w2538-h4174" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 4</div>
  <img height="350px" src="https://lh3.googleusercontent.com/p/AF1QipOuPw2aTXGL4mt18qnajf34wKxPNaqmxDDc1jT3=w2538-h4174" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 4</div>
  <img height="350px" src="https://lh3.googleusercontent.com/p/AF1QipPhoeooxUH2cfpqBFWUg7WCJp2-xzJk58Ouak21=w2538-h4174" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">4 / 4</div>
  <img height="350px" src="https://lh3.googleusercontent.com/p/AF1QipOyc9fT7CfdG2tV2G1O38wZB5s7R1-Vxec3GKfA=w720-h1184" style="width:100%">
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
<!--IMG slider-->


<!--College info-->
<div class="horizontal">
<div class="info">

<div class="icon">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSHcss-ImNrrwUt0fPwLCd0lfjdattkHNJOtA&usqp=CAU">
<span class="num">875</span>
<h6>Students</h6>
</div>
<div class="icon">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSRLTCNiO7tJOQ8DxqmaBAED6l4h_DlW_Cp0Q&usqp=CAU">
<span class="num">6</span>
<h6>Courses</h6>
</div>
<div class="icon">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSYocE9VhxngaYz1lB_7msZO9JGUoWaIVx9VA&usqp=CAU">
<span class="num">12</span>
<h6>Department</h6>
</div>
<div class="icon">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRRHE2YdCQxrc_D_L-OghMTYIXVQCluA2c1Hg&usqp=CAU">
<span class="num">31</span>
<h6>Teachers</h6>
</div>
</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
$('.num').counterUp({delay:10,time:1000});
});
</script>
<!--College info end-->

<!--scrollbar-->
<div class="check">
<div class="button1">
Event
</div>

<div class="button2">
Notice
</div>

</div>
<div class="scrollbar">

<div id="ecran" style='overflow:auto;width:400px;height:200px;border:solid 1px green; margin-left:55px'>
 <br/><br/><br/><br/><br/><br><br>
 <?php
                 include_once 'config.php';
                 error_reporting(0);
                 $query = "SELECT * FROM event";
                 $data = mysqli_query($conn, $query);
                 $total = mysqli_num_rows($data);
                
         
                 if($total!=0){
                     while($result = mysqli_fetch_assoc($data)){
                         echo"
                         <tr>
                         <td><img style='width:60px; height:60px' src='https://www.clipartsmania.com/gif/words/arrow-with-new-letter-icon-gif-animation.gif'></td>
                         <td>".$result['info']."</td><br><br>
                         </tr>
                         ";

                     }
                 }
                 else{
                     echo "<div style ='margin-top:35px; margin-left:450px' class='alert alert-danger' role='alert'>
                     Records Not Found!
                   </div>";
                 }
                ?>
<br/><br/><br/><br/><br/><br><br>

</div>

<script type='text/javascript'>
function ScrollDiv(){

   if(document.getElementById('ecran').scrollTop<(document.getElementById('ecran').scrollHeight-document.getElementById('ecran').offsetHeight)){-1
         document.getElementById('ecran').scrollTop=document.getElementById('ecran').scrollTop+1
         }
   else {document.getElementById('ecran').scrollTop=0;}
}

setInterval(ScrollDiv,50)
</script>


<div id="run" style='overflow:auto;width:400px;height:200px;border:solid 1px green; margin-left: 55px'>
 <br><br><br><br><br><br><br>
 <?php
                 include_once 'config.php';
                 error_reporting(0);
                 $query = "SELECT * FROM notice";
                 $data = mysqli_query($conn, $query);
                 $total = mysqli_num_rows($data);
                
         
                 if($total!=0){
                     while($result = mysqli_fetch_assoc($data)){
                         echo"
                         <tr>
                         <td><img style='width:60px; height:60px' src='https://www.clipartsmania.com/gif/words/arrow-with-new-letter-icon-gif-animation.gif'></td>
                         <td>".$result['info']."</td><br><br>
                         </tr>
                         ";

                     }
                 }
                 else{
                     echo "<div style ='margin-top:35px; margin-left:450px' class='alert alert-danger' role='alert'>
                     Records Not Found!
                   </div>";
                 }
                ?>
                <br/><br/><br/><br/><br/>

</div>
	
	
	
<script type='text/javascript'>
function ScrollDiv(){

   if(document.getElementById('run').scrollTop<(document.getElementById('run').scrollHeight-document.getElementById('run').offsetHeight)){-1
         document.getElementById('run').scrollTop=document.getElementById('run').scrollTop+1
         }
   else {document.getElementById('run').scrollTop=0;}
}

setInterval(ScrollDiv,50)
</script>

</div>

<!--scrollbar end-->
<!--tagline-->
<div class="lin">
<div class="tagline">
<div class="button3">
Aim
</div>
<img style="width:50px; height:50px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ9By37kwlhWr4JVaVOhBwjxSoalYEBjpsyvA&usqp=CAU">
We want the best Students from all around.<br>
Good Students are like brand ambassadors.<br>
Our alumni add value to our institution.
<img style="width:50px; height:50px" src="https://image.flaticon.com/icons/png/512/102/102571.png">
</div>
</div>
<!--tagline ends-->
<!--features-->
<div class="feature">
<p>Silent Features</p>
<div class="lab">
<div class="png">
<img style="margin-left:60px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTayD6_eI1poIfNgN6G21HTLaDlUUjrmv6AWA&usqp=CAU">
<b>Computer Lab</b>
</div>
<div class="png">
<img style="margin-left:80px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTsUdxh1OQ_VwTWDcul8Y-lXLK2RNFNAdsZzQ&usqp=CAU">
<b>Physics Lab</b>
</div>
<div class="png">
<img style="margin-left:80px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRz75HM4WqMAT-5rtjDUArnS_Bd5EDazOktAA&usqp=CAU">
<b>Chemistry Lab</b>
</div>
</div>

<div class="lab1">
<div class="png1">
<img style="margin-left:60px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSvPvk3CG7gPC2fy-XGhkibK6eSxeOxFUnxeA&usqp=CAU">
<b>Youth Festivals</b>
</div>
<div class="png1">
<img style="margin-left:80px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRIqYAe80hgNXqF3mR9xEGnqmGJbiVSvvZCPg&usqp=CAU">
<b>Library</b>
</div>
<div class="png1">
<img style="margin-left:100px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8phwmLdfrOXVg4X3o8Q3d5vByxlWXAeuWiQ&usqp=CAU">
<b>Play Ground</b>
</div>
</div>

</div>
<!--features end-->

<!--biodata-->
<div class="bio">
<div class="data">
<p style="margin-top:40px;">Abasaheb Khabudkar Junior College Of Science </p>
<br>
<b>Inspired by the idea that there
 is no alternative but education 
 to make the society self-reliant 
 and self-respecting, Shrimant Babasheb Deshmukh (Dada) 
 founded the Atpadi Education Society on 12 December 1953. 
 Junior Science College was started from June 1975 at Shri Bhavani Vidyalaya, Atpadi, 
 which is an educational hub in Atpadi area. In the year 2004, 
 this junior college was renamed as 'Abasaheb Khebudkar Junior College of Science'.
</b>

<button class="read">
<a style="text-decoration:none;color: white" href="hhh.com" >
Read more
</a>
</button>
</div>
</div>

<!--biodata-- ends-->

<footer>
<div class="type">
<div class="sub-type">
<b>Atpadi Education Society</b>
<p style="margin-top:20px">Shri Bhavan Vidhyalay</p>
<p>Abasaheb khabudkar junior College</p>
<p>Atpadi College Atpadi</p>
<p>Girls Highschool Atpadi</p>
</div>

<div class="sub-type">
<b>Administration</b>
<p style="margin-top:20px">Teaching Staff</p>
<p>Non-teaching Staff</p>
<p>Alumni</p>
<p></p>
</div>

<div class="sub-type">
<b>About</b>
<p  style="margin-top:20px">College</p>
<p>Founder</p>
<p>Chairman</p>
</div>

<div class="sub-type">
<b>Contact Info</b>
<p  style="margin-top:20px">Abasaheb Khabudkar </p>
<p>Junior College,Atpadi</p>
<p>Tal-Atpadi; Dist-Sangli</p>
<p>(Maharashtra)</p>
<p>Pincode-415301</p>
<b>Location</b>
<p style="margin-top:20px">Telephone No.(02343)220248</p>
<p>E-mail id: sbvakjrcollegeatpadi@gmail.com</p>
</div>
</div>
</footer>

<div class="developer">
®All Rights Are Reserved By Dhiraj Kadam. Contact No.7757897339/7410743968 E-mail id- dhirajkadam.official@gmail.com
</div>
</html>