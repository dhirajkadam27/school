<?php
include_once 'config.php';
$insert = false;
$insertt = false;
if(isset($_POST['save']))
{	 
  $year = $_POST['year'];
  $precent = $_POST['precent'];
	
	 $sql = "INSERT INTO `aluy`(`year`, `pre`)
     VALUES ('$year','$precent')";

if($conn->query($sql) == true) {
    $insert = true;
    } 
    else {
        echo "QUERY NOT CONNECTED";
    }
}
elseif(isset($_POST['save1']))
{	 
  $Name = $_POST['Name'];
	
	 $sql = "INSERT INTO `alua`(`Name`)
     VALUES ('$Name')";

if($conn->query($sql) == true) {
    $insertt = true;
    } 
    else {
        echo "QUERY NOT CONNECTED";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <!--This Website is created by DHIRAJ KADAM on 5/10/2020.-->
<!--Contact details: [Mobile No. 7757897339/7410743968]; [E-mail id: dhirajkadam.official@gmail.com]-->
<!--This site is copyrighted.©️ All rights are ®️reserved (contact us for more information)-->
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTkNdkQWbd72kWkeAxBQQuiuYc1TPwRtBKwRQ&usqp=CAU" type="image/wepb" sizes="32x32">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<!--Desktop Version-->
<meta name="viewport" content="width=1024">
<title>Admin Panel</title>
        <style>
            body{
                margin:0;
                padding:0;
            }
            .title{
                text-align: center;
                font-size: 29px;
                margin-top: 10px;
                font-family: Verdana, Geneva, Tahoma, sans-serif;
                font-weight: bold;
            }

            .inbu{
                width: 111px;
                height: 34px;
                background-color: greenyellow;
                color:brown;
                font-weight: bolder;
                font-size: 24px;
            }
            table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 400px;
  margin:40px 60px;
  
}

td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px
}

tr:nth-child(even) {
  background-color: #dddddd;
}
button{
    background-color : blue;
    font-weight:bold;
    color:white;
    text-align:center;
}
button:after{
    background-color:red;
}
.fle{
    display:flex;
    margin-top:-100px;
    margin-bottom:50px
}
        </style>
    </head>
    <body>
        <div class="title"><u>Add College Alumni</u></div>
        <hr style="margin-top: 20px;">
        <div style="display:flex;text-align:center">
        <p style="width:50%;padding:5px 0; height:120px; background-color:gray; color:white; font-size: 20px; font-family: Verdana, Geneva, Tahoma, sans-serif; font-weight: bold;">HSC Toppers</p>

        <p style="width:50%;padding:5px 0;background-color:lightgrey; color:black; font-size: 20px; font-family: Verdana, Geneva, Tahoma, sans-serif; font-weight: bold;">Seleted Students For Inspired Award</p>

    </div>
   
      <div class="fle">
      <div style="text-align:center">
            <form method="post" action="Alumni Edit.php">
            <input  required style="" name="year" style="" type="text" placeholder="Enter Year " class="in">
            <input  required name="precent" type="text" style="" placeholder="Enter Precentage " class="in"><br>
            <input type="submit" value="Add" class="inbu" name="save">
        </form>
        </div>
     
       
        <div style="text-align:center">
              <form method="post" action="Alumni Edit.php">
              <input required style="margin-left:10px;" name="Name" style="" type="text" placeholder="Enter Name " class="in">
              <input type="submit" value="Add" class="inbu" name="save1">
          </form>
          </div>
        </div>
        <hr style="margin-top: 20px;">
        <?php
        error_reporting(0);
        if($insert == true) {
          echo"<div style ='text-align:center;margin-top:10px' class='alert alert-success' role='alert'>
          Successfully Added A New Record!
        </div>";
          } 
          else {
              echo "";
          }
         
        ?>
        
        <?php
        error_reporting(0);
        if($insertt == true) {
          echo"<div style ='text-align:center;margin-top:10px' class='alert alert-success' role='alert'>
          Successfully Added A New Record!
        </div>";
          } 
          else {
              echo "";
          }
         
        ?>

<div style="display:flex">
        <table>
            <tr>
            <th>Year</th>
            <th>Precentage</th>
            <th>Delete</th>
        </tr>
        <?php
        include_once 'config.php';
        error_reporting(0);
        $query = "SELECT * FROM aluy";
        $data = mysqli_query($conn, $query);
        $total = mysqli_num_rows($data);
       

        if($total!=0){
            while($result = mysqli_fetch_assoc($data)){
                echo"
                <tr>
                <td>".$result['year']."</td>
                <td>".$result['pre']."</td>
                <td style= 'text-align:center'><a href='deleteo.php?rn=".$result[ID]."'><button>Delete</button></a></td>
                </tr>
                ";

            }
        }
        else{
            echo "";
        }
        ?>
         </table>
        

        <table>
            <tr>
            <th>Name</th>
            <th>Delete</th>
        </tr>
        <?php
        include_once 'config.php';
        error_reporting(0);
        $query = "SELECT * FROM alua";
        $data = mysqli_query($conn, $query);
        $total = mysqli_num_rows($data);
       

        if($total!=0){
            while($result = mysqli_fetch_assoc($data)){
                echo"
                <tr>
                <td>".$result['Name']."</td>
                <td style= 'text-align:center'><a href='deletes.php?rn=".$result[Name]."'><button>Delete</button></a></td>
                </tr>
                ";
            }
        }
        else{
            echo "";
        }
        ?>
         </table>
         </div>
    </body>
</html>
