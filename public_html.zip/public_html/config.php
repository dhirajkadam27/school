<?php 
 $servername = "localhost";
 $username = "id14758305_dhiraj";
 $password = "E+qJW~Zj@iFD_]X2";
 $name = "id14758305_college";

$conn = new mysqli($servername, $username, $password, $name);

if($conn->connect_error){
	echo"Unable To Connect The server";
}
else{
	echo "";
}
 ?>