<?php
 if(isset($_POST['url'])){
$con = curl_init($_POST['url']);
curl_setopt($con, CURLOPT_RETURNTRANSFER, 1);
$RUN = curl_exec($con);
$AZ = preg_replace('/\s\s+/', ' ', $RUN);

 preg_match($_POST['type'], $AZ, $AM);
 print_r($AM);
 }

?>

<html>
<head>
	
	<style type="text/css">
		
	</style>
</head>
<body>
	
	<form method="post">
<input type="text" name="url">
<input type="text" name="type">
<button>Go</button>
	</form>
</body>
</html>