<?php
include 'simple_html_dom.php';

if (isset($_POST['url'])) {
// Create DOM from URL or file
$url = $_POST['url'];
$find = $_POST['find'];
$html = file_get_html($url);

// Find all images
echo $html->find($find, 0)->plaintext;
}


?>

<html>
<head>
	
</head>
<body>
	<form method="post">
<input type="text" name="url">
<input type="text" name="find">
<button>Send</button>
</form>
</body>
</html>

