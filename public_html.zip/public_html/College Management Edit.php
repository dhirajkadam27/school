<?php
include_once 'config.php';
$insert = false;
if(isset($_POST['save']))
{	 
  $Name = $_POST['Name'];
  $Qualification = $_POST['Qualification'];
	$Department = $_POST['Department'];

	 $sql = "INSERT INTO `management`(`Name`, `Qualification`, `Department`)
     VALUES ('$Name','$Qualification', '$Department')";

if($conn->query($sql) == true) {
    $insert = true;
    } 
    else {
        echo "QUERY NOT CONNECTED";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <!--This Website is created by DHIRAJ KADAM on 5/10/2020.-->
<!--Contact details: [Mobile No. 7757897339/7410743968]; [E-mail id: dhirajkadam.official@gmail.com]-->
<!--This site is copyrighted.©️ All rights are ®️reserved (contact us for more information)-->
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTkNdkQWbd72kWkeAxBQQuiuYc1TPwRtBKwRQ&usqp=CAU" type="image/wepb" sizes="32x32">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<!--Desktop Version-->
<meta name="viewport" content="width=1024">
<title>Admin Panel</title>
        <style>
            body{
                margin:0;
                padding:0;
            }
            .title{
                text-align: center;
                font-size: 29px;
                margin-top: 10px;
                font-family: Verdana, Geneva, Tahoma, sans-serif;
                font-weight: bold;
            }
            .in{
                text-align: center;
                height: 26px;
            }
            .inbu{
                width: 111px;
                height: 34px;
                background-color: greenyellow;
                color:brown;
                font-weight: bolder;
                font-size: 24px;
            }
            table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 900px;
  margin:40px auto;
  
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px
}

tr:nth-child(even) {
  background-color: #dddddd;
}
button{
    background-color : blue;
    font-weight:bold;
    color:white;
    text-align:center;
}
button:after{
    background-color:red;
}
        </style>
    </head>
    <body>
        <div class="title"><u>Add College Management Staff</u></div>
      <?php
      error_reporting(0);
      if($insert == true) {
		echo"<div style ='text-align:center;margin-top:35px;' class='alert alert-success' role='alert'>
        Successfully Added A New Record!
      </div>";
        } 
        else {
            echo "<div style ='margin-top:35px; margin-left:450px'>
           
          </div>";
        }
       
      ?>
        <div class="input">
            <form method="post" action="College Management Edit.php">
            <input required name="Name" style="margin-left: 35px; margin-top: 10px; width: 359px;" type="text" placeholder="Enter Name " class="in">
            <input required name="Qualification" type="text" style="width: 255px;" placeholder="Enter Qualification " class="in">
            <input required name="Department" type="text" style="width: 211px;" placeholder="Enter Department " class="in">
            <input type="submit" value="Add" class="inbu" name="save">
        </form>
        </div>
        <hr style="margin-top: 20px;">
      
        <table>
            <tr>
            <th>Sr No.</th>
            <th>Name</th>
            <th>Qualification</th>
            <th>Department</th>
            <th>Delete</th>
        </tr>
        <?php
        include_once 'config.php';
        $no= 1;
        error_reporting(0);
        $query = "SELECT * FROM management";
        $data = mysqli_query($conn, $query);
        $total = mysqli_num_rows($data);
       

        if($total!=0){
            while($result = mysqli_fetch_assoc($data)){
                echo"
                <tr>
                <td>$no</td>
                <td>".$result['Name']."</td>
                <td>".$result['Qualification']."</td>
                <td>".$result['Department']."</td>
                <td style= 'text-align:center'><a href='deletem.php?rn=".$result[Name]."'><button>Delete</button></a></td>
                </tr>
                ";
                $no ++;
            }
        }
       else{
           echo "<div style ='text-align:center;margin-top:35px' class='alert alert-danger' role='alert'>
            Records Not Found!
          </div>";
       }
        ?>
         </table>
    </body>
</html>
