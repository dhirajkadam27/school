<?php
if(isset($_POST['save']))
{	 
    if($_POST['id'] == "hi" && $_POST['code'] == "hi"){
        header('location:After xyz abc.html');
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
     <!--This Website is created by DHIRAJ KADAM on 5/10/2020.-->
<!--Contact details: [Mobile No. 7757897339/7410743968]; [E-mail id: dhirajkadam.official@gmail.com]-->
<!--This site is copyrighted.©️ All rights are ®️reserved (contact us for more information)-->
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTkNdkQWbd72kWkeAxBQQuiuYc1TPwRtBKwRQ&usqp=CAU" type="image/wepb" sizes="32x32">


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!--Desktop Version-->
<meta name="viewport" content="width=1024">
<title>Security</title>
        <style>
            body{
                margin:0;
                padding: 0;
            }
            .center{
                width: 500px;
                height: 300px;
                background-color: turquoise;
                text-align: center;
                margin: auto;
                margin-top: 100px;
            }
      
        </style>
    </head>
    <body>
<div class="center"> 
    <p>.</p>
    <p style="font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; font-size: 30px; margin-bottom:29px; margin-top: -8px;">Admin Panel</p>
<?php
if(isset($_POST['save']))
{
  if(($_POST['id'] == "hi" && $_POST['code'] == "hi") == false){
    echo "<div style ='text-align:center;margin-top:-29px' class='alert alert-danger' role='alert'>
    Incorrect ID Password!
  </div>";
}
}
?>

    <form method="post" >
    <input name="id" type="text" placeholder="Enter User ID" style="width: 300px; height: 20px; margin-bottom: 20px; margin-top: 15px;"><br/>

    <input name="code" type="password" placeholder="Enter Password" style="width: 300px; height: 20px; margin-bottom: 20px; margin-top: 5px;"/><br>
 
    <input type="submit" name="save" style="text-decoration: none; width: 220px; height: 30px; margin-bottom: 20px; margin-top: 10px; background-color: aqua; font-weight: bold; font-size: 20px;" value="login"/>
    </form>
</div>

    </body>
</html>