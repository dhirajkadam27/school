
<!DOCTYPE html>
<html>
<head>

<!--This Website is created by DHIRAJ KADAM on 5/10/2020.-->
<!--Contact details: [Mobile No. 7757897339/7410743968]; [E-mail id: dhirajkadam.official@gmail.com]-->
<!--This site is copyrighted.©️ All rights are ®️reserved (contact us for more information)-->
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTkNdkQWbd72kWkeAxBQQuiuYc1TPwRtBKwRQ&usqp=CAU" type="image/wepb" sizes="32x32">



<!--Desktop Version-->
<meta name="viewport" content="width=1024">
<!--Desktop Version-->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
 <!--Desktop Version-->
 <script src="https://kit.fontawesome.com/a076d05399.js"></script>
 
 <script src="/path/to/js/jquery.autoscroll.js"></script>
 <!--Desktop Version-->
<title>AKJC Atpadi</title>
<!--Desktop Version-->
<style>
body{
     margin:0;
     padding:0;
}
/*header logo*/
header{
       display:flex;
       background: white
}
/*College Name*/
#texts{
      margin-left:20px;
      margin-top:12px;
}
header h3{
   color: #de0d0d; 
   font-size: 19px;
   font-weight: bold;
   font-family: 'Montserrat', sans-serif;
}
header p{
   color: black; 
   font-size: 17px;
   font-family: 'Roboto', sans-serif;
}
/* College contact*/
#Contact{
                margin-left:140px;
                text-align: center;
                margin-top:15px
                
}
/* College Image Slider */
{box-sizing: border-box;}
.mySlides {display: none;
    }
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
 max-width: 100%;
 position: relative;
 margin: auto;
}

/* Caption text */

/* Number text (1/3 etc) */
.numbertext {
 color: #f2f2f2;
 font-size: 12px;
 padding: 8px 12px;
 position: absolute;
 top: 0;
}

/* The dots/bullets/indicators */

/* Fading animation */
.fade {
 -webkit-animation-name: fade;
 -webkit-animation-duration: 1.5s;
 animation-name: fade;
 animation-duration: 1.5s;
}

@-webkit-keyframes fade {
 from {opacity: .4} 
 to {opacity: 1}
}

@keyframes fade {
 from {opacity: .4} 
 to {opacity: 1}
}
/*navigation bar*/
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #bababa;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-family: 'Noto Sans JP', sans-serif;
  font-weight: bold;
  font-size:12px
}

li a:hover{
           color: white;
           background: #4ca64c
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #bababa;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #4ca64c;}

.dropdown:hover .dropdown-content {
  display: block;
}
/*college info*/
.horizontal {
             background:#F7F7F7;
             width:100%;
             height:200px;
             margin-top:-17px;
             padding:0
}
.info{
      display:flex;
     
}
.icon span{
           font-size:40px;
           font-family: 'Roboto', sans-serif;
           margin-bottom:-30px
}
.icon h6{
         font-size:15px
}
.icon span, h6{
              display: block;
              margin-left:145px;
              text-align: center;
              font-family: 'Roboto', sans-serif;
               
}
.icon img{
          width:60px;
          height:60px;
          opacity:0.4;
          margin-left:145px;
          Margin-top:25px;
          margin-bottom:20px
}

.feature {
          width:100%;
          height:500px;
          background:#f6f6f6
}

.feature p{
            text-align: center;
            font-family: 'Roboto', sans-serif;
            font-size:50px;
            padding:20px 0 0 0

}

footer{
       background: black;
       height:400px;
       width:100%;
}

.type {
       display:flex;
       font-size:12px;
}
.type b{
        margin-left:90px;
        
}
.type p{
        margin-left:90px;
        margin-top:-8px
}
.sub-type{
margin-top:70px
}

footer b {
          color: white;
          font-family: 'Noto Sans JP', sans-serif;  
          
}

footer p{
         color:#bababa;
         font-family: 'Roboto', sans-serif;
}
.developer {
            margin-top:-1px;
            padding:20px 0;
            color: black;
            background: #bababa;
            font-size:15px;
            font-weight:bold;
            text-align: center;
            font-family: 'Roboto', sans-serif;
            
}


.title{
  text-align:center;
       font-family: 'Noto Sans JP', sans-serif;
       font-weight: bold;
       font-size:40px;
       color:green;
       margin-top:10px
       
}


table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 900px;
  margin:40px auto;
  
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px
}

tr:nth-child(even) {
  background-color: #dddddd;
}


</style>
</head>
<body>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!--Font style-->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Tangerine:wght@700&display=swap" rel="stylesheet">
<!-- font style end-->
<header>
<!-- College logo-->
<div id="img">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTkNdkQWbd72kWkeAxBQQuiuYc1TPwRtBKwRQ&usqp=CAU" style="margin:10px; height:110px"> 
</div>
<!-- college Logo end-->

<!--College details-->
<div id="texts">
<p style="margin-bottom:-14px" >Atpadi Education Society</p>
<h3>Abasaheb Khebudkar Junior College Of Science</h3>
<p style="margin-top:-12px">Affiliated to Shivaji University, kolhapur</p>
</div>
<!--College details end-->

<!--Contact info-->
<div id="Contact">
<p style="font-size:13px; font-family: 'Montserrat', sans-serif; font-weight: bolder; color:green; margin-top:25px">Contact Us</p>
<div style="display:flex" class="phone">
<img style="width:12px; height:12px; margin-top:-4px; margin-left:40px; " src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRAxXGn00tcP6pFL_qE7wRnJVkmc2kuT5SOng&usqp=CAU">
<p style="margin-top:-4px; margin-left:0px; font-family: 'Montserrat', sans-serif; font-size:10px">(02343)220248</p>
</div>
<p style="margin-top:-5.5px; font-family: 'Montserrat', sans-serif; font-size:10px">sbvakjrcollegeatpadi@gmail.com</p>
</div>
<!--contact info end-->
</header>
<!--NAV BAR -->
<ul>
  <li><a href="Home.php"  >HOME</a></li>
  <li class="dropdown">
  <a href="javascript:void(0)" class="dropbtn">ABOUT<i style="margin-left:5px" class="fas fa-angle-down"></i></a>
  <div class="dropdown-content">
  <a href="College.html">COLLEGE</a>
  <a href="Atpadi Education Society.html">ATPADI EDUCATION SOCIETY</a>
   <a href="Founder.html">FOUNDER BABASAHEB DESHMUKH</a>
    <a href="Chairman.html">CHAIRMAN BAPUSAHEB DESHMUKH</a>
  </div>
  
  <li class="dropdown">
  <a href="javascript:void(0)" class="dropbtn" style="background:#4ca64c; color: white">ADMINISTRATION<i style="margin-left:5px" class="fas fa-angle-down"></i></a>
  <div class="dropdown-content">
  <a href="Teaching Staff.php">TEACHING STAFF</a>
  <a href="Non-Teaching Staff.php">NON-TEACHING STAFF</a>
  <a href="College Management.php" style="background:#4ca64c; color: white">COLLEGE MANAGEMENT</a>
  <a href="Alumni.php">ALUMNI</a>
  </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">COURSES<i style="margin-left:5px" class="fas fa-angle-down"></i></a>
    <div class="dropdown-content">
      <a href="11th.html">11th</a>
      <a href="12th.html">12th</a>
      <a href="MH-CET.html">MH-CET</a>
      <a href="NEET.html">NEET</a>
      <a href="JEE.html">JEE</a>
    </div>
  </li>
  <li><a href="Facilities.html">FACILITIES</a></li>
  <li><a href="Students.html">STUDENTS</a></li>
   <li style="margin-left:220px; margin-top:2px; "><a style="color:#de0d0d; font-family: 'Montserrat', sans-serif; font-size:14px" href="Online Admission.html">ONLINE ADMISSION</a></li>
  
</ul>

<!--NAV BAR end-->


<div class="title">
College Management Staff
</div>
<div class="outline" >

  <table>
    <tr>
    <th>Sr No.</th>
    <th>Name</th>
    <th>Qualification</th>
    <th>Department</th>
</tr>
<?php
include_once 'config.php';
$no=1;
error_reporting(0);
$query = "SELECT * FROM management";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);


if($total!=0){
    while($result = mysqli_fetch_assoc($data)){
        echo"
        <tr>
        <td>$no</td>
        <td>".$result['Name']."</td>
        <td>".$result['Qualification']."</td>
        <td>".$result['Department']."</td>
        </tr>
        ";
        $no++;
    }
}
else{
    echo "<div style ='text-align:center;margin-top:35px;width:100%;background-color: rgba(255,0,0,0.2);padding:15px 0;color: red'>
    Records Not Found!
  </div>";
}
?>
 </table>
</div>




<footer>
<div class="type">
<div class="sub-type">
<b>Atpadi Education Society</b>
<p style="margin-top:20px">Shri Bhavan Vidhyalay</p>
<p>Abasaheb khabudkar junior College</p>
<p>Atpadi College Atpadi</p>
<p>Girls Highschool Atpadi</p>
</div>

<div class="sub-type">
<b>Administration</b>
<p style="margin-top:20px">Teaching Staff</p>
<p>Non-teaching Staff</p>
<p>Alumni</p>
<p></p>
</div>

<div class="sub-type">
<b>About</b>
<p  style="margin-top:20px">College</p>
<p>Founder</p>
<p>Chairman</p>
</div>

<div class="sub-type">
<b>Contact Info</b>
<p  style="margin-top:20px">Abasaheb Khabudkar </p>
<p>Junior College,Atpadi</p>
<p>Tal-Atpadi; Dist-Sangli</p>
<p>(Maharashtra)</p>
<p>Pincode-415301</p>
<b>Location</b>
<p style="margin-top:20px">Telephone No.(02343)220248</p>
<p>E-mail id: sbvakjrcollegeatpadi@gmail.com</p>
</div>
</div>
</footer>

<div class="developer">
®All Rights Are Reserved By Dhiraj Kadam. Contact No.7757897339/7410743968 E-mail id- dhirajkadam.official@gmail.com
</div>
</html>