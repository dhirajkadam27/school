<?php
include_once 'config.php';
error_reporting(0);

$NAME = $_GET['rn'];
$query = "DELETE FROM admis WHERE SN = '$NAME'";
if(mysqli_query($conn, $query)){
    header('location:Online Admission Edit.php');
}
else {
    echo "<div style ='margin-top:35px; margin-left:450px' class='alert alert-danger' role='alert'>
    Something Went Wrong, Record Couldn't Delete
  </div>";
}
?>